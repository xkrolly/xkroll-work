if("serviceWorker" in navigator){
	navigator.serviceWorker.register("sw.js").then(registration => {
		console.log("SW registered!");
		console.log(registration);
	}).catch(error => {
		console.log("SW registration failed!");
		console.log(error);
	})
}

function getMyLoc() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToPos);
   } else { 
     var msg="Put on your device location ( <i class='fa fa-map-marker' style='color:#2166f3'></i> ) to use this app!";
     var bgcolor='#002';
     var id='';
     var respSelector='response';
     response(msg, bgcolor, id, respSelector);
    }
}
    
function redirectToPos(position) {
    var lat =position.coords.latitude;
    var lng =position.coords.longitude;
    {maximumAge:10000; timeout: 5000; enableHighAccuracy: true}

    $('#latd').val(lat);
    $('#lngd').val(lng);
}
