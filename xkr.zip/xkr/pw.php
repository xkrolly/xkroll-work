<?php

                echo 'Oladex  ' . password_hash('Oladex4$', PASSWORD_DEFAULT);
                echo '<br>Olatej  ' . password_hash('Olatej4$', PASSWORD_DEFAULT);
