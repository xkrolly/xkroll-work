//request form submitter
 $('#request_data').on('submit', function(event){
    event.preventDefault();
  
    $.ajax({
        url: 'views/setrequest.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          $('#request_data')[0].reset();
            var msg= data.reqResp;
            var did = data.did;
            var bgcolor='#002';
            var id = '#request_fm';
            var respSelector = 'response';
            response(msg, bgcolor, id, respSelector);
            window.scrollTo(0,0);
        },
        error: function(data){
          $('#request_data')[0].reset();
          var msg='Sorry, your request failed, try again!';
          var bgcolor='red';
          var id = '#request_fm';
          var respSelector = 'response';
          response(msg, bgcolor, id, respSelector);
         
        }
      });
  });

   $('#return_data').on('submit', function(event){
    event.preventDefault();
        $.ajax({
        url: 'views/setreturn.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var msg=data.rtnResp;
            var bgcolor='#002';
            var respSelector = 'response';
            var id = '#return_fm';
            response(msg, bgcolor, id, respSelector);
        },
        error: function(data){
            var msg='Failed, try again.';
            var bgcolor='red';
            var respSelector = 'response';
            var id = '#return_fm';
            response(msg, bgcolor, id, respSelector);
        }
    });
  });

  $('#search_data').on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'views/fetchSearch.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var type=data.type;
            var id='';
            var ppt='';
            var city='';
            var time='';
            var fn='';
            var ln='';
            var total=data.total;

           if(type==1){
              var id=data.id;
              var ppt=data.ppt;
              var city=data.city;
              var time=data.time;
            }
            else{
              var fn=data.fn;
              var ln=data.ln;
            }

            var total=data.total;
            var page = '<div style="text-align:right;"><a href=""><i class="fa fa-times"></i></a></div>';
           
            if(total <= 0){
              page += "<br><div style='color:red; font-size:20px; font-family:san-serif; text-align:center;'>SORRY! NO MATCH FOUND</div>";
                          
            }else{
              while(total > 0){
                  if(type==1){
                      page += "<div style='color:#005; font-family:san-serif;'>"+
                          "<div style='display:flex;'>"+
                            "<div style='color:#2166f3;'>"+ppt[total-1]+"</div>"+
                            "<div style='margin-left:auto'>"+time[total-1]+"</div>"+
                          "</div>"+
                          "<div style='display:flex;'>"+
                            "<span style='font-size:16px;'>This item was found in "+city[total-1]+" </span>"+
                          "</div>"+
                          "<div style='display:flex;'>"+
                              "<div style='margin-left:auto;'><button class=''>claim</button></div>"+
                          "</div>"+
                        "</div><hr>";
                    }
                    else{
                      page += "<div style='color:#005; font-family:san-serif;'>"+
                          "<h6 style='color:#2166f3'>"+fn[total-1]+"</h6>"+
                          "<span style='font-size:16px;'>"+ln[total-1]+" "+fn[total-1]+" is available on Xkroll</span>"+
                          "<div style='text-align:right'><button class=''>View profile</button></div>"+
                        "</div><hr>";
                    }  
                total--;
              }
            }
          $('#profilePg').hide();
          $('#req').hide();
          $('#rtn').hide();
          $('#rpt').hide();
          $('#search_results').html(page);
        },
        error: function(data){
           page = "<hr><div style='background-color:white; text-align:center; border:1px solid #ccc; border-radius:10px'>Something went wrong, please try again!</div>";
           $('#search_results').html(page);
        }
    });
  });

$('.grabFDI').click(function(){
    var id=$(this).attr('id').replace('grabFDI', '');
    $('#grabFDI'+id).on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'views/grabFDI.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.setnReply;
          var bgcolor='#002';
          var respSelector='response';
          var id='';
 
          response(msg, bgcolor, id, respSelector);
        },
    });
    });
    });

  $(document).on('click','#saveSettings',function(){
  $('#settingFm').on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'views/setSettings.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.setnReply;
          var bgcolor='#002';
          var respSelector='response';
          var id='';
          response(msg, bgcolor, id, respSelector);
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          var respSelector='response';
          var id='';
          response(msg, bgcolor, id, respSelector);
        }
      });
    });
});


  $(document).on('click','.commentBtn',function(){
     $('#commentForm').on('submit', function(event){
        event.preventDefault();

    $.ajax({
        url: 'includes/comment.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var comment=data.commentResp+' '+'~just now';
          if(comment!='failed'){
          var discussId = data.discussId;
          $('#commentBox').val('');
          var p = document.createElement("p");
          var node = document.createTextNode(comment);
          p.appendChild(node);
          var addCommentSpace = document.getElementById('addComment');
          var child = document.getElementById("commentOpener");
          addCommentSpace.insertBefore(p, child);
            $(window).scrollTop(100);
          }
          else{
            var msg='Attempt failed, please try again!';
            var bgcolor='red';
            var respSelector='response';
            var id='';
            response(msg, bgcolor, id, respSelector);
         
          }
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          var respSelector='response';
          var id='';
          response(msg, bgcolor, id, respSelector);
        }
      });
    });
  });

//assist form submitter
$(document).ready(function(){  
  $(document).on('click','.assistForm',function(){
    var i4=$(this).prop('id').replace('channel4', '');
    var i3=i4.replace('channel3', '');
    var i2=i3.replace('channel2', '');
    var i=i2.replace('channel1', '');

  $('#'+i+'assistForm').on('submit', function(event){
    event.preventDefault();
    var item=$('#'+i+'item').val();
    var donation_id=$('#'+i+'rid').val();
    function response2(msg, bgcolor){
       $('#'+i+'assist').modal('hide');
       $('#'+i+'hid').hide('slow');
       $('#successAss').addClass(i+'successAss');
          $('#'+i+'successAss').html('<div class="dropshadow" id="'+i+'successAss" style="z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:20%;'+
          ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:white; background-color:'+bgcolor+'">'+msg+'</div>');
     
            setTimeout(function(){
                         $('#'+i+'successAss').fadeOut('slow')
                         $('#'+i+'assistForm').empty();
                        }, 5000);
    }
    function clearInputs(){
      $("#"+i+"assistForm :input").val('');
      }
    
  if(helperContact!=''){
    $.ajax({
        url: 'views/assist.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.assResp;
          var bgcolor='#2196f3';
          response2(msg, bgcolor);
          clearInputs();
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          response2(msg, bgcolor);
        }
      });
    }
   });
 });
});


function ajaxProcessor(url, bgcolor){
      $.ajax({
        url: url,
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.assResp;
          response2(msg, bgcolor);
          clearInputs();
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor2='red';
          response2(msg, bgcolor2);
        }
      });

}