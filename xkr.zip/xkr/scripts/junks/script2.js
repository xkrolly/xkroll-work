/*$('#mycomm').on('click', function(){
  alert('YOU ARE GOOD');
});
*/
/*var slider = document.getElementById("iRange");
var output = document.getElementById("idemo");
output.innerHTML = slider.value;

slider.oninput = function(){
  output.innerHTML = this.value;
}
*/


$('.RBtn').dblclick(function(){
    $('.requestBtn').hide();
    $('#donateBtn').show();

});

    function response(msg, bgcolor, id, respSelector){
       $(id).modal('hide');
       
       var div = document.createElement("div");
          var node = document.createTextNode(msg);
          div.appendChild(node);
          var respPanel = document.getElementById(respSelector);
          var child = document.getElementById("commentOpener");
          respPanel.appendChild(div);
          
        $('#'+respSelector).css({'z-index':10, 'font-size':'16px', 'font-family':'roboto', 'border-radius':'5px', 'text-align':'center', 'position':'fixed', 'left':'5%', 'right':'5%', 'bottom':'10%', 'margin-left':'auto', 'margin-right':'auto', 'padding':'5px', 'color':'#fff', 'background-color':bgcolor});

            setTimeout(function(){
                            $('#'+respSelector).slideUp('slow');
                           setTimeout(function(){
                             respPanel.removeChild(div);
                            }, 50);    
                        }, 5000);
    }

//GEO is HERE
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToPosition);
   } else { 
     var msg="Put on your device location ( <i class='fa fa-map-marker' style='color:#2166f3'></i> ) to use this app!";
      notifyUser(msg);
    }
}

function redirectToPosition(position) {
    var lat =12.8022761;//position.coords.latitude;
    var lng =9.5663224;// position.coords.longitude;
  {maximumAge:0; timeout: 5000; enableHighAccuracy: true}
  $.ajax({
        type: 'POST', 
        url:  'views/getGeo.php',
        data: 'lat='+lat+'&lng='+lng,
        });
}

redirectToPosition();//getLocation();

setInterval(function(){
  redirectToPosition();//  getLocation();
}, 1000*60);


  $(document).on('click','#saveSettings',function(){
  $('#settingFm').on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'views/setSettings.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.setnReply;
         var bgcolor='#002';
          var respSelector='response';
          var id='';
 
    response(msg, bgcolor, id, respSelector);
       
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
         var bgcolor='red';
          var respSelector='response';
          var id='';
 
response(msg, bgcolor, id, respSelector);
        }
      });
    });
});

  $(document).on('click','.commentBtn',function(){

  $('#commentForm').on('submit', function(event){
    event.preventDefault();

    $.ajax({
        url: 'includes/comment.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var comment=data.commentResp+' '+'~just now';
          if(comment!='failed'){
          var discussId = data.discussId;
          $('#commentBox').val('');
          var p = document.createElement("p");
          var node = document.createTextNode(comment);
          p.appendChild(node);
          var addCommentSpace = document.getElementById('addComment');
          var child = document.getElementById("commentOpener");
          addCommentSpace.insertBefore(p, child);
            $(window).scrollTop(100);
        }
        else{
          var msg='Attempt failed, please try again!';
         var bgcolor='red';
          var respSelector='response';
          var id='';
 
response(msg, bgcolor, id, respSelector);
       
        }
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
         var bgcolor='red';
          var respSelector='response';
          var id='';
 
response(msg, bgcolor, id, respSelector);
        }
      });
    });
  });

// viewports functions
$.fn.isInViewport = function(){
  var elementTop= $(this).offset().top;
  var elementBottom= elementTop + $(this).outerHeight();

  var viewportTop= $(window).scrollTop();
  var viewportBottom = viewportTop + $(window).height();
  var m=$(window).height()/2;
  return elementBottom > (viewportTop+m) && elementTop < (viewportBottom-m);
  };

  $(window).on('resize scroll', function(){
      $('.aud_auto').each(function(){
    var id=$(this).attr('id').replace('aud_auto', '');
    var fd_id=$(this).attr('id').replace('fd', '');
    
    var auto=$('#autoplay'+id).val();
    var proof=$('#proof'+id).val();
    var ms=$('#media_setins'+id).val();
    if($(this).isInViewport()){
      if(auto==1){
           if($('#u_note'+id).length>0){
              if(ms==3 || ms==5){document.getElementById('u_note'+id).innerHTML = "<source src='user_notes/"+proof+".wav' type='video/webm'>";
            document.getElementById('u_note'+id).play();}}
      }
      else{
        if($('#u_note'+id).length>0){document.getElementById('u_note'+id).pause();}
      }
    
  //on the fly loading down here
      if(fd_id > 5){
        //load nxt twenty feeds
        alert('remain 5 down the line');
       //var body = document.getElementByTagName("body")[0];
        var pp = document.getElementById("aud_auto"+id);

      }
    }

  });
});



//notification
    function updateNotifications(note='newMsg'){
        $.ajax({
            url: 'views/notifyMe.php',
            method: 'GET',
            data: {getNote: note},
            dataType:'json',
            success: function(data){
                var totalNew =
                '<div style="font-family:monospace; background-color:red">'+
                  '<span style="z-index:1; position:fixed; background-color:red; color:white; border-radius:50%; padding:4px; padding-top:6px; padding-bottom:7px; font-size:5px; margin-top:-20px; margin-left:13px; height:12px; border:1.7px solid #fff">'+
                  '<strong>'+data.totalNew+'</strong>'+
                  '</span></div>';

              $('.notifier').html(data.totalNew);

            }
        });
    }
            updateNotifications();
        setInterval(function(){
            updateNotifications();
        }, 1000*30);
//switch buttons
$('#toggle').on('click', function(){
                  var click=+$(this).data('clicks') || 0;
                  if(click % 2 == 1){
                      $('.local').show();
                    $('.global').hide();

                  }
                  else{
                      $('.global').show();
                      $('.local').hide();
                        
                  };
                  $(this).data('clicks',click+1);
              });


$('#toggle2').on('click', function(){
                  var click=+$(this).data('clicks') || 0;
                  if(click % 2 == 1){
                      $('.city').show();
                     $('.profiles_sach').hide();
                      $('.search_i').show();
                      $('.profiles_sach').val('');
                  }
                  else{
                      $('.city').hide();
                      $('.profiles_sach').show();
                      $('.search_i').hide();
                      $('.search_i').val('');
                  };
                  $(this).data('clicks',click+1);
              });
//styling input type file
var inputs = document.querySelectorAll( '.file-input' );
Array.prototype.forEach.call( inputs, function( input ){
  var label = input.nextElementSibling;
  var labelVal = label.innerHTML;

  input.addEventListener( 'change', function(e){

    var fileName = '';
    if(this.files && this.files.length > 1)
      fileName = (this.getAttribute( 'data-multiple-caption') || '').replace('{count}', this.files.length);
    else 
      fileName = e.target.value.split('\\').pop();

    if(fileName.length > 20)
      fileName = fileName.substr(0, 20) + '...';
    if(fileName)
      label.innerHTML = fileName;
    else
      label.innerHTML = labelVal;
  });
});

$(document).on('click','.aud_auto',function(){
  $('#donateBtn').show();
  $('#donateBtn').removeClass('collapse');
});
//assist form submitter
$(document).ready(function(){  
  $(document).on('click','.assistForm',function(){
    var i4=$(this).prop('id').replace('channel4', '');
    var i3=i4.replace('channel3', '');
    var i2=i3.replace('channel2', '');
    var i=i2.replace('channel1', '');

  $('#'+i+'assistForm').on('submit', function(event){
    event.preventDefault();
    var item=$('#'+i+'item').val();
    var donation_id=$('#'+i+'rid').val();
    function response2(msg, bgcolor){
       $('#'+i+'assist').modal('hide');
       $('#'+i+'hid').hide('slow');
       $('#successAss').addClass(i+'successAss');
          $('#'+i+'successAss').html('<div class="dropshadow" id="'+i+'successAss" style="z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:20%;'+
          ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:white; background-color:'+bgcolor+'">'+msg+'</div>');
     
            setTimeout(function(){
                         $('#'+i+'successAss').fadeOut('slow')
                         $('#'+i+'assistForm').empty();
                        }, 5000);
    }
    function clearInputs(){
      $("#"+i+"assistForm :input").val('');
      }

    
  if(helperContact!=''){
    $.ajax({
        url: 'views/assist.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.assResp;
          var bgcolor='#2196f3';
          response2(msg, bgcolor);
          clearInputs();
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          response2(msg, bgcolor);
        }
      });
    }
   });
 });
});

//emp btn
   function animate(i){
        $(i).toggleClass('bounce');
        $(i).css('font-size','3px');
        setTimeout(function(){
               setTimeout(function(){
                    $(i).toggleClass('bounce');
                    $(i).css('font-size','20px');
               }, 600);    
            }, 600);    
   }

  function animate3(i){
      var sound="<audio id='xban' volume='60'>"+
                  "<source src='sounds/ban.mp3' type='video/webm'>"+
                "</audio>";
  }

  $(document).on('click','.ban',function(){
         //alert('You considered the request unrealistic!');
    var id=$(this).prop('id').replace('ban', '');         
    var tid=$('#tid').val();
    var banAll=$('#'+id+'banAll').val(); 
    var clicked = $('#clicked'+id).val();

    var i='#icon2'+id;
    animate3(i);
    var eColor='#929292'; var bColor='#ff00e2';
    var b='';

    var ban_upd='';
    clicked == 2 ? ban_upd = parseInt(banAll) : 
    ban_upd = parseInt(banAll) + 1;
    clicked == 2 ? bColor = '#929292' : bColor = bColor;
   
    $(i).css('webkit-text-stroke-color', bColor);
    $('#icon'+id).css('webkit-text-stroke-color', eColor);     
    
    var prev_ban="<sub id='b"+id+"' style='color:#2166f3'>"+ban_upd+"</sub>";
    $('#b'+id).replaceWith(prev_ban);

    //empty clicked value
    clicked == 2 ? $('#clicked'+id).val(0) : 
    $('#clicked'+id).val(2);

        $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:2},
          dataType:'json',
          
          success: function(data){
           var banData=(data.upd_ban).replace('-', '');
           var empData=(data.upd_emp).replace('-', '');
           var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
           var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

          $('#e'+data.id).replaceWith(upd_emp);
          $('#icon'+data.id).css('webkit-text-stroke-color', '#929292');
          $('#b'+data.id).replaceWith(upd_ban);
          $('#icon2'+data.id).css('webkit-text-stroke-color', '#ff00e2');
        },

        }); 
      });

$(document).on('click','.emp', function(){
    
    var id=$(this).prop('id').replace('emp', '');         
    var tid=$('#tid').val();
    var empAll=$('#'+id+'empAll').val();         
    var clicked = $('#clicked'+id).val();

    var i='#icon'+id;
    animate(i);
    var eColor='red'; var bColor='#929292';
    var e='';
    
    clicked == 1 ? emp_upd = parseInt(empAll) : 
    emp_upd = parseInt(empAll) + 1;
    
    clicked == 1 ? eColor = '#929292' : eColor = eColor;
   
    $('#icon2'+id).css('webkit-text-stroke-color', bColor);
    $(i).css('webkit-text-stroke-color', eColor);     
    
    var prev_emp="<sub class='e"+id+"' id='e"+id+"' style='color:#2166f3'>"+emp_upd+"</sub>";
    $('#e'+id).replaceWith(prev_emp);

    //empty clicked value
    clicked == 1 ? $('#clicked'+id).val(0) : 
    $('#clicked'+id).val(1);

    $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:1 },
          dataType:'json',
      success: function(data){
         var banData=(data.upd_ban).replace('-', '');
         var empData=(data.upd_emp).replace('-', '');

        var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
        var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

        $('#b'+data.id).replaceWith(upd_ban);
        $('#icon2'+data.id).css('webkit-text-stroke-color', '#929292');

        $('#e'+data.id).replaceWith(upd_emp);
        $('#icon'+data.id).css('webkit-text-stroke-color', 'red');
      },

    });   
  });
//});
 //ENDS HERE

//$(document).ready(function(){
$('#recorder').click(function(event){
startRec();

function startRec(){
  let device= navigator.mediaDevices.getUserMedia({ audio: true });
  let chunks = [];
  let recorder;
  device.then(stream => {
    recorder = new MediaRecorder(stream);

    recorder.ondataavailable = e => {
      chunks.push(e.data);

      if(recorder.state == 'inactive'){
        let blob = new Blob(chunks, {type: 'audio/webm' });
   var ad=URL.createObjectURL(blob); 
   //start
   var xhr=new XMLHttpRequest();
   xhr.onload=function(e){
    if(this.readState===4){
      console.log("Server returned: ",e.target.responseText);
    }
   };
   var fd=new FormData();
   fd.append("audio_data",blob,"note");
   xhr.open("POST","index.php?page=aud_upload",true);
//   xhr.open("POST","views/aud_upload.php",true);
   xhr.send(fd);
   //stop
   document.getElementById('audio').innerHTML = '<source src="'+ad+'" type="video/webm" />';
          $('#myaudio').val(ad);
      }
    }
    recorder.start(1000);
  });
  setTimeout(() => {
    recorder.stop();
$('#audioMeter').replaceWith('<div><center><audio id="audio" controls style="width:80%"></audio></center></div>');
         $('#aud').css('background-color','white');
          $('#recorder').css('color','#aaa');
          $('.mic').hide();
                //$('#myaudio').val('src');
    
      //    document.getElementById('s4').play();

  }, 16000);

}


  $('#aud').css('background-color','gold');
  $('#recorder').css('color','white');
  $('#aud_reader').show();
  $('.mic').hide();

setTimeout(function(){
                       $('#initA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 2);

 setTimeout(function(){
                       $('#oneA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#oneA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#oneA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 2000);

setTimeout(function(){
                           $('#twoA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#twoA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#twoA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 3000);
setTimeout(function(){
                           $('#threeA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#threeA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#threeA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 4000);
setTimeout(function(){
                           $('#fourA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#fourA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#fourA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 5000);
setTimeout(function(){
                           $('#fiveA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#fiveA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#fiveA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 6000);

setTimeout(function(){
                       $('#sixA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#sixA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#sixA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 7000);
setTimeout(function(){
                       $('#sevenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#sevenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#sevenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 8000);
setTimeout(function(){
                       $('#eightA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#eightA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#eightA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 9000);
setTimeout(function(){
                       $('#nineA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#nineA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#nineA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 10000);
setTimeout(function(){
                       $('#tenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#tenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#tenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 11000);
setTimeout(function(){
                       $('#elevenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#elevenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#elevenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 12000);
setTimeout(function(){
                       $('#twelveA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#twelveA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#twelveA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 13000);
setTimeout(function(){
                       $('#thirteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#thirteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#thirteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 14000);
setTimeout(function(){
                       $('#fourteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#fourteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#fourteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 15000);
setTimeout(function(){
                       $('#fifteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#fifteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#fifteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 16000);

//  document.getElementById('s4').play();
});


useAud();
function useAud(){
        $(document).on('click','#useAudio',function(){
          $('#useAudio').css('font-size','30px');
          
          $('#textRec').remove();
          $('#audioRec').show();

        });
      }

//Rpt info
$(document).on('click','#rptLx', function(){ 
    $(".rptLxFm").show();
    $(".rtnLxFm").hide();
    $("#rptLx").css('border','2px inset red');
    $("#rtnLx").css('border','2px inset #eee');
    $("#rFm").load('views/report-loss.php')
  });

//Return info
$(document).on('click','#rtnLx', function(){ 
    $(".rtnLxFm").show();
    $(".rptLxFm").hide();
    $("#rptLx").css('border','2px inset #eee');
    $("#rtnLx").css('border','2px inset green');
      $("#rFm").load('views/returns.php')
  });


$(document).on('click','#rptHx', function(){ 
    $("#rpt").show();
    $("#rtn").hide();
    $("#req").hide();
    $("#rptHx").css('color', '#fff');
    $("#rptHx").css('background-color','#ff00e2');
    $("#reqHx").css('color', 'black');
    $("#reqHx").css('background-color','#fff');
    $("#rtnHx").css('color', 'black');
    $("#rtnHx").css('background-color','#fff');
  
  });
 $(document).on('click','#rtnHx', function(){ 
    $("#rpt").hide();
    $("#rtn").show();
    $("#req").hide();
    $("#rtnHx").css('color', '#fff');
    $("#rtnHx").css('background-color','#ff00e2');
    $("#rptHx").css('color', 'black');
    $("#rptHx").css('background-color','#fff');
    $("#reqHx").css('color', 'black');
    $("#reqHx").css('background-color','#fff');
  
  });
 $(document).on('click','#reqHx', function(){ 
    $("#rpt").hide();
    $("#rtn").hide();
    $("#req").show();
    $("#reqHx").css('color', '#fff');
    $("#reqHx").css('background-color','#ff00e2');
    $("#rtnHx").css('color', 'black');
    $("#rtnHx").css('background-color','#fff');
    $("#rptHx").css('color', 'black');
    $("#rptHx").css('background-color','#fff');
  });


//$(document).ready(function(){
    $(document).on('click','.sendContact',function(){
      $('.assistMedium').hide();
      $('.helper_tel').show();
      $('#backToOptList').show();
      
    });
     $(document).on('click','.chatUp',function(){
      $('.assistMedium').hide();
      $('.chatMedium').show();
       $('#backToOptList').show();
     
    });
        $(document).on('click','#backToOptList',function(){
      $('.assistMedium').show();
      $('.chatMedium').hide();
      $('.helper_tel').hide();
       $('#backToOptList').hide();
     
  
    });
//});

$(document).on('click', '#textProofCaller', function(){
  postFormatCaller('textProofCaller');
  $('#textProofCaller').css('color','red');
});

$(document).on('click', '#audioProofCaller', function(){
  postFormatCaller('audioProofCaller');
  $('#audioProofCaller').css('color','red');
});

$(document).on('click', '#textProofCloser', function(){
  $('#textProof').hide();
  postFormatCaller('');
});

$(document).on('click', '#radiusCoverageCaller', function(){
  xkrollRangeCaller('radiusCoverageCaller');
  $('#radiusCoverageCaller').css('color','#2166f3');
  
});

$(document).on('click', '#globalCoverageCaller', function(){
  xkrollRangeCaller('globalCoverageCaller');
  $('#globalCoverageCaller').css('color','#2166f3');
  $('#global').val(1);
});

$(document).on('click', '#radiusCoverageCloser', function(){
  $('#radiusCoverage').hide();
  xkrollRangeCaller('');
});

function postFormatCaller(exclude){
  $('#'+exclude).css('color','red');
  $('.unselectedCaller').css('color','#666');

  var selectedFmControl=exclude.replace('Caller', '');
  $('.unselected').hide();
  $('#'+selectedFmControl).show();
}

function xkrollRangeCaller(exclude){
  $('#'+exclude).css('color','#2166f3');
  $('.unselectedCaller2').css('color','#666');

  var selectedFmControl=exclude.replace('Caller', '');
  $('.unselected2').hide();
  
  selectedFmControl === 'globalCoverage' ? rangeValue = 'visible to everyone' : rangeValue = 'within <span class="rangeVal"></span>km radius';
  document.getElementById('rangeValue').innerHTML='<span>'+rangeValue+'</span>';
  $('#'+selectedFmControl).show();
 $('.coverage').show();
 
 var slider = document.getElementById("callRange");

slider.oninput = function() {
  $('.rangeVal').text((Math.round(slider.value/100))/10);
}


}

//request form submitter
 $('#request_data').on('submit', function(event){
    event.preventDefault();
  
    $.ajax({
        url: 'views/setrequest.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
        $('#request_data')[0].reset();
        var msg= data.reqResp;
        var did = data.did;
         var bgcolor='#002';
         var id = '#request_fm';
         var respSelector = 'response';
         response(msg, bgcolor, id, respSelector);
          window.scrollTo(0,0);
        },
        error: function(data){
        $('#request_data')[0].reset();
      var msg='Sorry, your request failed, try again!';
      var bgcolor='red';
      var id = '#request_fm';
      var respSelector = 'response';
         response(msg, bgcolor, id, respSelector);
         
        }
      });
  
    
  });
//});

  //REPORT submitter 
//$(document).ready(function(){
  $('#return_data').on('submit', function(event){
    event.preventDefault();
    var asset_id=$('#asset-id').val();
    var city=$('#city').val();
    var area=$('#area').val();
    var street=$('#street').val();
    var contact=$('#contact').val();
    var rptType=$('#rptType').val();
    
  if(asset_id==1 || asset_id==''){  $('#attache').load('includes/itemFm.inc.php');}
  if(asset_id==6){  $('#attache').load('includes/personFm.inc.php');}
  if(asset_id==3){  $('#attache').load('includes/cardFm.inc.php');}
  if(asset_id==2){  $('#attache').load('includes/docFm.inc.php');}
  if(asset_id==4){  $('#attache').load('includes/jewelFm.inc.php');}
  if(asset_id==5){  $('#attache').load('includes/moneyFm.inc.php');}
    
      $('#return_fm').modal('show');
      $('#_asset-id').val(asset_id);
      $('#_city').val(city);
      $('#_area').val(area);
      $('#_street').val(street);
      $('#_contact').val(contact);
      $('#_rptType').val(rptType);
      /*if(rptType == 1){
        $('#rptBtns').innerHTML('REPORT');
      }*/
    
  });

  $('#return_data2').on('submit', function(event){
    event.preventDefault();
    var _asset_id=$('#_asset-id').val();
    var _city=$('#_city').val();
    var _area=$('#_area').val();
    var _street=$('#_street').val();
    var _contact=$('#_contact').val();
    
    $.ajax({
        url: 'views/setreturn.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var msg=data.rtnResp;
            var bgcolor='#002';
            var respSelector = 'response';
            var id = '#return_fm';
            response(msg, bgcolor, id, respSelector);
        },
        error: function(data){
            var msg='Failed, try again.';
            var bgcolor='red';
            var respSelector = 'response';
            var id = '#return_fm';
            response(msg, bgcolor, id, respSelector);
        }
    });
  });
  
  //SEARCH submitter 
  $('#search_data').on('submit', function(event){
    
    event.preventDefault();
    $.ajax({
        url: 'views/fetchSearch.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var type=data.type;
            var id='';
            var ppt='';
            var city='';
            var time='';
            var fn='';
            var ln='';
            var total=data.total;

           if(type==1){
            var id=data.id;
            var ppt=data.ppt;
            var city=data.city;
            var time=data.time;}
            else{
            var fn=data.fn;
            var ln=data.ln;}

            var total=data.total;
            var page = '';
           
            if(total < 1){
              page += "<br><div style='color:red; font-size:20px; font-family:san-serif; text-align:center;'>SORRY! NO SEARCH RESULT</div>";
                          
            }else{
              while(total > 0){
                  if(type==1){
                      page += "<div style='color:#005; font-family:san-serif;'>"+
                          "<h6 style='color:#2166f3'>"+ppt[total-1]+"</h6>"+
                          "<span style='font-size:16px;'>This item was found in "+city[total-1]+" "+time[total-1]+"</span>"+
                          "<div style='text-align:right'><button class=''>claim</button></div>"+
                        "</div><hr>";
                    }
                    else{
                      page += "<div style='color:#005; font-family:san-serif;'>"+
                          "<h6 style='color:#2166f3'>"+fn[total-1]+"</h6>"+
                          "<span style='font-size:16px;'>"+ln[total-1]+" "+fn[total-1]+" is available on Xkroll</span>"+
                          "<div style='text-align:right'><button class=''>View profile</button></div>"+
                        "</div><hr>";
                    }  
                total--;
              }
            }
          $('#search_results').html(page);
        },
        error: function(data){
           page = "<hr><div style='background-color:white; text-align:center; border:1px solid #ccc; border-radius:10px'>Something went wrong, please try again!</div>";
           $('#search_results').html(page);
        }
    });
  });
//});

//AUTOUPDATE VOTES
//$(document).ready(function(){
function strShortener(value=this.data){
  if(value.length==4){
    var nV=value.slice(-3,);
    var x=value.slice(-3, -2);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'K');
  return newValue;
  }
  else if(value.length<7 && value.length>4){
    var nV=value.slice(-3,);
    var x=value.slice(-3, -2);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'K');
  return newValue;
  }
  else if(value.length==7){
    var nV=value.slice(-6,);
    var x=value.slice(-6, -5);
     x==0?x='':x='.'+x; 
   
    var newValue=value.replace(nV, x+'M');
  return newValue;
  }
  else if(value.length<10 && value.length>7){
    var nV=value.slice(-6, );
    var x=value.slice(-6, -5);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'M');
  return newValue;
  }
  else if(value.length==10){
    var nV=value.slice(-9,);
     var x=value.slice(-9, -8);
    x==0?x='':x='.'+x; 
   
    var newValue=value.replace(nV, x+'B');
  return newValue;
  }
  else if(value.length<13 && value.length>10){
    var nV=value.slice(-9, );
    var x=value.slice(-9, -8);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'B');
  }
  else{var newValue=value;}
    return newValue;
};
    function updateClicks(choice='myvote'){
        $.ajax({
            url: 'views/int_btns.php',
            method: 'GET',
            data: {getVote: choice},
            dataType:'json',
            success: function(data){
                            $.each(data.fds, function() {
                              //grab like votes
                       var prevView = $("#nplay-"+this['d']).val();
                         if( parseInt(prevView) < parseInt(this['p']) ){
                           document.getElementById('xlike').play();
                           prevView=this['p'];
                         }

                         var banData=this['h'];
                         var empData=this['l'];

                         var ban="<sub style='color:#2196f3' id='b"+this['d']+"' class='nonreal'>"+strShortener(banData)+"</sub>";
                       $("#b"+this['d']).replaceWith( ban );
                         var emp="<sub style='color:#2196f3' id='e"+this['d']+"' class='emp'>"+strShortener(empData)+"</sub>";
                       $("#e"+this['d']).replaceWith( emp );
                         var nView="<label style='color:#2196f3' id='nnplay-"+this['d']+"'>"+strShortener(this['p'])+"</label>";
                       $("#nnplay-"+this['d']).replaceWith( nView );
                       //update it on the other side
                       var prevViewUpd="<input type='hidden' value='"+this['p']+"' id='nplay-"+this['d']+"'>";
                       $('#nplay-'+this['d']).replaceWith( prevViewUpd );

                        
                   });
            }
        });
    }
            updateClicks();
        setInterval(function(){
            updateClicks();
        }, 1000*20);
//});
///AUTOUPDATE ENDS HERE
