
 $(document).on('click','#search_needs_icon', function(){ 
    $('#search_needs_icon').hide();
    document.getElementById('search_needs_div').innerHTML = "<span><form id='search_need_data'><input type='search' name='search-need' id='search-need' class='form-control' style='background:#fff; width:100%; margin-left:auto; margin-right:aut0;' placeholder='Search needs...'/></form></span>";

    $("#assetsList").show();
    $("#rpt").hide();
    $("#rtn").hide();
    $("#req").hide();
    $("#userAssets").css({'color':'#f016eb', 'font-weight':'bold', 'padding':'2px 10px 2px 10px', 'background':'#fcf1f4', 'border-radius':'4px'});
   $("#reqHx, #rtnHx, #rptHx").css({'background':'#fff', 'padding':'2px 10px 2px 10px', 'color':'#000', 'font-weight':'normal'});

  });

//show info tips
/*function showInfo(){
  var infoMsg = '<strong>Correct order:</strong><br>Quantity, Size, Color, Shape, Origin, Material<br>e.g. Two big brown rectangular american wooden box. <a href="" style="font-style:italic;">learn more description</a>';
  var info ="<label onclick=$('.item-desc-info').hide() style='border-radius:10px; border:1px solid #f01e6b; position:fixed; z-index:5; background:#f01e6b; color:white; font-size:10px; width:200px; padding:5px;'>"+infoMsg+"</label>";
  $('#item-desc-info').replaceWith(info);
}
*/


/*function tripleclick(num){
  window.addEventListener('click', function(evt){
  if(evt.detail === num){
    alert(num+' clicks');
  }else{alert(evt.detail+' clicks....');}
  });
}
*/



//distress call feeder
    function distressCallToFeed(vid){
        $.ajax({
            url: 'includes/distressToFeed.inc.php',
            method: 'GET',
            data: {getVid: vid},
            dataType:'json',
            success: function(data){
                var dVideo ="<div style='margin-top:5px; margin-bottom:1px; width:100%;'><video controls style='width:100%; height:auto; border-radius:10px; aspect-ratio:4/3;' frameborder='0' allowfullscreen>"+
                  "<source src='videos/distress/"+data.dvUrl+".webm' />"+
               "</video></div>";

/*               if(document.getElementById('dTopFeed').child == null){
                document.getElementById('dTopFeed').innerHTML=dVideo;
                $('#dTopFeed').attr('id').replace('dTopFeed', '');
              }*/
            }
        });
    }

            distressCallToFeed();
        setInterval(function(){
            distressCallToFeed();
        }, 1000*5);

/*$(document).on('click', '#asset',function(){

  var selected = $('#asset :selected').val();//document.getElementById('report-typer').value;
     if(selected < 6 ){
           $('.assetimg').hide();
           $('.uniq-Id').hide();
           $('.vins').show();
        }
    else if(selected == 6 ){ 
           $('.assetimg').show();
           $('.uniq-Id').show();
           $('.vins').hide();
          $('#unique-Id').attr('placeholder', 'IMEI1 & IMEI2 separated by comma');
        }
     else if(selected > 6 ){ 
           $('.assetimg').show();
           $('.uniq-Id').show();
           $('.vins').hide();

          $('#unique-Id').attr('placeholder', 'enter the serial code');
        }


});
*/
/*function FDIorNot(value){
  if(value == 3){
    document.getElementById('heading').placeholder="Item name";
    $('#addFDIspec').replaceWith("<br><div class='input-group' style=''>"+
                                "<select name='currency' class='input-group-addon' style='border:.5px solid #ccc; border-radius:4px 0px 0px 4px; background-color:white;'>"+
                                  "<option value='₦'> Naira (₦) </option>"+
                                  "<option value='USD'>USD ($)</option>"+
                                  "<option value='£'>Pounds (£) </option>"+
                                  "<option value='€'>Euro (€) </option>"+
                                  "<option value='¥'>Yuan (¥) </option>"+
                                "</select>"+
                                "<input type='number' class='form-control peem' min='100' max='' name='worth' id='worth' value='' placeholder='Item worth?' style='border-right:0px; border-left:0px' required"+
                                      "pattern='^(?=.{10,})([\d]>=10)$'"+
                                          "title='Input must be only numeric characters.'/>"+
                                "<button style='border-radius:0px 4px 4px 0px; background-color:white; border:.5px solid #ccc' class='input-group-addon twoem'>.00</button>"+
                            "</div>");
  }
  if(value==1){
    $('.datalist').append("<option value='Thieves'>"+
                        "<option value='Kidnappers'>"+
                        "<option value='Wanna Kill Me'>"+
                        "<option value='Domestic violence'>"+
                        "<option value='Fire Outbreak'>"+
                        "<option value='Terrorists Invasion'>");
  }
  if(value==2){
    $('.datalist').append("<option value='Money'>"+
                        "<option value='Health'>"+
                        "<option value='Food'>"+
                        "<option value='Provision'>"+
                        "<option value='Errand'>"+
                        "<option value='Bill'>");
    }
  if(value==3){
    $('.datalist').append("<option value='Money'>"+
                        "<option value='TV set'>"+
                        "<option value='Food'>"+
                        "<option value='Provision'>"+
                        "<option value='Rug'>"+
                        "<option value='Phone'>");
    }
  

  if(value!=3){$('.addFDIspec').hide();}
}*/
