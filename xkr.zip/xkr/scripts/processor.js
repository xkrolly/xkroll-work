//request & report form submitters
//ajaxSubmitter('#otpCheck', '../../../includes/otpverifier.inc.php');
 var inputIdArr = []; var selectIdArr = [];
ajaxSubmitter('#profile_data', 'includes/setprofile.inc.php', selectIdArr, inputIdArr);

 var inputIdArr = ['heading']; var selectIdArr = [];
ajaxSubmitter('#request_data', 'includes/setrequest.inc.php', selectIdArr, inputIdArr);

 var inputIdArr = ['cityy', 'tel', 'file']; 
 var selectIdArr = [];
ajaxSubmitter('#retrieval_data', 'includes/retrievalprocessing.inc.php', selectIdArr, inputIdArr);

$(document).on('click','#reportBtn', function(){
var audioRec;
 var inputIdArr = []; var selectIdArr = [];
 if($('#report-type').val() == 1){ inputIdArr = ['item']; selectIdArr = ['report-type'];}
else if($('#report-type').val() == 2){inputIdArr = ['item', 'city']; selectIdArr = ['report-type'];}
else if($('#report-type').val() == 3 && $('#property').val() < 6){ inputIdArr = ['model', 'color', 'vin1', 'vin2', 'vin3']; selectIdArr = ['report-type', 'property', 'make'];}
else if($('#report-type').val() == 3 && $('#property').val() == 6){ inputIdArr = ['item']; selectIdArr = ['report-type', 'property'];}
else if($('#report-type').val() == 3 && $('#property').val() == 7){ inputIdArr = ['item']; selectIdArr = ['report-type', 'property'];}

audioRec = $('#myaudio').val();

if(audioRec!='' || $('#report-type').val() == 2){
ajaxSubmitter('#return_data', 'includes/setreturn.inc.php', selectIdArr, inputIdArr);
}else{
  document.getElementById('check_voicerec').innerHTML = "<span style='color:red; font-size:12px; font-style:italic;'>Provide a voicenote!</span>";
return false;
}
});

ajaxSubmitter('#settingFm', 'includes/setSettings.inc.php');

 var inputIdArr = ['contactF1', 'contactF2', 'contactFr1', 'contactFr2', 'contactS1', 'contactS2', 'contactN1', 'contactN2']; var selectIdArr = [];
ajaxSubmitter('#distress_data', 'includes/setdistress.inc.php', selectIdArr, inputIdArr);

 var inputIdArr = [];//'dur_', 'qtty_', 'uom_', 'uom2_']; 
 var selectIdArr = ['giftList'];
ajaxSubmitter('#addFDI_data', 'includes/setfdi.inc.php', selectIdArr, inputIdArr);
/*ajaxSubmitter('#claim_data', 'views/claimLoss.php');
*/

 var inputIdArr = [];
 var selectIdArr = [];
ajaxSubmitter('#verify_data', 'includes/verifier.inc.php', selectIdArr, inputIdArr);

 var inputIdArr = ['_username', '_passphrase', '_firstname', '_lastname', '_contact'];
 var selectIdArr = [];
ajaxSubmitter('#completeReg_data', 'includes/completeReg.inc.php');

$(document).on('click','#giftList', function(){
if($('#giftList :selected').val() == 1){
  $('#qNum').hide(); $('#uom').hide();
  $('#fileupload').css({'background':'#fff', 'border':'1px solid #ccc'});
  document.getElementById('fileupload').innerHTML="<input type='file' name='file[]' class='fdi-upload' multiple style='width:100%;' accept='video/*'/>";
}
else if($('#giftList :selected').val() !== 1){
  $('#qNum').show(); $('#uom').show();
  $('.fdi-upload').hide();
}

});


/*$(document).on('click','#qtty_btn', function(){
  event.preventDefault();
  var dur=$('#dNum').val(); 
  var uomd =$('#uomd').val(); 
  $('#dur_').val(dur);
  $('#uomd_').val(uomd);
  document.getElementById('qtty_btn').innerHTML=
            '<input inputmode="numeric" id="qNum" max="20" min="1" placeholder="Qtty" style="background:#eee; font-size:1em; padding:6px; border:1px solid #ccc;"/>'+
            '<select id="uomq" style="background:#eee; font-size:1em; padding:6px; border:1px solid #ccc;">'+
                '<option value="1">Pieces</option>'+
                '<option value="2">Cup</option>'+
                '<option value="3">Congo</option>'+
                '<option value="4">Bag</option>'+
                '<option value="5">Pairs</option>'+
                '<option value="6">Litres</option>'+
              '</select>'
          ;
});
*/

  $(document).on('click','#saveLoginData', function(){
     event.preventDefault();
       var pw=$('#pw').val();
       var pw2=$('#pw2').val();
       var un=$('#un').val();
  //   if(pw!='' && un!=''){
    if( pw==pw2 ){
       $('#completeRegFmDiv1').hide();
       $('#completeRegFmDiv2').show();
       $('#b1').css('background','#2196f3');
       $('#c2').css('background','#2196f3');
       var un=$('#un').val();
       var pw=$('#pw').val();
       $('#passphrase').val(pw);
       $('#username').val(un);

    }
    else{
//      alert('not possible');
       $('#pw').css('border', '1px solid red'); 
       $('#pw2').css('border', '1px solid red'); 
      document.getElementById('check_pw2, check_pw').innerHTML='<span style="color:red; font-size:10px;">Passwords do not match!</span>';

    }
/*  }else{
       $('#un').css('border', '1px solid red'); 
      document.getElementById('check_un').innerHTML='<span style="color:red; font-size:10px;">All form fields required!</span>';

  }
*/     
     
  });

  $(document).on('click','#saveLoginData2', function(){
     event.preventDefault();

     var un=$('#username').val();
     var pw=$('#passphrase').val();
     var fn=$('#fn').val();
     var sn=$('#sn').val();
     var pn=$('#contact').val();
     if(fn!='' && sn!='' && pn!=''){
         $('#completeRegFmDiv2').hide();
         $('#completeRegFmDiv3').show();
         $('#b2').css('background','#2196f3');
         $('#c3').css('background','#2196f3');
        

        document.getElementById('regDetail').innerHTML='<p>Firstname: '+fn+'</p>'+
            '<p>Lastname: '+sn+'</p>'+
            '<p>username: '+un+'</p>'+
            '<p>Password: *********</p>'+
            '<p>Whatsapp: '+pn+'</p>';
         
         $('#_passphrase').val(pw);
         $('#_username').val(un);
         $('#_firstname').val(fn);
         $('#_lastname').val(sn);
         $('#_contact').val(pn);
      }else{
        $('#fn').css('border', '1px solid red');
        $('#sn').css('border', '1px solid red'); 
        $('#contact').css('border', '1px solid red'); 
      document.getElementById('check_contact').innerHTML='<span style="color:red; font-size:10px;">All form fields required!</span>';

      }
  });

$(document).on('click', '#cancelRegFm', function(){
  $('#completeRegFmDiv2').show();
  $('#completeRegFmDiv3').hide();
     $('#b2').css('background','#eee');
     $('#c3').css('background','#eee');
  
  
})
$(document).on('click','#saveSettings', function(){
  ajaxSubmitter('#settingFm', 'views/setSettings.php');
});


//assist form submitter
  $(document).on('click','.assist', function(){
    // event.preventDefault();
  //   alert('what');
    var i4=$(this).prop('id').replace('channel4', '');
    var i3=i4.replace('channel3', '');
    var i2=i3.replace('channel2', '');
    var i=i2.replace('channel1', '');
    
    var inputIdArr = [i+'channel1']; var selectIdArr = [];
    ajaxSubmitter('#'+i+'assistForm', 'includes/assist.inc.php', selectIdArr, inputIdArr);
 
    $('#'+i+'assist').hide();
    $('.homeFeed'+i).hide('slow');
 });

$('.search_data').on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'includes/fetchSearch.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var type=data.type;
            var id='';
            var property='';
            var city='';
            var time='';
            var fn='';
            var ln='';
            var cii = '';
            var n_assist = '';
            var n_returns = ''; 
            var n_requests = '';
            var n_fdi = '';
            var n_impacts = '';
            var total='';
            var geoDist = '';
          
           if(type==1 || type==3 ){
              var id =data.id;
              var property =data.ppt;
              var city=data.city;
              var time=data.time;
              var description= data.description;
              var geoDist = data.geoDist;
            }
           if(type==4 ){
              var id =data.id;
              var property=data.item_list;
              var qtty = data.qtty;
              var time=data.time;
              var geoDist = data.geoDist;
            }
            if(type==2){
              var fn=data.fn;
              var ln=data.ln;
              var cii = data.cii;
              var rank = data.rank;
              var jd = data.jd;
              var n_assist = data.nAss;
              var n_returns = data.nRtn;
              var n_requests = data.nReq;
              var n_fdi = data.nFdi;
              var n_impacts = data.nImpacts;
            }
            var total =data.total;
            //$('#searchPanel').css('filter', 'drop-shadow(0px 0px 0px #aaa)');
            var page = '<div style="position:fixed; top:0; bottom:0%; overflow:auto; content-visibility:auto; z-index:18; background:#fff; width:100vw; padding:5px 20px 100px 20px;;">';
             page += '<div style="text-align:right;"><a href=""><i class="fa fa-times"></i></a></div>';
            if(total < 1){
              page += "<br><br><br><div style='color:red; font-size:20px; text-align:center;'>No match found !!</div>";
            }else{
                          if(type==3){page +='<div style="text-align:center;"><h5 style="padding:2px; font-size:22px;">Loss reports</h5>'+
                          '<p style="font-size:14px; margin-top:-10px; font-weight:bold;">Retrieve any and get 20% worth in compensation.</p></div>';}           

              while(total > 0){
                var cii_color='';
                cii[total-1] < 30 ? cii_color='red' : (cii[total-1] <= 60 ? cii_color='orange' : cii_color='green');
                  if(type==1){
                      page += "<div style='margin-top:10px;'><form method='post' action='claim' id='claim_data"+id[total-1]+"'>"+
                                  "<input type='hidden' name='fid' value="+id[total-1]+">"+
                      "<div style='color:#005; font-family:san-serif;'>"+
                          "<div style='display:flex;'>"+
                            "<div style='color:#2166f3; font-size:20px; font-weight:bold;'>"+property[total-1]+"</div>"+
                            "<div style='margin-left:auto'>"+time[total-1]+"</div>"+
                          "</div>"+
                          "<div style='display:flex;'>"+
                            "<span style='font-size:16px;'>Prove your ownership and Claim this <strong>"+property[total-1]+"</strong> by providing the city it was found.</span>"+
                            "<span style='margin-left:auto;'>"+
                            "<button type='submit' class='btn sm btnColor'>claim</button>"+
                            "</span>"+
                          "</div>"+
                        "</div>"+
                        "</form></div><hr>";
                    }
                    else if(type==2){
                      page += "<div style='color:#005; font-family:san-serif;'>"+
                          "<h6 style='color:#2166f3; font-weight:bold;'>"+fn[total-1]+" "+ln[total-1]+"<meter low='30' optimum='80' high='70' value='"+cii[total-1]+"' min='0' max='100' style='margin-left:10px;'></meter>&nbsp;<span style='color:"+cii_color+"; font-size:12px;'>"+cii[total-1]+"% CCII</span></h6>"+
                          "<span style='font-size:16px;'><span style='font-weight:bold;'>"+ln[total-1]+" "+fn[total-1]+"</span> is a "+rank[total-1]+" with "+n_impacts[total-1]+" impacts.<br>"+
                          "<div class='truncate' style='display:flex; margin-top:10px; margin-bottom:-5px; font-size:10px;'>"+n_requests[total-1]+" Requests</span><span style='font-size:10px; margin-left:10px;'>"+n_assist[total-1]+" Assists</span><span style='font-size:10px; margin-left:10px;'>"+n_fdi[total-1]+" Handouts</span><span style='font-size:10px; margin-left:10px;'>"+n_returns[total-1]+" Returns</span><span style='margin-left:auto'>"+jd[total-1]+"</span></div>"+
                        "</div><hr>";
                    }
                    else if(type==3){
                      page += "<div style='margin:10px auto -15px auto; background:#fff; filter:drop-shadow(1px 1px 1px #444);'>"+
                      "<form method='post' action='retrieval-detail'>"+
                                  "<input type='hidden' name='lid' value="+id[total-1]+">"+
                      "<div style='font-family:san-serif; padding:10px; border-radius:10px;'>"+
                         "<div style='display:flex; align-items:flex-end; justify-content:space-between; padding-left:20px; padding-right:20px;'>"+
                            "<div><div style='font-size:18px; font-weight:bold;'>"+property[total-1]+"<sub>"+geoDist[total-1]+"km</sub></div></div>"+
                            "<div><i class='fa fa-play' id='descBtn"+id[total-1]+"' onClick='playReport("+id[total-1]+")' style='margin-left:10px;'></i><audio class='audio' id='lossDesc"+id[total-1]+"'><source src='sounds/Loss/"+description[total-1]+".webm' type='audio/webm'></audio></div>"+
                            "<div>"+
                                "<button type='submit' class='btn' style='font-size:12px; padding:5px; border:0px;'>RETURN</button>"+
                            "</div>"+
                         "</div>"+
                      "</div>"+
                    "</form>"+
                  "</div><hr>";

                    }
                  else if(type==4){
                      page += "<div style='color:#005; margin-bottom:10px; border:1px solid #fff; border-radius:10px; padding:5px; background:#fff; display:flex; align-items:center; justify-content:center; filter: drop-shadow(2px 2px 1px #ddd) drop-shadow(-1px -1px 1px #eee);'>"+
                          "<div style='color:#2166f3; font-weight:bold;'>"+property[total-1]+"</div><div>"+qtty[total-1]+" cups</div>"+
                          "<div style='display:flex; align-items:center; justify-content:center; height:40px; width:40px;  border-radius:50%; background:#eee;'><div class='flex-center' style='font-size:14px;'>"+geoDist[total-1]+"<sub>Km</sub></div></div>"+
                          "<div style='display:flex column;' class='far-right'><div>"+time[total-1]+"</div><div><button class='btn btn-sm'>Accept</button></div></div>"+
                        "</div>";
                    }

                total--;
              }
            }
            page +='</div>';

          $('.homeFeed').hide();
          $('#setinPg').hide();

          $('#profilePg').hide();
          $('#req').hide();
          $('#rtn').hide();
          $('#rpt').hide();
          $('.rtnLxFm').hide();
          $('#search_results').html(page);
          $('.setBgWhite').css('background','#fff');
        },
        error: function(data){
           page = "<hr><div id='wrong' onclick=$('#wrong').hide() style='background-color:white; text-align:center; border:1px solid #ccc; border-radius:10px'>Something went wrong, please try again!</div>";
           $('#search_results').html(page);
        }
    });
  });

/*function grab_finder_info(id){
// onclick='grab_finder_info("+id[total-1]+")'
}
*/
function playReport(id){
$('audio').each(function(){
  this.pause();
})
//  document.getElementsByClassName('audio').pause();
//  $('.fa-play').pause();
  $('#descBtn'+id).removeClass('fa-play');
  $('#descBtn'+id).addClass('fa-pause');
  document.getElementById('lossDesc'+id).play();
$('audio').each(function(){
  this.pause();
})

}

/*$('.grabFDI').click(function(){
    var id=$(this).attr('id').replace('grabFDI', '');
    $('#grabFDI'+id).on('submit', function(event){
    event.preventDefault();
    $.ajax({
        url: 'views/grabFDI.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.setnReply;
          var bgcolor='#002';
          var respSelector='response';
          var id='';
 
          response(msg, bgcolor, id);
        },
    });
    });
    });
*/
/*  $(document).on('click','.commentBtn',function(){
     $('#commentForm').on('submit', function(event){
        event.preventDefault();

    $.ajax({
        url: 'includes/comment.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var comment=data.commentResp+' '+'~just now';
          if(comment!='failed'){
          var discussId = data.discussId;
          $('#commentBox').val('');
          var p = document.createElement("p");
          var node = document.createTextNode(comment);
          p.appendChild(node);
          var addCommentSpace = document.getElementById('addComment');
          var child = document.getElementById("commentOpener");
          addCommentSpace.insertBefore(p, child);
            $(window).scrollTop(100);
          }
          else{
            var msg='Attempt failed, please try again!';
            var bgcolor='red';
            var id='';
            response(msg, bgcolor, id);
          }
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          var id='';
          response(msg, bgcolor, id);
        }
      });
    });
  });
*/