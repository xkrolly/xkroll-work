
function validate(selectIdArray, inputIdArray){
var resp='';
 if(selectIdArray.length > 0){
   
    selectIdArray.forEach(function(id){
      if($('#'+id+' :selected').val()==''){
        resp += 1;
        document.getElementById('check_'+id).innerHTML = '<span style="color:red; font-size:12px; font-style:italic;">Select an option!</span>';
        $('#'+id).css('border','1px solid red');
      }else{document.getElementById('check_'+id).innerHTML =''; resp += 0;}
   
    });

  }
  
 if(inputIdArray.length > 0){
//alert(inputIdArray.length);
    inputIdArray.forEach(function(id){
      if($('#'+id).val()==''){
         document.getElementById('check_'+id).innerHTML = '<span style="color:red; font-size:12px; font-style:italic;">This field is empty!</span>';
        $('#'+id).css('border','1px solid red');
        resp += 1;
     }else{ document.getElementById('check_'+id).innerHTML =''; resp += 0;}
    });

  }
return resp;
}

function response(msg, bgcolor){
       var div = document.createElement("div");
          var node = document.createTextNode(msg);
          div.appendChild(node);
          var respPanel = document.getElementById('response');
          respPanel.appendChild(div);
          
        $('#response').css({'z-index':10, 'font-size':'16px', 'font-family':'roboto', 'border-radius':'5px', 'text-align':'center', 'padding':'5px', 'color':'#fff', 'background':bgcolor});

            setTimeout(function(){
                            $('#response').fadeOut();
                           setTimeout(function(){
                             respPanel.removeChild(div);
                            }, 50);    
                        }, 25000);
    }

//OTP signup 
$(document).ready(function(){
//ajaxSubmitter('#signup_data', 'includes/signup.inc.php');
  $('#signup_data').on('submit', function(event){
      event.preventDefault();
      $.ajax({
        url: 'infobipnew/src/sms/send-sms-basic.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var output=data.ajaxReply;
          var mobile = data.mobile;
//          var bgcolor='green';
          output == '1' ? bgcolor = 'green' : bgcolor ='red';
          output=='1' ? document.getElementById('otpVerifyFm').innerHTML=
          "<form id='otpCheck' method='post' action='includes/otpverifier.inc.php'>"+
          "<input type='text' autofocus name='otp' placeholder='Enter your OTP' style='padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-bottom-left-radius:50px; border-top-left-radius:50px; margin-top:10px; margin-bottom:10px;'/>"+
          "<input type='hidden' name='mobile' value='"+mobile+"' />"+
          "<button type='submit' style='background:#f01e6b; color:#fff; padding:10px; border-top-right-radius:50px; border-bottom-right-radius:50px; width:35%;'>Verify</button>"+
          "</form>" : '';

          output=='1' ? msg='Successful, enter your OTP above to verify your mobile.' : (output=='3' ? msg='This contact is a registered user' : (output == 4 ? msg='Fill in your mobile digit correctly and try again' : msg='Error occured, try again!')); 
          response(msg, bgcolor);
        },
        error: function(data){
          var bgcolor='red';
          var msg='Registration error, pls try again.';
          response(msg, bgcolor);
        }
      });
  });

});

function ajaxSubmitter(formToSubmit, processor_URL, selectIdArray, inputIdArray){
  $(formToSubmit).on('submit', function(event){
      event.preventDefault();
      //var sum = selectIdArray.length + inputIdArray.length;
      var check = validate(selectIdArray, inputIdArray);
//      alert(check);
if(check == 0){
      $.ajax({
        url: processor_URL,
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.ajaxReply;
          var bgcolor='#002';
          response(msg, bgcolor);
          $('#mdd').hide();
          $(formToSubmit)[0].reset();
        },
        error: function(data){
          var bgcolor='red';
          var msg='Failed try again.';
          response(msg, bgcolor);
        }
      });
    }
  });
}

/*SIGNUP */
/*$(document).ready(function(){
//ajaxSubmitter('#signup_data', 'includes/signup.inc.php');
  $('#signup_data').on('submit', function(event){
      event.preventDefault();
      $.ajax({
        url: 'includes/signup.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.ajaxReply;
          var bgcolor='#002';
          response(msg, bgcolor);
          $('#signup_data')[0].reset();
        },
        error: function(data){
          var bgcolor='red';
          var msg='Registration is currently on hold, pls check back later.';
          response(msg, bgcolor);
        }
      });
  });

});
*/


$(document).ready(function(){
$('#login_data').on('submit', function(event){
    event.preventDefault();
  // $(document).on('click','#loginbtn', function(){ 
      if( $('#uname').val()==''){
           document.getElementById('uname-input-check').innerHTML="<span style='color:red; font-size:12px;'>Input username!</span>";
             $('#uname').css('border', '1px solid red');
        }
       if( $('#pwd').val()==''){
           document.getElementById('pwd-input-check').innerHTML="<span style='color:red; font-size:12px;'>Input password!</span>";
             $('#pwd').css('border', '1px solid red');
        }

// });

                  
  /*  var uname=$('#uname').val();
    var pwd=$('#pwd').val();
*/
if( $('#uname').val() !=='' && $('#pw').val() !==''){
      
    $.ajax({
        url: 'includes/login.inc.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            if(data.url=='login'){
              window.location.href='home';
            }else{
          var msg= data.ajaxReply;
          var bgcolor='#002';
          var id=data.id;
          response(msg, bgcolor);
          }
        },
        error: function(data){
            $('#login_data')[0].reset();
          var msg='Sorry, You cannot be logged in now, please check your internet and try again!';
          var bgcolor='red';
          var id=data.id;
          response(msg, bgcolor);
        }
      });
  }

  });
});
