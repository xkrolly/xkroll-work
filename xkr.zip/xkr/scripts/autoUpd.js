   function animate(i){
        $(i).toggleClass('bounce');
        $(i).css('font-size','3px');
        setTimeout(function(){
               setTimeout(function(){
                    $(i).toggleClass('bounce');
                    $(i).css('font-size','25px');
               }, 600);    
            }, 600);    
   }

  function animate3(i){
      var sound="<audio id='xban' volume='60'>"+
                  "<source src='sounds/ban.mp3' type='video/webm'>"+
                "</audio>";
  }

  $(document).on('click','.ban',function(){
    var id=$(this).prop('id').replace('ban', '');         
    var tid=$('#tid').val();
    var banAll=$('#'+id+'banAll').val(); 
    var clicked = $('#clicked'+id).val();

    var i='#icon2'+id;
    animate3(i);
    var eColor='#929292'; var bColor='#000';
    var b='';
    var ban_upd='';
    clicked == 2 ? ban_upd = parseInt(banAll) : 
    ban_upd = parseInt(banAll) + 1;
    clicked == 2 ? bColor = '#929292' : bColor = bColor;
   

    $(i).css('-webkit-text-stroke-color', bColor);
    $('#icon'+id).css('-webkit-text-stroke-color', eColor);     
    
    var prev_ban="<sub id='b"+id+"' style='color:#2166f3'>"+ban_upd+"</sub>";
    $('#b'+id).replaceWith(prev_ban);

    //empty clicked value
    clicked == 2 ? $('#clicked'+id).val(0) : 
    $('#clicked'+id).val(2);

        $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:2},
          dataType:'json',
          
          success: function(data){
           var banData=(data.upd_ban).replace('-', '');
           var empData=(data.upd_emp).replace('-', '');
           var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
           var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

          $('#e'+data.id).replaceWith(upd_emp);
          $('#icon'+data.id).css('-webkit-text-stroke-color', '#929292');
          $('#b'+data.id).replaceWith(upd_ban);
          $('#icon2'+data.id).css({'-webkit-text-stroke-color':'#000', 'font-size':'20'});
        },

        }); 
      });

$(document).on('click','.emp', function(){
    
    var id=$(this).prop('id').replace('emp', '');         
    var tid=$('#tid').val();
    var empAll=$('#'+id+'empAll').val();         
    var clicked = $('#clicked'+id).val();

    var i='#icon'+id;
    animate(i);
    var eColor='red'; var bColor='#929292';
    var e='';
    
    clicked == 1 ? emp_upd = parseInt(empAll) : 
    emp_upd = parseInt(empAll) + 1;
    
    clicked == 1 ? eColor = '#929292' : eColor = eColor;
   
    $('#icon2'+id).css('-webkit-text-stroke-color', bColor);
    $(i).css('-webkit-text-stroke-color', eColor);


    var prev_emp="<sub class='e"+id+"' id='e"+id+"' style='color:#2166f3'>"+emp_upd+"</sub>";
    $('#e'+id).replaceWith(prev_emp);

    //empty clicked value
    clicked == 1 ? $('#clicked'+id).val(0) : 
    $('#clicked'+id).val(1);

    $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:1 },
          dataType:'json',
      success: function(data){
         var banData=(data.upd_ban).replace('-', '');
         var empData=(data.upd_emp).replace('-', '');

        var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
        var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

        $('#b'+data.id).replaceWith(upd_ban);
        $('#icon2'+data.id).css('-webkit-text-stroke-color', '#929292');

        $('#e'+data.id).replaceWith(upd_emp);
//        $('#icon'+data.id).css('-webkit-text-stroke-color', 'red');
        $('#icon'+data.id).css({'-webkit-text-stroke-color':'red', 'font-size':'20'});

      },

    });   
  });


    function updateClicks(choice='myvote'){
        $.ajax({
            url: 'views/int_btns.php',
            method: 'GET',
            data: {getVote: choice},
            dataType:'json',
            success: function(data){
                            $.each(data.fds, function() {
                              //grab like votes
                          var prevView = $("#nplay-"+this['d']).val();
                         if( parseInt(prevView) < parseInt(this['p']) ){
                           document.getElementById('xlike').play();
                           prevView=this['p'];
                         }

                         var banData=this['h'];
                         var empData=this['l'];
                         var ban="<sub style='color:#2196f3' id='b"+this['d']+"' class='nonreal'>"+strShortener(banData)+"</sub>";
                       $("#b"+this['d']).replaceWith( ban );
                         var emp="<sub style='color:#2196f3' id='e"+this['d']+"' class='emp'>"+strShortener(empData)+"</sub>";
                       $("#e"+this['d']).replaceWith( emp );
                         var nView="<label style='color:#2196f3' id='nnplay-"+this['d']+"'>"+strShortener(this['p'])+"</label>";
                       $("#nnplay-"+this['d']).replaceWith( nView );
                       //update it on the other side
                       var prevViewUpd="<input type='hidden' value='"+this['p']+"' id='nplay-"+this['d']+"'>";
                       $('#nplay-'+this['d']).replaceWith( prevViewUpd );
                   });
            }
        });
    }
            updateClicks();
        setInterval(function(){
            updateClicks();
        }, 1000*20);