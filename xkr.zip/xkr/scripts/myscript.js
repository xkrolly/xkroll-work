
/*setTimeout(function(){
                       $('#initA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                               setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 2);

});*/




var pg="<div style='background-color:black; opacity:.6'></div>";
    function response(msg, bgcolor, fmHide, respFade){
       $('#'+fmHide).modal('hide');
        $('#'+respFade).html(msg);
              setTimeout(function(){
                $('#'+respFade).fadeOut('slow')
                    setTimeout(function(){
                  }, 50);    
               }, 15000);
    }

//complete reg
$(document).ready(function(){
//$(document).on('submit','#saveStn',function(){
  $('#completeReg').on('submit', function(event){
    event.preventDefault();
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/completeReg.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.cRegReply;
//        $('.setnResp'+x).html("<div id='setnResp"+x+"' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:40%; right:40%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                           $('.compReg').hide();
                     
                    setTimeout(function(){
                                    $('.interest').fadeIn('slow')
                        }, 4000);
      }
    }); 
  });
});

/* $(window).on('load', function(event){
function notifyUser(msg){
             $('#noGeo').html(pg+'<div id="noGeo" class="" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; top:15%; margin-left:auto; margin-right:auto; padding:10px; color:#ff00e2; background-color:#fff">'+msg+'</div>');
           setTimeout(function(){
                         $('#noGeo').fadeOut('slow')
                        }, 8000);
          }
  
     setTimeout(function(){
           var geoCheck='x';
     $.ajax({
          type: 'POST',
          url: 'views/geoCheck.php',
          data: { geoCheck: geoCheck},
          dataType:'json',
      success: function(data){
          var geoResp=data.geoResp;
          var msg="Put on your device location ( <i class='fa fa-map-marker' style='color:#2166f3'></i> ) to use this app!";
          if(data.geoResp=='0'){
            notifyUser(msg);
          }
      },    
    });
   }, 10000);
        
  });
*/
/*$(document).ready(function(){
    alert('I am nlow fully loaded');backToOptions
  });
*/

$(document).ready(function(){
    $(document).on('click','.sendContact',function(){
      $('.assistMedium').hide();
      $('.helper_tel').show();
      $('#backToOptList').show();
    });
    $(document).on('click','.chatUp',function(){
      $('.assistMedium').hide();
      $('.chatMedium').show();
      $('#backToOptList').show();
    });
    $(document).on('click','#backToOptList',function(){
      $('.assistMedium').show();
      $('.chatMedium').hide();
      $('.helper_tel').hide();
      $('#backToOptList').hide();
    });
});

$(document).ready(function(){

  function animate3(i){
    document.getElementById('xban').play();
  }

    $(document).on('click','.ban',function(){
         //alert('You considered the request unrealistic!');
 var id=$(this).prop('id').replace('did-', '');         
       var tid=$('#tid').val();
       id!='' ? document.getElementById('xban').play() :  document.getElementById('xban').pause();
       
       var _m=$('#'+id+'emp_s').val();         
       var _b=$('#'+id+'ban_s').val();
       var clicked=$('#clicked'+id).val();
        if(_b >=12){ $('#aud_auto'+id).hide('slow');}
       
       var e=''; var b='';
       clicked==1 ? b+='1' : (clicked==2 ? b+='-1' : b+='1');
       clicked==1 ? e+='-1' : (clicked==2 ? e+='0' : e+='0');
  
  var i='#nban'+id;

   animate3(i);
   var eColor='#929292'; var bColor='';
   b=='1' ? bColor+='#ff00e2' : bColor+='#929292';

 $('#nemp'+id).css('webkit-text-stroke-color', eColor);//6
   $(i).css('webkit-text-stroke-color', bColor);//7     
  
_m>0 ? e=e : e=0;
_b>0 ? b=b : b=1;

clicked==2? $('#clicked'+id).val('') : $('#clicked'+id).val(2);// 1

 emp_upd=parseInt(_m)+parseInt(e);
 ban_upd=parseInt(_b)+parseInt(b);
var prev_emp="<sub class='e"+id+"' id='e"+id+"' style='color:#2166f3'>"+emp_upd+"</sub>";
var prev_ban="<sub class='b"+id+"' id='b"+id+"' style='color:#2166f3'>"+ban_upd+"</sub>";

$('#'+id+'emp_s').val(emp_upd);//2
$('#'+id+'ban_s').val(ban_upd);//3
//update each on the page;
$('#e'+id).replaceWith(prev_emp);//4
$('#b'+id).replaceWith(prev_ban);//5
var ban=2;

//THE END

/*        var id=$(this).prop('id').replace('did-', '');         
        var tid=$('#tid').val();
        var nreal=$('#'+id+'ban_s').val();
       var m=$('#'+id+'emp_s').val();         
        var ban=2;
var i='#nban'+id;
       $('#nemp'+id).css('webkit-text-stroke-color','#929292');
        if(nreal >=12){ $('#aud_auto'+id).hide('slow');}

        animate3(i);
*/        $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:ban},
          dataType:'json',
      success: function(data){

         var banData=(data.upd_ban).replace('-', '');
         var empData=(data.upd_emp).replace('-', '');
                        
        var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
        var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

        $('#e'+data.id).replaceWith(upd_emp);
        $('#b'+data.id).replaceWith(upd_ban);
       var clicked=$('#clicked'+id).val(); var _bColor='';
      clicked==''? _bColor+='#828282' : _bColor='#ff00e2';
       $('#nban'+data.id).css('webkit-text-stroke-color', _bColor);

        },

        }); 
      });
});

//rxt btn
$(document).ready(function(){
function animate(i){
        $(i).toggleClass('bounce');
        $(i).css('font-size','3px');
        setTimeout(function(){
               setTimeout(function(){
                    $(i).toggleClass('bounce');
                    $(i).css('font-size','20px');
               }, 600);    
            }, 600);    
}


    $(document).on('click','.emp',function(){
       var id=$(this).prop('id').replace('did2-', '');         
       var tid=$('#tid').val();
       var empathy=1;
       id!='' ? document.getElementById('heart').play() :  document.getElementById('heart').pause();
       
       var _m=$('#'+id+'emp_s').val();         
       var _b=$('#'+id+'ban_s').val();
       var clicked=$('#clicked'+id).val();
       
       var e=''; var b='';
       clicked==2 ? e+='1' : (clicked==1 ? e+='-1' : e+='1');
       clicked==2 ? b+='-1' : (clicked==1 ? b+='0' : b+='0');
  var i='#nemp'+id;
   animate(i);
   var eColor=''; var bColor='#929292';
   e=='1' ? eColor+='red' : eColor+='#929292';

 $('#nban'+id).css('webkit-text-stroke-color', bColor);//6
   $(i).css('webkit-text-stroke-color', eColor);//7     
  
_m>0 ? e=e : e=1;
_b>0 ? b=b : b=0;

clicked==1? $('#clicked'+id).val('') : $('#clicked'+id).val(1);// 1

 emp_upd=parseInt(_m)+parseInt(e);
 ban_upd=parseInt(_b)+parseInt(b);
var prev_emp="<sub class='e"+id+"' id='e"+id+"' style='color:#2166f3'>"+emp_upd+"</sub>";
var prev_ban="<sub class='b"+id+"' id='b"+id+"' style='color:#2166f3'>"+ban_upd+"</sub>";

$('#'+id+'emp_s').val(emp_upd);//2
$('#'+id+'ban_s').val(ban_upd);//3
//update each on the page;
$('#e'+id).replaceWith(prev_emp);//4
$('#b'+id).replaceWith(prev_ban);//5

        $.ajax({
          type: 'POST',
          url: 'views/votes.php',
          data: { donation_id: id, tid:tid, vote:empathy },
          dataType:'json',
      success: function(data){
  
//        var d_id=data.id;
  
 //       var upd_emp=data.upd_emp; 
         var banData=(data.upd_ban).replace('-', '');
         var empData=(data.upd_emp).replace('-', '');

        var upd_emp=" <sub class='e"+data.id+" emp_votes' id='e"+data.id+"' style='color:#2196f3'>"+empData+"</sub>";
        var upd_ban=" <sub class='b"+data.id+" ban_votes' id='b"+data.id+"' style='color:#2196f3'>"+banData+"</sub>";

        $('#e'+data.id).replaceWith(upd_emp);
        //var upd_ban=data.upd_ban; 
        $('#b'+data.id).replaceWith(upd_ban);

       var clicked=$('#clicked'+id).val(); var _eColor='';
      clicked==''? _eColor+='#828282' : _eColor='red';
       $('#nemp'+data.id).css('webkit-text-stroke-color', _eColor);
        },

        });

      });
    });

//big play btn
$('.play').on('click', function(){
   var i=$(this).prop('id').replace('play-', '');
      var id='u_note'+i;
      var playedB4=$('#Clikplay'+i).val();
      _played_n=$('#nplay-'+i).val();
      var played_n=parseInt(_played_n)+1;
      var nnplay="<label class='nnplay-"+i+"' id='nnplay-"+i+"' style='color:#2196f3'>"+played_n+"</label>";
      $('#nnplay-'+i).replaceWith(nnplay);
         if($('#'+id).length>0){
     //start
       var click=+$(this).data('clicks') || 0;
        if(click % 2 == 0){
        var proof=$('#proof'+i).val();
      document.getElementById(id).innerHTML = "<source src='user_notes/"+proof+".wav' type='video/webm'>";
      document.getElementById(id).play();
        $('#playBtn'+i).removeClass('fa-play');
      $('#playBtn'+i).addClass('fa-pause');
        if(playedB4==0){
          $('#Clikplay'+i).val(1);
              $.ajax({
          type: 'POST',
          url: 'views/nPlayed.php',
          data: { donation_id: i },
      
        });
       }
  
      }
        else{
      document.getElementById(id).pause();
              $('#playBtn'+i).removeClass('fa-pause');
      $('#playBtn'+i).addClass('fa-play');
        };
        $(this).data('clicks',click+1);
      }
});


//var refr;
//$(window).scrollTop()==$(this).offset().top ? refr=1 : refr=0;
$.fn.isInViewport = function(){
  var elementTop= $(this).offset().top;
  var elementBottom= elementTop + $(this).outerHeight();

  var viewportTop= $(window).scrollTop();
  var viewportBottom = viewportTop + $(window).height();
  var m=$(window).height()/2;
  return elementBottom > (viewportTop+m) && elementTop < (viewportBottom-m);
  };

$(window).on('resize scroll', function(){
    $('.aud_auto').each(function(){
  var id=$(this).attr('id').replace('aud_auto', '');
  var fd_id=$(this).attr('id').replace('fd', '');
  
  var auto=$('#autoplay'+id).val();
  var proof=$('#proof'+id).val();
  var ms=$('#media_setins'+id).val();
  if($(this).isInViewport()){
    if(auto==1){
         if($('#u_note'+id).length>0){
            if(ms==3 || ms==5){document.getElementById('u_note'+id).innerHTML = "<source src='user_notes/"+proof+".wav' type='video/webm'>";
          document.getElementById('u_note'+id).play();}}
    }
    else{
      if($('#u_note'+id).length>0){document.getElementById('u_note'+id).pause();}
    }
  
//on the fly loading down here
    if(fd_id > 15){
      //load nxt twenty feeds
      alert('remain 5 down the line');
    }
  }
  

   });
  });

//Return info
$(document).on('click','#rptLx', function(){ 
    $(".rptLxFm").show();
    $(".rtnLxFm").hide();
    $("#rptLx").css('border','2px inset red');
    $("#rtnLx").css('border','2px inset #eee');
    $("#rFm").load('views/report-loss.php')
  });

//Return info
$(document).on('click','#rtnLx', function(){ 
    $(".rtnLxFm").show();
    $(".rptLxFm").hide();
    $("#rptLx").css('border','2px inset #eee');
    $("#rtnLx").css('border','2px inset green');
      $("#rFm").load('views/returns.php')
  });


$(document).on('click','#rptHx', function(){ 
    $("#rpt").show();
    $("#rtn").hide();
    $("#req").hide();
    $("#rptHx").css('color', '#fff');
    $("#rptHx").css('background-color','#ff00e2');
    $("#reqHx").css('color', 'black');
    $("#reqHx").css('background-color','#fff');
    $("#rtnHx").css('color', 'black');
    $("#rtnHx").css('background-color','#fff');
  
  });
 $(document).on('click','#rtnHx', function(){ 
    $("#rpt").hide();
    $("#rtn").show();
    $("#req").hide();
    $("#rtnHx").css('color', '#fff');
    $("#rtnHx").css('background-color','#ff00e2');
    $("#rptHx").css('color', 'black');
    $("#rptHx").css('background-color','#fff');
    $("#reqHx").css('color', 'black');
    $("#reqHx").css('background-color','#fff');
  
  });
 $(document).on('click','#reqHx', function(){ 
    $("#rpt").hide();
    $("#rtn").hide();
    $("#req").show();
    $("#reqHx").css('color', '#fff');
    $("#reqHx").css('background-color','#ff00e2');
    $("#rtnHx").css('color', 'black');
    $("#rtnHx").css('background-color','#fff');
    $("#rptHx").css('color', 'black');
    $("#rptHx").css('background-color','#fff');
  });

$(document).ready(function(){
      $("#helpmeLogo").remove();
         $(document).on('click','.logoshow',function(){
  $("#helpmeLogo").html('<span class="tracus hlogo" id="helpmeLogo" style="font-size:2em; padding-left:.5em; font-weight:bold; font-family:roboto">helpme</span>');
      
           });
       
 });
$(document).ready(function(){
$('#recorder').click(function(event){
startRec();
//recMeter();
//useAud();
function startRec(){
let device= navigator.mediaDevices.getUserMedia({ audio: true });
  let chunks = [];
  let recorder;
  device.then(stream => {
    recorder = new MediaRecorder(stream);

    recorder.ondataavailable = e => {
      chunks.push(e.data);

      if(recorder.state == 'inactive'){
        let blob = new Blob(chunks, {type: 'audio/webm' });
//        document.getElementById('audio').src = URL.createObjectURL(blob);
   var ad=URL.createObjectURL(blob); //URL.createObjectURL(blob)
   //start
   var xhr=new XMLHttpRequest();
   xhr.onload=function(e){
    if(this.readState===4){
      console.log("Server returned: ",e.target.responseText);
    }
   };
   var fd=new FormData();
   fd.append("audio_data",blob,"note");
   xhr.open("POST","views/aud_upload.php",true);
   xhr.send(fd);
   //stop
   document.getElementById('audio').innerHTML = '<source src="'+ad+'" type="video/webm" />';
          $('#myaudio').val(ad);
      }
    }
    recorder.start(1000);
  });
  setTimeout(() => {
    recorder.stop();
$('#audioMeter').replaceWith('<div><center><audio id="audio" controls style="width:80%"></audio></center></div>');
         $('#aud').css('background-color','white');
          $('#recorder').css('color','#aaa');
          $('.mic').hide();
                //$('#myaudio').val('src');
    
          document.getElementById('s4').play();

  }, 16000);

}


  $('#aud').css('background-color','gold');
  $('#recorder').css('color','white');
  $('#aud_reader').show();
  $('.mic').hide();
        
//////////////////////////

setTimeout(function(){
                       $('#initA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#initA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 2);

 setTimeout(function(){
                       $('#oneA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#oneA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#oneA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 2000);

setTimeout(function(){
                           $('#twoA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#twoA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#twoA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 3000);
setTimeout(function(){
                           $('#threeA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#threeA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#threeA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 4000);
setTimeout(function(){
                           $('#fourA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#fourA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#fourA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 5000);
setTimeout(function(){
                           $('#fiveA').css("color","#ff00e2");
                         setTimeout(function(){
                           $('#fiveA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                       $('#fiveA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 200);  
                    }, 6000);

setTimeout(function(){
                       $('#sixA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#sixA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#sixA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 7000);
setTimeout(function(){
                       $('#sevenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#sevenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#sevenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 8000);
setTimeout(function(){
                       $('#eightA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#eightA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#eightA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 9000);
setTimeout(function(){
                       $('#nineA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#nineA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#nineA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 10000);
setTimeout(function(){
                       $('#tenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#tenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#tenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 11000);
setTimeout(function(){
                       $('#elevenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#elevenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#elevenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 12000);
setTimeout(function(){
                       $('#twelveA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#twelveA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#twelveA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 13000);
setTimeout(function(){
                       $('#thirteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#thirteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#thirteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 14000);
setTimeout(function(){
                       $('#fourteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#fourteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#fourteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 15000);
setTimeout(function(){
                       $('#fifteenA').css("color","#ff00e2");
                             setTimeout(function(){
                           $('#fifteenA').css("color","#ff00e2");
                    
                               setTimeout(function(){
                           $('#fifteenA').css("color","#ff00e2");
                                   
                                }, 17000);    
                            }, 1);  
                    }, 16000);


  document.getElementById('s4').play();
});

});

$(document).ready(function(){
useAud();
function useAud(){
        $(document).on('click','#useAudio',function(){
          $('#useAudio').css('font-size','30px');
          
          $('#textRec').remove();
          $('#audioRec').show();

        });
      }


});
//big play btn
$('.fa-play').on('click', function(){
   var i=$(this).prop('id').replace('playBtn', '');
      var id='u_note'+i;
         if($('#'+id).length>0){
     //start
       var click=+$(this).data('clicks') || 0;
        if(click % 2 == 0){
        var proof=$('#proof'+i).val();
      document.getElementById(id).innerHTML = "<source src='user_notes/"+proof+".wav' type='video/webm'>";
      document.getElementById(id).play();
        $('#playBtn'+i).removeClass('fa-play');
      $('#playBtn'+i).addClass('fa-pause');
  
        }
        else{
      document.getElementById(id).pause();
              $('#playBtn'+i).removeClass('fa-pause');
      $('#playBtn'+i).addClass('fa-play');
        };
        $(this).data('clicks',click+1);
      }
});

//rtn nav
$(document).ready(function(){
 $(document).on('dblclick','.rtnNav',function(){
   window.location.href='index.php?page=returns';
   jQuery(window).load(function(){
      $('#rtn-i').hide('slow');//css('color','#ff00e2');
   })
 });  
});
$(document).ready(function(){
 $(document).on('dblclick','.fa-bell',function(){
           $('.fa-bell').replaceWith('GO');//  css('color','#ff00e2');
   
   jQuery(window).load(function(){
           $('.fa-bell').replaceWith('GO');//  css('color','#ff00e2');
   
    setTimeout(function () {
           $('.fa-bell').replaceWith('GO');//  css('color','#ff00e2');
    }, 5000);
   })
 });
});

//cadres_data
$(document).ready(function(){
  $('#cadres_data').on('submit', function(event){
    event.preventDefault();
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/profUpdate.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.cadresReply;

        $('#cadres').modal('hide');
            //var kantri="<span style='background-color:yellow'>".data.kantri."</span>";
    
        var city="<span style='background-color:yellow'>"+data.city+"</span>";
        var contact="<span style='background-color:yellow'>"+data.contact+"</span>";
        var mail="<span style='background-color:yellow'>"+data.mail+"</span>";
        $('#mycity').html(city);
        $('#mycontact').html(contact);
        $('#mymail').html(mail);
        $('#adresResp').html("<div id='adresResp' class='' style='z-index:1; border-radius:5px; text-align:center; position:fixed; left:20%; top:15%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#adresResp').fadeOut('slow')
                        }, 5000);
      },
      error: function(data){
        var reply=data.cadresReply;
        $('#cadres').modal('hide');
        $('#adresResp').html("<div id='adresResp' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; top:15%; left:20%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#adresResp').fadeOut('slow')
                        }, 5000);
      }
    }); 
   });
});

//acct info_data
$(document).ready(function(){
  $('#acct_data').on('submit', function(event){
    event.preventDefault();
    $.ajax({
      type: 'POST',
      url: 'views/profUpdate.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.acctReply;
        $('#acct_info').modal('hide');
    
        var un="<span style='background-color:yellow'>"+data.un+"</span>";
        var pw="<span style='background-color:yellow'>"+data.pw+"</span>";
        $('#mypw').html(pw);
        $('#acctResp').html("<div id='acctResp' class='' style='z-index:1; border-radius:5px; text-align:center; position:fixed; left:20%; top:15%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
        setTimeout(function(){
                         $('#acctResp').fadeOut('slow')
                        }, 5000);
      },
      error: function(data){
        var reply=data.acctReply;
        $('#acct').modal('hide');
        $('#acctResp').html("<div id='acctResp' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; top:15%; left:20%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>"+reply+"</div>");
        setTimeout(function(){
                         $('#acctResp').fadeOut('slow')
                        }, 5000);
      }
    }); 
   });
});

//profile update
$(document).ready(function(){
  $('#pinfo_data').on('submit', function(event){
    event.preventDefault();
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/profUpdate.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.profReply;

        $('#pinfo').modal('hide');
            //var kantri="<span style='background-color:yellow'>".data.kantri."</span>";
    
        var country="<span style='background-color:yellow'>"+data.country+"</span>";
        var dob="<span style='background-color:yellow'>"+data.dob+" Years</span>";
        var gender="<span style='background-color:yellow'>"+data.gender+"</span>";
        $('#mycountry').html(country);
        $('#mydob').html(dob);
        $('#mygender').html(gender);
        $('#profResp').html("<div id='profResp' class='' style='z-index:1; border-radius:5px; text-align:center; position:fixed; left:20%; top:15%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#profResp').fadeOut('slow')
                        }, 5000);
      },
      error: function(data){
        var reply=data.profReply;
        $('#pinfo').modal('hide');
        $('#profResp').html("<div id='profResp' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; top:15%; left:20%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#profResp').fadeOut('slow')
                        }, 5000);
      }
    }); 
   });

//profile pic
$(document).ready(function(){
  $('#ppic_data').on('submit', function(event){
    event.preventDefault();
$('#myprofpic').change(function(){
  var file=this.files[0];
  var fileType=file.type;
  var match=['image/jpeg', 'image/png', 'image/jpg'];
    if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]))){
      alert('sorry, only jpg, jpeg & png files are allowed');
      $('#myprofpic').val('');
      return false;
    }
});

    $.ajax({
      type: 'POST',
      url: 'views/profUpdate.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.profReply;
        $('#ppic').modal('hide');
        $('#profResp').html("<div id='profResp' class='' style='z-index:1; border-radius:5px; text-align:center; position:fixed; left:20%; top:15%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#profResp').fadeOut('slow')
                          location.reload();
                        }, 5000);
      },
      error: function(data){
        var reply=data.profReply;
        $('#ppic').modal('hide');
        $('#profResp').html("<div id='profResp' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; top:15%; left:20%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#profResp').fadeOut('slow')
                        }, 3000);
      }
    }); 
   });
 });

//social media detail update
  $('#social_data').on('submit', function(event){
    event.preventDefault();
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/profUpdate.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.smReply;

        $('#social_info').modal('hide');
    
        var fb="<span style='background-color:yellow'>"+data.fb+"</span>";
        var twt="<span style='background-color:yellow'>"+data.twt+"</span>";
        var linkedin="<span style='background-color:yellow'>"+data.li+"</span>";
        var ins="<span style='background-color:yellow'>"+data.ins+"</span>";
        $('#myfb').html(fb);
        $('#mytwt').html(twt);
        $('#myli').html(linkedin);
        $('#myins').html(ins);
        $('#smResp').html("<div id='smResp' class='' style='z-index:1; border-radius:5px; text-align:center; position:fixed; left:20%; top:15%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#smResp').fadeOut('slow')
                        }, 5000);
      },
      error: function(data){
        var reply=data.smReply;
        $('#social_info').modal('hide');
        $('#smResp').html("<div id='smResp' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; top:15%; left:20%; right:20%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#smResp').fadeOut('slow')
                        }, 5000);
      }
    }); 
   });
  });


//search processor
$(document).ready(function(){
        $(document).on('click','.claim',function(){
  
    var i=$(this).prop('id').replace('c', '');         
  $('#'+i+'search_data').on('submit', function(event){
        event.preventDefault();
    var asset_id=$('#asset_id').val();
    var fid=$('#found_id').val();
    var city=$('#city').val();
        $('#'+i+'claim_modal').modal('show');
    });
  });

        $(document).on('click','.verify',function(){
  
    var i=$(this).prop('id').replace('v', '');         

    $('#'+i+'verify_data').on('submit', function(event){
        event.preventDefault();
       function response(msg, bgcolor){
             $('#'+i+'claim_modal').modal('hide');
             $('#'+i+'successVer').html('<div id="'+i+'successVer" class="" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; top:15%; margin-left:auto; margin-right:auto; padding:10px; color:#fff; background-color:'+bgcolor+'">'+msg+'</div>');
           setTimeout(function(){
                         $('#'+i+'successVer').fadeOut('slow')
                        }, 8000);
          }
    
    $.ajax({
        url: 'views/verify.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var msg=data.verResp;
            var bgcolor='#2196f3';
            response(msg, bgcolor);
        //$('#return_data').[1].reset();
        },
        error: function(data){
            var msg='Sorry! filing loss report failed, try again.';
            var bgcolor='red';
            response(msg, bgcolor);
        }
        });
      });

      });
   });

//});
//helpValidator
$(document).ready(function(){
$(document).on('click','.vali',function(){
   var id=$(this).prop('id').replace('vali', '');

  $('#vali_help'+id).on('submit', function(event){
        event.preventDefault();
        $('#i21modal'+id).modal('show');
          var select='';
          select+=$("input[name='help']:checked").val();
        var selected=select;
        if(selected==1 || selected==0 || selected==-1){
         $('#i21modal'+id).modal('show');
          $('#sOpt'+id).val(selected);
          var option;
          var areU='Are you sure you ';
          selected==1 ? option=areU+'were helped by the supposed helper?' : (selected==0 ? option=areU+'could not locate the prospective helper?' : option='<strong class="warning">'+areU+'were deceived by the help gesture?</strong>');
          $('#ioption'+id).html(option);
        }
        else{ $('#i21modal'+id).modal('hide');}
   });
  id;
  $('#helpValidatorFm'+id).on('submit', function(event){
    event.preventDefault();
    //$('#sOpt').val(selected);
          
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/helpValidator.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        $('#i21'+id).hide('slow');
        $('#donorAssess'+id).hide('slow');
        $('#i21modal'+id).modal('hide');
         $('#vali_help'+id)[0].reset();
       
        var reply=data.hvReply;
        $('#hvResp'+id).html("<div id='hvResp"+id+"' class='' style='z-index:1; border-radius:5px; opacity:.9; text-align:center; position:fixed; left:20%; right:20%; top:15%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#hvResp'+id).fadeOut('slow')
                        }, 5000);
      }
    }); 

  });
 
});
});

$(document).ready(function(){
//$(document).on('submit','#saveStn',function(){
  $('#settingFm').on('submit', function(event){
    event.preventDefault();
    //var id=$(this).prop('id');
   
    $.ajax({
      type: 'POST',
      url: 'views/saveSettings.php',
      data: new FormData(this),
      dataType:'json',
      contentType: false,
      cache: false,
      processData: false,
      success: function(data){
        var reply=data.setnReply;
        var x=data.x;
        $('.setnResp'+x).html("<div id='setnResp"+x+"' class='dropshadow' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:40%; right:40%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:#2196f3'>"+reply+"</div>");
                    
        setTimeout(function(){
                         $('#setnResp'+x).fadeOut('slow')
                        }, 1500);
      }
    }); 

  });
  });

//delete my req
$(document).ready(function(){
$(document).on('click','.delete',function(){
   var id=$(this).prop('id').replace('MyReq', '');
    $.ajax({
      type: 'POST',
      url: 'views/deleteMyReq.php',
      data: { donation_id: id},
      success: function(data){
        $('#'+id+'deleted').html("<div class='dropshadow' id="+id+"deleted' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:40%; right:40%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:red'>Deleted!</div>");
                    
        setTimeout(function(){
                         $('#'+id+'deleted').fadeOut('slow')
                        }, 1500);
    
      }
    }); 

  });
  });
//grab FDI
$(document).ready(function(){
$(document).on('click','.grabFDI',function(){
   var id=$(this).prop('id').replace('FDI', '');
    $.ajax({
      type: 'POST',
      url: 'views/grabFDI.php',
      data: { donation_id: id},
      success: function(data){
        $('#'+id+'grabFDI').html("<div class='dropshadow' id="+id+"grabFDI' style='z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:25%; right:25%; margin-left:auto; margin-right:auto; padding:5px; color:white; background-color:green'>Successfully grabbed!</div>");
                    
        setTimeout(function(){
                         $('#'+id+'grabFDI').fadeOut('slow')
                        }, 1500);
      }
    }); 

  });
  });


  //SEARCH submitter 
$(document).ready(function(){
  $('#search_data').on('submit', function(event){
    
    event.preventDefault();
  function response(msg, bgcolor){
      $('#successRet').html('<div id="successRet" class="dropshadow" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:#fff; background-color:'+bgcolor+'">'+msg+'</div>');
           setTimeout(function(){
                         $('#successRet').fadeOut('slow')
                        }, 5000);
          }
    
    $.ajax({
        url: 'index.php?page=fetchSearch',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var msg=data.rResp;
            var bgcolor='#21963f';
            response(msg, bgcolor);
        }
    });
  });
});

  //REPORT submitter 
$(document).ready(function(){
  $('#return_data').on('submit', function(event){
    event.preventDefault();
    var asset_id=$('#asset-id').val();
    var city=$('#city').val();
    var area=$('#area').val();
    var street=$('#street').val();
    var contact=$('#contact').val();
    var rptType=$('#rptType').val();
    
  if(asset_id==34 || asset_id==''){  $('#attache').load('includes/itemFm.inc.php');}
  if(asset_id==25){  $('#attache').load('includes/personFm.inc.php');}
  if(asset_id==33 || asset_id==23 || asset_id==24 || asset_id==18 ){  $('#attache').load('includes/cardFm.inc.php');}
  if(asset_id==16){  $('#attache').load('includes/docFm.inc.php');}
  if(asset_id==13){  $('#attache').load('includes/jewelFm.inc.php');}
  if(asset_id==19){  $('#attache').load('includes/moneyFm.inc.php');}
    
      $('#return_fm').modal('show');
      $('#_asset-id').val(asset_id);
      $('#_city').val(city);
      $('#_area').val(area);
      $('#_street').val(street);
      $('#_contact').val(contact);
      $('#_rptType').val(rptType);
/*      if(rptType == 1){
        document.getElementById('rptBtns').innerHTML('REPORT');
      }*/
    
  });

  $('#return_data2').on('submit', function(event){
    event.preventDefault();
    var _asset_id=$('#_asset-id').val();
    var _city=$('#_city').val();
    var _area=$('#_area').val();
    var _street=$('#_street').val();
    var _contact=$('#_contact').val();
    
    function response(msg, bgcolor){
             $('#return_fm').modal('hide');
            // $('#'+i+'info').modal('hide');
             $('#successRet').html('<div id="successRet" class="dropshadow" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:#fff; background-color:'+bgcolor+'">'+msg+'</div>');
           setTimeout(function(){
                         $('#successRet').fadeOut('slow')
                        }, 5000);
          }
    
    $.ajax({
        url: 'index.php?page=setreturn',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
            var msg=data.rResp;
            var bgcolor='#21963f';
            response(msg, bgcolor);
        //$('#return_data').[1].reset();
        
        },
        error: function(data){
            var msg='Sorry! filing report failed, try again.';
            var bgcolor='red';
            response(msg, bgcolor);
        }
    });
  });
  
  });
  //return submitter ends here
 //block a user
$(document).ready(function(){  
  $(document).on('click','.block',function(){
     var i=$(this).prop('id').replace('bn', '');
     var blockeeId=$('#'+i+'blockUser').val();
        $('#'+i+'blocker_form').on('submit', function(event){
           event.preventDefault();
    
          function response(msg, bgcolor){
             $('#'+i+'blockModal').modal('hide');
             $('#'+i+'info').modal('hide');
             $('#'+i+'successBlocked').html('<div class="dropshadow" id="'+i+'successBlocked" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:red; background-color:'+bgcolor+'">'+msg+'</div>');
           setTimeout(function(){
                         $('#'+i+'successBlocked').fadeOut('slow')
                        }, 5000);
          }
    
 $.ajax({   url: 'views/blockUser.php',
            method: 'POST',
            data: {blockeeId: blockeeId},
            dataType: 'json',
            success: function(data){
               var msg=data.blockedResp;
               var bgcolor='#fff';
                 $('.'+blockeeId).hide('slow');//write BLOCKED LETTERS ON this widget
              response(msg, bgcolor);
            },
            error: function(data){
               var msg='Sorry! blocking user failed, try again.';
               var bgcolor='yellow';
              response(msg, bgcolor);
            }
        });

      });
  });
});
//update notifications
$(document).ready(function(){
    function updateNotifications(note='newMsg'){
        $.ajax({
            url: 'views/notifyMe.php',
            method: 'GET',
            data: {getNote: note},
            dataType:'json',
            success: function(data){
               $('.inbox').html(data.totalNew);
               $('.notifier').html(data.notifier);
               $('.eachMsg').html(data.eachMsg);
            }
        });
    }
            updateNotifications();
        setInterval(function(){
            updateNotifications();
        }, 1000*30);
});

//update new found ppts
$(document).ready(function(){
    function updateRtNotifications(note='newRtn'){
        $.ajax({
            url: 'views/rtnNotes.php',
            method: 'GET',
            data: {getNote: note},
            dataType:'json',
            success: function(data){
               $('.rtnNotes').html(data.allNew);
                $('#geofnd').html("<h6 style='color:#2196f3; text-align:center'>Recently found items</h6><marquee id='rtlist' onfocus='start()' scrollamount=6 ></marquee>");
                 $.each(data.rtnNotes, function() {
                          var item = this['ppt'];
                          var date = this['rdate'];
                    $('#rtlist').append("<span><strong style='color:#ff00e2; font-size:16px'>"+item+"</strong>&nbsp;<i class='fa fa-globe fa-spin skyblue'></i>&nbsp;<sub>"+date+"</sub>&nbsp;&nbsp;&nbsp;</span>");
               });
            }
        });
    }
    updateRtNotifications();
    setInterval(function(){
//      $('#geofnd span').remove();
       updateRtNotifications();
    }, 1000*25);
});




//FDI form submitter
$(document).ready(function(){
  $('#FDI_data').on('submit', function(event){
    event.preventDefault();
    var item=$('#item').val();
    var worth=$('#worth').val();
    var contact=$('#contact').val();
    
  $('#file').change(function(){
    var file=this.files[0];
    var fileType=file.type;
    var match=['image/jpeg', 'image/png', 'image/jpg'];
    if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]))){
      alert('sorry, only jpg, jpeg & png files are allowed');
      $('#file').val('');
      return false;
    }
  });

   
 if(item !='' && worth !='' && contact !=''){
    $.ajax({
        url: 'views/donatex.php',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
        $('#FDI_data')[0].reset();
        var resp= data.FDIResp;
        var bgcolor='#002';

        var msg="<div style='background-color:"+bgcolor+"; position:fixed; left:12%; right:12%; top:5%; border-radius:10px; font-family:calligraphy; z-index:1; padding:5px; color:#fff; text-decoration:italic; font-weight:bold; font-size:1.2em; text-align:center'>"+
                 "<span style='font-size:13px; font-family:cursive'>"+resp+"</span></div>";
        var fmHide='donate_fm';
        var respFade='successDon';
     $('#donateBtn').hide();  
     response(msg, bgcolor, fmHide, respFade);
          $(window).scrollTop(100);
        },
        error: function(data){
        $('#FDI_data')[0].reset();
      var msg='Sorry, '+item+' donation failed, try again!';
      var bgcolor='red';
          response(msg, bgcolor);
        }
      });
    }
  });
  });


//request form submitter
$(document).ready(function(){
  $('#request_data').on('submit', function(event){
    event.preventDefault();
    var asset=$('#asset').val();
    var proof=$('#proof').val();
    var myaudio=$('#myaudio').val();
    var range=$('#myRange').val();
    var myId=$('#addMyId').val();
    var myEmotion=$('#myEmotion').val();
    var id=$('donation_id').prop('id');
   // var imgProof=$('#imgProof').val();
  proof=='' ? proof="<audio controls><source src='src'></audio>" : proof=proof+'....';
$('#file').change(function(){
  var file=this.files[0];
  var fileType=file.type;
  var match=['image/jpeg', 'image/png', 'image/jpg'];
    if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]))){
      alert('sorry, only jpg, jpeg & png files are allowed');
      $('#file').val('');
      return false;
    }
});
    function response(msg, bgcolor){
       $('#request_fm').modal('hide');
       
         $('#successReq').html('<div class="dropshadw" id="successReq" style="filter:drop-shadow(3px 3px 30px #ccc); z-index:1; font-size:16px; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:20%;'+
          ' right:20%; top:15%; margin-left:auto; margin-right:auto; padding:5px; color:#fff; background-color:'+bgcolor+'">'+msg+'</div>');

   /*          var newReq="<div class='container-fluid container' style='margin-bottom:-1.5em; margin-top:-1em;'"+ "draggable=true ondblclick=$('#donateBtn').show('slow')>"+
   "<div class='row'>"+
      "<div class='col-sm-0 col-md-0 col-lg-1'></div>"+
      "<div class='col-xs-12 col-sm-12 col-md-12 col-lg-10'>"+
        "<div class='row jumbotron' draggable='true' style='background-color:white'>"+
          "<div class='col-xs-12 col-sm-12 col-md-12 optwem text-center' style='color:#2196f3'><strong>"+
                  asset+"</strong>"+
          "</div>"+
          "<div class='col-xs-12 col-sm-12 skyblue optwem text-center'>"+
                  "<center><span style='font-family:roboto; color:black; font-size:14px'><br>"+
                  proof+"</span></center>"+
              "<div style='text-align:right'>"+
              "<button class='delete btn sm hover' style='background-color:white; color:red; "+
              "border:1px solid red'>Delete</button>"+
  "</div>"+
  "<table width='100%' style='margin-bottom:-1.5em; margin-top:-1.5em'>"+
                  "<tr style='line-height:.2em'><td>"+
        "<span class='psem'><i class='fa fa-heart warning' style=''></i>&nbsp;&nbsp; <sup><i class='fa fa-circle'"+ "style='color:#aaa; font-size:.4em'></i></sup><label style='color:#aaa'>&nbsp;&nbsp; 0 people showed "+ "empathy</label></span>"+
                  "</td></tr>"+
                "</table>"+
              "</div>"+
                  "<div class='col-xs-12 col-sm-12 col-md-12'>"+
                  "<br><hr>"+
"<table width='100%' style='margin-top:-10px; margin-bottom:-5px'>"+
          "<tr>"+
"<td width='15%'><span onclick=$('#type').replaceWith('playing')><i class='fa fa-volume-down hover md' id='type' "+ "title='chat' style='color:white; -webkit-text-stroke-width:1px; -webkit-text-stroke-color:black'></i></span>"+
            "</td>"+
            "<td width='25%'><center><span class='emp' id='did2' style='text-decoration:none'>"+
"<i class='fa fa-heart hover md' title='Empathy' id='nemp' style='color:transparent; -webkit-text-stroke-width:1px;"+ "-webkit-text-stroke-color:red' onclick=$('').html(1)></i> <label class='e' id='e' style='color:#2196f3'>0"+
"</label>"+
                "</span></center>"+
            "</td>"+
            "<td width='25%'><center><span class='likes' id='did3' style='text-decoration:none'>"+
         "<i class='fa fa-thumbs-up hover md' id='nlike' style='color:transparent; -webkit-text-stroke-width:1px;"+ 
"-webkit-text-stroke-color:#EFAF5B' title='like' onclick=$('.l').html(_nlike+1)></i><label style='color:#2196f3'>"+
"0</label>"+
               "</span></center>"+
            "</td>"+
            "<td width='25%'><center><span id='did' class='ban' style='text-decoration:none'>"+
          "<i class='fa fa-ban hover md ajax' title='Ban' id='nban' style='color:transparent; -webkit-text-stroke"+
              "-width:1px; -webkit-text-stroke-color:#ff00e2' onclick=$('.b').html(_nonreal+1)>"+
               "</i> <label style='color:#2196f3'>0</label>"+
                "</span></center>"+
            "</td>"+
"<td width='10%' style='text-align:right'><a href=# data-toggle='modal' data-target='#"+i+"info' "+
    "style='color:black; text-decoration:none'><i class='fa fa-ellipsis-v'></i></a>"+
            "</td>"+
          "</tr>"+
       "</table>"+
        "</div>"+
        "</div>"+
            "</div>"+
            "<div class='col-sm-0 col-md-0 col-lg-1'></div>"+
          "</div>"+
        "</div>";
         $('#newReq').html(newReq);*/
        //fadeOut
            setTimeout(function(){
                            $('#successReq').fadeOut('slow')
                            
                           setTimeout(function(){
                            }, 50);    
                        }, 5000);

    }
    if(asset !='' && (proof !='' || myaudio !='')){
//      var formData = $(this).serialize();
    $.ajax({
        url: 'index.php?page=setrequest',
        method: 'post',
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
        $('#request_data')[0].reset();
        var msg= data.reqResp;
         var bgcolor='green';
         response(msg, bgcolor);
          $(window).scrollTo(0);
        },
        error: function(data){
        $('#request_data')[0].reset();
      var msg='Sorry, '+asset+' request failed, try again!';
      var bgcolor='red';
          response(msg, bgcolor);

        }
      });
  
    }
  });
});
//emotion sound
$(document).ready(function(){ 
  $(document).on('click','.fa-volume-off',function(){
    var i=$(this).prop('id').replace('type', '');         
    var sound_id=$('#'+i+'sound').val();
      document.getElementById('s17').play();
  });
});

//assist form submitter
$(document).ready(function(){  
  //var loc = new googl.maps.LatLng(this['lat'], this['long']); pg 440
  $(document).on('click','.assistForm',function(){
    var i4=$(this).prop('id').replace('dd4', '');
    var i3=i4.replace('dd3', '');
    var i2=i3.replace('dd2', '');
    var i=i2.replace('dd', '');

//    var i=$('#assistId').val();      
  $('#'+i+'assistForm').on('submit', function(event){
    event.preventDefault();
    var item=$('#'+i+'item').val();
/*    var donor=$('#'+i+'donor').val();
    var needy=$('#'+i+'needy').val();////////////PROBLEM OF ID SECURITY HER
*/    var donation_id=$('#'+i+'rid').val();
//var helperContact='';
 /* $('#'+i+'assistForm').on('submit', function(event){
   event.preventDefault();
    helperContact+=$('#'+i+'helperContact').val();
}*/    
    function response2(msg, bgcolor){
       $('#'+i+'assist').modal('hide');
       $('#'+i+'hid').hide('slow');
       $('#successAss').addClass(i+'successAss');
          $('#'+i+'successAss').html('<div class="dropshadow" id="'+i+'successAss" style="z-index:1; opacity:.9; border-radius:5px; text-align:center; position:fixed; left:20%;'+
          ' right:20%; margin-left:auto; margin-right:auto; padding:10px; color:white; background-color:'+bgcolor+'">'+msg+'</div>');
     
            setTimeout(function(){
                         $('#'+i+'successAss').fadeOut('slow')
                         $('#'+i+'assistForm').empty();
                        }, 5000);
           // $('#'+i+'assistForm').empty();
    }
    function clearInputs(){
      $("#"+i+"assistForm :input").val('');
      }

    
    if(helperContact!=''){
      //var formData = $(this).serialize();

    $.ajax({
        url: 'views/assist.php',
        method: 'post',
        //data: {"item" : item, "helperContact" : helperContact, "donation_id" : donation_id},
        data: new FormData(this),
        dataType:'json',
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          var msg=data.assResp;
          var bgcolor='#2196f3';
          response2(msg, bgcolor);
          clearInputs();
        },
        error: function(data){
          var msg='Attempt failed, please try again!';
          var bgcolor='red';
          response2(msg, bgcolor);
        }
      });
    }

 });
  });
  });


//Getting location
/*$(document).ready(function(){
function notifyUser(msg){
             $('#noGeo').html(pg+'<div id="noGeo" class="" style="z-index:1; opacity:.9; border-radius:5px; border:1px solid #ccc; text-align:center; position:fixed; left:20%;'+
                ' right:20%; top:15%; margin-left:auto; margin-right:auto; padding:10px; color:#ff00e2; background-color:#fff">'+msg+'</div>');
           setTimeout(function(){
                         $('#noGeo').fadeOut('slow')
                        }, 8000);
          }
*/
/*function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToPosition);
   } else { 
     var msg="Put on your device location ( <i class='fa fa-map-marker' style='color:#2166f3'></i> ) to use this app!";
      notifyUser(msg);
    }
}

function redirectToPosition(position) {
    var lat =position.coords.latitude;
    var lng = position.coords.longitude;
  {maximumAge:0; timeout: 5000; enableHighAccuracy: true}
$.ajax({
        type: 'POST', 
        url:  'views/process.php',
        data: 'lat='+lat+'&lng='+lng,
        });
  }
            getLocation();
        setInterval(function(){
            getLocation();
        }, 1000*60);
});
*/
//SLIDER
$(document).ready(function(){
var slider = document.getElementById("myRange");
$('.demo').text(slider.value/1000);

slider.oninput = function() {
$('.demo').text('within '+(Math.round(this.value/100))/10);
$('.demot').text('('+Math.round(this.value/1000*15) +' mins trek)');
}
});

/*$(document).ready(function(){
var sliders = document.getElementById("myRanger");
$('.demor').text(sliders.value/1000);
slider.oninput = function() {
$('.demor').text(this.value/1000);
$('.demotr').text('('+Math.round(this.value/1000*12) +' mins trek)');
}
});
*/
//Search perimeter
$(document).ready(function(){
        $("#peri").click(function() {
            var perimeter =     console.log($("#peri").val());
            $.ajax({
                type: 'POST',
                url: 'searches.php', //<<--- second file
                data: {"perimeter" : perimeter},
            });
        });
{
    var perimeter;
    perimeter=console.log($("#peri").val());
}
});

$(window).scroll(function () {
sessionStorage.scrollPos = $(window).scrollTop();
});
var init = function () {
$(window).scrollTop(sessionStorage.scrollPos || 0)
};
window.onload = init;

/*character counter*/
$(document).ready(function(){
$('textarea').on('input', function(){
var maxlength = $(this).attr('maxlength');
var currentLength = $(this).val().length;
var char = maxlength - currentLength;
if( currentLength >= maxlength ){
$('#charNum').text(' You have reached the limit');
}else{
$('#charNum').text(char + ' characters left');
}
});
});


/*PLAY AUDIO*/
//$(document).ready(function(){
//const rollSound = new Audio('view/audio.mp4');
//$('#dice-button').click(e => rollSound.play());
//});



