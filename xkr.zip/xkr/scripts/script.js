if("loading" in HTMLImageElement.prototype){
  const lazyImages = document.querySelectorAll("img.lazy");
  lazyImages.forEach(img => {
    img.src = img.dataset.src;
    });
}else{
  var observer = new IntersectionObserver(lazyLoad, {
    rootMargin: "100px",
    threshold: 1.0
  });

  function lazyLoad(elements){
    elements.forEach(image => {
      if(image.IntersectionRatio > 0){
        image.src = image.dataset.src;
        observer.unobserve(item.target);
      };
    });
  };

var lazyImages = document.querySelectorAll("img.lazy");
lazyImages.forEach(img => {
  observer.observe(img);
});

}

function displayProfileMenu(){
      var id = $('.menuBar').attr('id');
//      .replace('menuBar', 'menuBarShow');
      if(id=='menuBar'){
        $('#menuBar').append('<div class="menuList" id="menuList" style="filter:drop-shadow(-2px 2px 2px #ccc); position:fixed; right:1%; border-radius:5px; background:#fff; margin-top:10px; padding:20px; font-size:15px; text-align:left;">'+
        '<p style="margin:-10px auto -10px auto;"><a href="setprofile" style="color:black;">Profile settings</a></p><hr>'+
        '<p style="margin:-10px auto -10px auto;"><a href="assets" style="color:black;">My Assets</a></p><hr>'+
        '<p style="margin:-10px auto 0px auto;"><a href="" style="color:black;">Other settings</a></p>'+
      '</div>');
      document.getElementById('menuBar').id='menuBarHide';

      }else{
          $('.menuList').hide();
      document.getElementById('menuBarHide').id='menuBar';
      }

/*  $('.menuList').hide();
//    var id=$(this).attr('id').replace('homeFeed', '');
  $('#menuBar').append('<div id="menuList" style="position:fixed; right:1%; border-radius:5px; background:#fff; border:1px solid #aaa; margin-top:10px; padding:14px; font-size:13px; text-align:left;">'+
    '<p><a href>Search needs</a></p>'+
    '<p><a href="setprofile">Profile settings</a></p>'+
  '</div>');
  $('#menuList').addClass('menuList');
document.getElementById('menuBar').id='menuBarHide';
*/}



$(document).on('click', '#textProofCaller', function(){
                postFormatCaller('textProofCaller');
                $('#textProofCaller').css('color','#f01e6b');
              });
                      $(document).on('click','.playRec', function(){ 
                document.getElementById('audio').play();
                $('.playRec').replaceWith("<i class='fa fa-pause md playRec' id='playRec'></i>");
              });

/*              $(document).on('click','.fa-pause', function(){ 
              document.getElementById('playRec').classList.toggle('fa-play');
              document.getElementById('audio').pause();
                
              });
*/

useAud();
function useAud(){
        $(document).on('click','#useAudio',function(){
          $('#useAudio').css('font-size','30px');
          
          $('#textRec').remove();
          $('#audioRec').show();
//          $('.countDown').show();  
        });
      }



$(document).on('click','.item', function(){ 
  var did =$(this).prop('id').replace('itemContainer', '');
  $('#proof'+did).show('slow');
  $('.item'+did).css('font-size','20px');
});

    function response(msg, bgcolor){
       
       var div = document.createElement("div");
          var node = document.createTextNode(msg);
          div.appendChild(node);
          var respPanel = document.getElementById('response');
          var child = document.getElementById("commentOpener");
          respPanel.appendChild(div);
          
        $('#response').css({'z-index':10, 'font-size':'16px', 'font-family':'roboto', 'border-radius':'5px', 'text-align':'center', 'padding':'5px', 'color':'#fff', 'background-color':bgcolor});

            setTimeout(function(){
                            $('#response').fadeOut();
                           setTimeout(function(){
                             respPanel.removeChild(div);
                          }, 50);
                        }, 10000);
    }

//Javascript for darkMode switch
if(window.matchMedia('(prefers-color-scheme: dark)').matches){
  document.documentElement.setAttribute("dark", true);
}

//Complete reg form caller
$(document).on('click','.forceRegCompletion', function(){ 
  $('#completeReg').show();
});

// viewports functions
  $.fn.isInViewport = function(){
  var elementTop= $(this).offset().top;
  var elementBottom= elementTop + $(this).outerHeight();

  var viewportTop= $(window).scrollTop();
  var viewportBottom = viewportTop + $(window).height();
  var m=$(window).height()/2;
  return elementBottom > (viewportTop+m) && elementTop < (viewportBottom-m);
  }

  $(window).on('resize scroll', function(){
      $('.homeFeed').each(function(){
    var id=$(this).attr('id').replace('homeFeed', '');
    var auto=$('#autoplay'+id).val();
    var proof=$('#proof'+id).val();
    var ms=$('#media_setins'+id).val();
    if($(this).isInViewport()){
      if(auto==1){
           if($('#u_note'+id).length>0){
              if(ms==3 || ms==5){document.getElementById('u_note'+id).innerHTML = "<source src='user_notes/"+proof+".wav' type='video/webm'>";
            document.getElementById('u_note'+id).play();}}
      }
      else{
        if($('#u_note'+id).length>0){document.getElementById('u_note'+id).pause();}
      }
    
  //on the fly loading down here
      /*if(id > 5){
        alert('remain 5 down the line');
       //var body = document.getElementByTagName("body")[0];
        var pp = document.getElementById("aud_auto"+id);
      };*/
    };

  });
});

function assessHelper(selectedOption, did){
   $.ajax({
            url: 'includes/confirmHelp.inc.php',
            method: 'POST',
            data: {did: did, selectedOption:selectedOption},
            dataType:'json',
            success: function(data){
              $('#helperGrader'+data.did).hide('slow');
              response(data.ajaxReply, 'green');

            }
        });
}
//notification
    function updateNotifications(note='newMsg'){
        $.ajax({
            url: 'views/notifyMe.php',
            method: 'GET',
            data: {getNote: note},
            dataType:'json',
            success: function(data){
                var allnotes ='<strong>'+data.totalNew+'</strong>';
                document.getElementById('inbox_icon').innerHTML='<div style="font-size:10px; font-family:serif; padding:2px; color:#fff; background: red; border-radius:50%; display:flex; align-items:center; justify-content:center; height:18px; width:18px; border:2px solid #fff;">'+allnotes+'</div>';
            }
        });
    }
            updateNotifications();
        setInterval(function(){
            updateNotifications();
        }, 1000*30);

//close search results
 $(document).on('click','#close_searches', function(){ 
  $('#search_results').hide();
 });



//Rpt info
 $(document).on('click','#rtnHx', function(){ 
    $('.hideMe').hide('slow');

    $("#rpt").hide();
    $("#rtn").show();
    $("#assetsList").hide();
    $("#req").hide();
    $("#rtnHx").css({'color':'#f016eb', 'font-weight':'bold', 'padding':'2px 10px 2px 10px', 'background':'#fcf1f4', 'border-radius':'4px'});
    $("#rptHx, #reqHx, #userAssets").css({'background':'#fff', 'padding':'2px 10px 2px 10px', 'color':'#000', 'font-weight':'normal'});

  });
 $(document).on('click','#reqHx', function(){ 
    $('.hideMe').hide('slow');

    $("#rpt").hide();
    $("#rtn").hide();
    $("#assetsList").hide();
    $("#req").show();
    $("#reqHx").css({'color':'#f016eb', 'font-weight':'bold', 'padding':'2px 10px 2px 10px', 'background':'#fcf1f4', 'border-radius':'4px'});
    $("#rptHx, #rtnHx, #userAssets").css({'background':'#fff', 'padding':'2px 10px 2px 10px', 'color':'#000', 'font-weight':'normal'});

  });
 $(document).on('click','#rptHx', function(){ 
    $("#rpt").show();
    $("#assetsList").hide();
    $("#rtn").hide();
    $("#req").hide();
    
    $('.hideMe').hide('slow');
    $("#rptHx").css({'color':'#f016eb', 'font-weight':'bold', 'padding':'2px 10px 2px 10px', 'background':'#fcf1f4', 'border-radius':'4px'});
    $("#reqHx, #rtnHx, #userAssets").css({'background':'#fff', 'padding':'2px 10px 2px 10px', 'color':'#000', 'font-weight':'normal'});

  });

 $(document).on('click','#userAssets', function(){ 
    $('.hideMe').hide('slow');

    $("#assetsList").show();
    $("#rpt").hide();
    $("#rtn").hide();
    $("#req").hide();
    $("#userAssets").css({'color':'#f016eb', 'font-weight':'bold', 'padding':'2px 10px 2px 10px', 'background':'#fcf1f4', 'border-radius':'4px'});
   $("#reqHx, #rtnHx, #rptHx").css({'background':'#fff', 'padding':'2px 10px 2px 10px', 'color':'#000', 'font-weight':'normal'});

  });

//$(document).ready(function(){
    $(document).on('click','.sendContact',function(){
      $('.assistMedium').hide();
      $('.helper_tel').show();
      $('.backToOptList').show();
      
    });
    $(document).on('click','.chatUp',function(){
      $('.assistMedium').hide();
      $('.chatMedium').show();
      $('.backToOptList').show();
     
    });
    $(document).on('click','.backToOptList',function(){
      $('.assistMedium').show();
      $('.chatMedium').hide();
      $('.helper_tel').hide();
      $('.backToOptList').hide();
    });

              

function switchSrchForm2(){
  document.getElementById('searchRpts').innerHTML='<a href=# id="searchRpts" onclick="switchSrchForm()" style="color:#aaa;">Verify Ownership</a>';
    $('#searchType').val(1);
    $('#srchLossFm').attr("placeholder", "Search lost items...");
    $('#addCityFm').attr("placeholder", "City...");
    $('#search_btn').css({'background':'#fff', 'color':'#aaa'});
}

function switchSrchForm(){

    $('#searchType').val(3);
    $('#srchLossFm').attr("placeholder", "Input item to verify...");
    $('#addCityFm').attr("placeholder", " + City");
    $('#search_btn').css({'background':'#f01e6b', 'border':'#f01e6b', 'color':'white'});
    document.getElementById('searchRpts').innerHTML='<a href=# id="searchRpts" onclick="switchSrchForm2()" style="color:#f01e6b;">Search Loss</a>';
 }

$(document).on('click', '#audioProofCaller', function(){
  postFormatCaller('audioProofCaller');
  startRec();
  $('#audioProofCaller').css('color','#f01e6b');
});

$(document).on('click', '#textProofCloser', function(){
  $('#textProof').hide();
  postFormatCaller('');
});

$(document).on('click', '#radiusCoverageCaller', function(){
  xkrollRangeCaller('radiusCoverageCaller');
  $('#radiusCoverageCaller').css('color','#2196f3');//#f01e6b
  $('#global').val(0);
  
});

$(document).on('click', '#globalCoverageCaller', function(){
  xkrollRangeCaller('globalCoverageCaller');
  $('#globalCoverageCaller').css('color','#2196f3');//#f01e6b
  $('#global').val(1);
});

$(document).on('click', '#radiusCoverageCloser', function(){
  $('#radiusCoverage').hide();
  xkrollRangeCaller('');
});

function postFormatCaller(exclude){
  $('#'+exclude).css('color','red');
  $('.unselectedCaller').css('color','#666');

  var selectedFmControl=exclude.replace('Caller', '');
  $('.unselected').hide();
  $('#'+selectedFmControl).show();
}

function xkrollRangeCaller(exclude){
  $('#'+exclude).css('color','green');
  $('.unselectedCaller2').css('color','#666');

  var selectedFmControl=exclude.replace('Caller', '');
  $('.unselected2').hide();
  
  selectedFmControl === 'globalCoverage' ? rangeValue = 'visible to everyone' : rangeValue = 'within <span class="rangeVal"></span>km radius';
  document.getElementById('rangeValue').innerHTML='<span class="truncate">'+rangeValue+'</span>';
  $('#'+selectedFmControl).show();
 $('.coverage').show();
 
 var slider = document.getElementById("callRange");

slider.oninput = function() {
  $('.rangeVal').text((Math.round(slider.value/100))/10);
}

}

//AUTOUPDATE VOTES
function strShortener(value=this.data){
  if(value.length==4){
    var nV=value.slice(-3,);
    var x=value.slice(-3, -2);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'K');
  return newValue;
  }
  else if(value.length<7 && value.length>4){
    var nV=value.slice(-3,);
    var x=value.slice(-3, -2);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'K');
  return newValue;
  }
  else if(value.length==7){
    var nV=value.slice(-6,);
    var x=value.slice(-6, -5);
     x==0?x='':x='.'+x; 
   
    var newValue=value.replace(nV, x+'M');
  return newValue;
  }
  else if(value.length<10 && value.length>7){
    var nV=value.slice(-6, );
    var x=value.slice(-6, -5);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'M');
  return newValue;
  }
  else if(value.length==10){
    var nV=value.slice(-9,);
     var x=value.slice(-9, -8);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'B');
  return newValue;
  }
  else if(value.length<13 && value.length>10){
    var nV=value.slice(-9, );
    var x=value.slice(-9, -8);
    x==0?x='':x='.'+x; 
    var newValue=value.replace(nV, x+'B');
  }
  else{var newValue=value;}
    return newValue;
};


      $(document).on('click', '#report-type',function(){

var report_type = $('#report-type :selected').val();
report_type >= 3 ? $('#property').attr('required', true) : $('#property').attr('required', false);

        if(report_type==2){
          $('.item').show();
          $('.city').show();
         $('#city, #item').attr('required', true);

          $('.propertyType').hide();
          $('.model').hide();
          $('.img').hide();
          $('.desc').hide();
          $('.vins').hide();
        }
      else if(report_type==1){
          $('.item').show();
          $('.desc').show();
          $('#item').attr('required', true);

          $('.city').hide();
          $('.propertyType').hide();
          $('.model').hide();
          $('.img').hide();
          $('.vins').hide();
              document.getElementById('item_label').innerHTML = 'Item name*';
              $('#item').attr('placeholder', 'e.g. Wrist watch');
          document.getElementById('pptDesc').innerHTML = 'Describe the unique features of the property succintly(e.g make, model, scratch, dent, texture, color, decoration etc.)';
            
        }
      else if(report_type>=3){
          $('.item, .city').hide();
          $('.propertyType').show();
          $('.img, .desc').show();

       
        }
        
      });


$(document).on('click', '#property',function(){
var selected = $('#property :selected').val();
     if(selected>=6){
          $('.item').show();
         if(selected == 6 ){ 
              document.getElementById('item_label').innerHTML = 'Phone IMEI  <span style="background:#ccc; padding:3px; font-size:12px; border-radius:5px;"><a href="tel:*#06#" style="text-decoration:none;"> dial *#06#</a></span>';
              document.getElementById('pptImg').innerHTML = 'Upload phone picture and IMEI screenshot.';
              document.getElementById('pptDesc').innerHTML = 'Describe the make, model, color.';
              $('#item').attr('placeholder', 'IMEI-1, IMEI-2 separated by comma');

          }
         if(selected == 7 ){ 
              document.getElementById('item_label').innerHTML = 'TV serial number*';
              document.getElementById('pptImg').innerHTML = 'Upload snapshot of serial number page on TV screen';
              document.getElementById('pptDesc').innerHTML = 'Describe the make, model, color.';
             $('#item').attr('placeholder', 'enter TV serial num.');
          }
         if(selected == 8 ){ 
              document.getElementById('item_label').innerHTML = 'Item name*';
              document.getElementById('pptImg').innerHTML = 'Upload property snapshot';
              document.getElementById('pptDesc').innerHTML = 'if possible, describe external appearance with color, material, internal constituent etc';
              $('#item').attr('placeholder', 'e.g Wrist watch');
          }
          
          $('#item').attr('required', true);
          $('#vin1, #vin2, #vin3, #model, #make').attr('required', false);
          $('#model, #make').attr('required', false);
//          $('#vin1, #vin2, #vin3, #model, #make').css('display', 'none');
          $('.model, .vins').hide();
      }
      else if(selected<6){
          $('.model, .vins').show();
          $('#make, #model, #vin1, #vin2, #vin3, #color').attr('required', true);
          $('.item').hide();
        
      }

     
});

/*$(document).on('click', '.chasisCol',function(){
   $('.vins').show();
});
*/
$(document).on('click', '.property',function(){
var property = $('.property :selected').val();//document.getElementById('report-typer').value;
if(property<=3){
  $('.model').show();
  $('#model').attr('placeholder', 'Vehicle model');

}
else if(property==4 || property==5){
  $('.model').show();
  $('#model').attr('placeholder', 'Bike model');

}
/*
else if(property==3){
  $('.model').show();
  $('#model').attr('placeholder', 'Truck model');

}*/

});