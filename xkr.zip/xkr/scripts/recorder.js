
//video function starts
//$(document).ready(function(){
function vid_rec(sec, folder) {
navigator.mediaDevices.enumerateDevices().then((devices) => {
  devices = devices.filter((d) => d.kind === 'videoinput');
});
processor.doLoad();

  var handleSuccess = function(stream) {
processor.doLoad();
    var options;
    if(MediaRecorder.isTypeSupported('video/webm;codecs=vp8')){
      options = {mimeType: 'video/webm;codecs=vp8'};
    }
    else if(MediaRecorder.isTypeSupported('video/webm;codecs=vp9')){
      options = {mimeType: 'video/webm;codecs=vp9'};
    }
    else{
      options = {mimeType: 'video/webm'};
    }
//    const options = {mimeType: 'video/webm;codecs=vp8'};
    var recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream, options);
    mediaRecorder.ondataavailable = handleDataAvailable;
    mediaRecorder.start(1000);
       //     document.getElementById('source').src=stream;
 $('#source').attr('src', stream);
processor.doLoad();
    function handleDataAvailable(event){
      if(event.data.size > 0){
        recordedChunks.push(event.data);
      }else{
        alert('No data recorded');
      }
    } 

    setTimeout(function(){
       
        mediaRecorder.stop(); 
        let blob = new Blob(recordedChunks);
        var src = URL.createObjectURL(blob);
        var xhr=new XMLHttpRequest();
        var fmd = new FormData();
        fmd.append("video_data",blob,folder);
        xhr.open("POST","index.php?page=vid_upload",true);
        xhr.send(fmd);
        $('#source').attr('src', src);
       $('#overlay').css({'position': 'fixed', 'z-index': '91', 'left': '0', 'top': '0', 'width': '100%', 'height': '100%', 'overflow': 'auto', 'background': 'rgba(0,0,0,0.2)',});
        document.getElementById('overlay').innerHTML='<div style="height:100vh; background:transparent; display:flex; justify-content:center; align-items:center;"><span id="overlayPanel" style="z-index:92; border-radius:10px; color:red; background:#fff; font-size:25px; padding:10px; font-weight:bold;">Video Sent</span></div>';
 //navigator.mediaDevices.getUserMedia().stop();
      }, sec + 1000);

setTimeout(function(){
  $('#overlayPanel').css({'color':'#fff', 'background':'red'});
  $('#overlay').css({'filter':'drop-shadow(1px 1px 100px #ccc'});
  }, sec + 5000);
    
   }
     navigator.mediaDevices.getUserMedia({ audio: true, video: true }).then(handleSuccess);
  }



var processor = {
  timerCallback: function() {
    if (this.video.paused || this.video.ended) {
      return;
    }
    this.computeFrame();
    var self = this;
    setTimeout(function () {
      self.timerCallback();
    }, 16); // roughly 60 frames per second
  },

  doLoad: function() {
    this.video = document.getElementById("preview");
    this.c1 = document.getElementById("canvas");
    this.ctx1 = this.c1.getContext("2d");
    var self = this;

    this.video.addEventListener("play", function() {
      self.width = self.video.width;
      self.height = self.video.height;
      self.timerCallback();
    }, false);
  },

  computeFrame: function() {
    this.ctx1.drawImage(this.video, 0, 0, this.width, this.height);
    var frame = this.ctx1.getImageData(0, 0, this.width, this.height);
    var l = frame.data.length / 4;

    for (var i = 0; i < l; i++) {
      var grey = (frame.data[i * 4 + 0] + frame.data[i * 4 + 1] + frame.data[i * 4 + 2]) / 3;

      frame.data[i * 4 + 0] = grey;
      frame.data[i * 4 + 1] = grey;
      frame.data[i * 4 + 2] = grey;
    }
    this.ctx1.putImageData(frame, 0, 0);

    return;
  }
};


touch_count = 0;
TOUCH_TIMEOUT = 500;
$('body').on('click touchend', function(evt){
    touch_count +=1;
    setTimeout(function(){
      touch_count = 0; 
    }, TOUCH_TIMEOUT);


    if(touch_count === 3){
      var msg = '<video id="preview" controls autoplay width="100%" height="100%" crossorigin="anonymous">'+
                  '<source id="source" src="" type="video/webm">'+
                  '<source src="" type="video/mp4">'+
                '</video>'+
                '<canvas id="canvas" width="100%" height="100%"></canvas>';

      document.getElementById('homevideo').innerHTML=msg;//var msg = '<video id="player" width="100%" height="100%" controls autoplay></video>';
      $('#homevideo').css('height','100%');
      var bgcolor = 'red';
     // $('#canvas, #video-frame').css({'z-index':90, 'position':'fixed', 'top':'5%', 'display':'flex', 'align-items':'center', 'justify-content':'center', 'width':'100%', 'height':'100%', 'border-radius':'15px', 'margin':'25px'});

     vid_rec(10000, 1);
    }

});



function startRec(sec, folder){
  event.preventDefault();
  let device= navigator.mediaDevices.getUserMedia({ audio: true });
  let chunks = [];
  let recorder;
  device.then(stream => {
    recorder = new MediaRecorder(stream);

    recorder.ondataavailable = e => {
      chunks.push(e.data);

      if(recorder.state == 'inactive'){
        let blob = new Blob(chunks, {type: 'audio/webm' });
   var ad=URL.createObjectURL(blob); 
   //start
   var xhr=new XMLHttpRequest();
   xhr.onload=function(e){
    if(this.readState===4){
      console.log("Server returned: ",e.target.responseText);
    }
   };
   var fd=new FormData();
   fd.append("audio_data",blob,folder);
   xhr.open("POST","index.php?page=aud_upload",true);
//   xhr.open("POST","views/aud_upload.php",true);
   xhr.send(fd);
   //stop
//   document.getElementById('audio').innerHTML = '<source src="'+ad+'" type="video/webm" />';
          $('#myaudio').val(ad);
      }
    }
    recorder.start(1000);
    $('#reportBtn').attr('disabled', true);
    $('#startRecBtn').attr('disabled', true);

  });

 var x = setInterval(function(){
//                var n = Math.floor(Math.random()*100);
                $("#countDowntime"+folder).css({"font-weight":"bold", "font-size":"20px", "font-family":"cursive"});
                $("#countDowntime"+folder).attr("required", true);
                document.getElementById("countDowntime"+folder).innerHTML = '<span style="filter:drop-shadow(1px 1px 0px #aaa);">'+sec+':00</span>';  
                if(sec<=0){
                  recorder.stop();
                  $('#reportBtn').attr('disabled', false);
                  $('#startRecBtn').attr('disabled', false);

                  document.getElementById('countDowntime'+folder).innerHTML = "<i class='fa fa-play md playRec'></i>";
             //   $("#countDowntime"+folder).removeAttr("id");
                  clearInterval(x);
                
                }
                  sec--;

                }, 1000); 

}


/////////////
function countDown(sec){
 var x = setInterval(function(){
//sec>=60 ?   
$("#cdcontainer").attr("onclick", "");
              
                document.getElementById("countSecs").innerHTML ='Remain <span style="font-size:20px; color:red;">'+sec+'s </span >..';  
                if(sec<=0){
                  clearInterval(x);
                  $("#cdcontainer").attr("onclick", "countDown()");

                }
                  sec--;

                }, 1000);
}


/*var processor = {
  timerCallback: function() {
    if (this.video.paused || this.video.ended) {
      return;
    }
    this.computeFrame();
    var self = this;
    setTimeout(function () {
      self.timerCallback();
    }, 16); // roughly 60 frames per second
  },

  doLoad: function() {
    this.video = document.getElementById("video-frame");
    this.c1 = document.getElementById("canvas");
    this.ctx1 = this.c1.getContext("2d");
    var self = this;

    this.video.addEventListener("play", function() {
      self.width = self.video.width;
      self.height = self.video.height;
      self.timerCallback();
    }, false);
  },

  computeFrame: function() {
    this.ctx1.drawImage(this.video, 0, 0, this.width, this.height);
    var frame = this.ctx1.getImageData(0, 0, this.width, this.height);
    var l = frame.data.length / 4;

    for (var i = 0; i < l; i++) {
      var grey = (frame.data[i * 4 + 0] + frame.data[i * 4 + 1] + frame.data[i * 4 + 2]) / 3;

      frame.data[i * 4 + 0] = grey;
      frame.data[i * 4 + 1] = grey;
      frame.data[i * 4 + 2] = grey;
    }
    this.ctx1.putImageData(frame, 0, 0);

    return;
  }
};
*/



//window.onload = function(){
//  document.querySelector('body').addEventListener('click', function(evt){
  /*  $('body').on('click touchend', function(evt){
//      console.time('timer');

    if(evt.detail === 5){
      var msg = '<video id="player" width="320" height="240" controls autoplay></video>';
      var bgcolor = 'red';
      $('#player').css({'z-index':90, 'position':'fixed', 'top':'5%', 'display':'flex', 'align-self':'center', 'justify-content':'center', 'width':'320', 'height':'240', 'border-radius':'15px', 'margin':'25px'});
      //console.timeEnd('timer');
      
alert('timer 5secs');
     // vid_rec(10000, 1);
  }
 });
*/
