
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToPosition);
   } else { 
     var msg="Put on your device location ( <i class='fa fa-map-marker' style='color:#2166f3'></i> ) to use this app!";
     var bgcolor='#002';
     var id='';
     var respSelector='response';

     response(msg, bgcolor, id, respSelector);
 
    }
}

function redirectToPosition(position) {
    var lat =1.3456;//position.coords.latitude;
    var lng =2.3456;//position.coords.longitude;
  {maximumAge:10000; timeout: 5000; enableHighAccuracy: true}
  $.ajax({
        type: 'POST', 
        url:  'views/getGeo.php',
        data: 'lat='+lat+'&lng='+lng,
        });
        //alert('lat: '+lat+' and long:'+lng);
}
