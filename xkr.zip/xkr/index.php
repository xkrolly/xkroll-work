<?php
include_once 'includes/autoloader.inc.php';

$pgv = new UsersView();
$pgv->session();
$pgv->content='';

//$pgv->addScript('https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js');
$pgv->addScript('scripts/jquery-3.3.1.min.js');

$pgv->addScript('scripts/login.js');
$pgv->addScript('scripts/geoLoc.js');
$pgv->addScript('index.js');

/*$pgv->addCSS('css/master.css');
*/
$pgv->addCSS('https://fonts.googleapis.com/icon?family=Material+Icons');

if(isset($_SESSION['user_id'])){
  $pgv->addScript('scripts/script.js');
  $pgv->addScript('scripts/autoUpd.js');
  $pgv->addScript('scripts/processor.js');
  $pgv->addScript('scripts/recorder.js');
 // $pgv->addScript('scripts/app.js');

$row = $pgv->fetchUser();
$regCompleted = $row[0]['regCompleted']; 
if($regCompleted==0){
  $pgv->content .= $pgv->showModal('views/completeRegFm.php', 'completeReg', 'file');
}

  $pgv->content .=include_once "views/navigation.php";

  $pgv->addCSS('css/index.css');
  $navigationIsClicked = isset($_GET['page']);
$fileToLoad='';
  if($navigationIsClicked){$fileToLoad .= $_GET['page'];}
  else {$fileToLoad .='home';}
  $fileToLoad == "" ? $fileToLoad = 'home' : $fileToLoad;
  $pgv->content.=include_once "views/".$fileToLoad.".php";
  $pgv->embeddedStyle = "<style>
    nav a[href *= '$fileToLoad']{
      background:#fff;
      color:#f01e6b;
      -webkit-text-stroke-width:0px; 
      -webkit-text-stroke-color:#f01e6b;
      margin-top:-5px;
      text-decoration:none;
      padding-top:10px;
    }
    .contain_er{
      display:flex;
    }

  </style>";
}else{
 $pgv->content .= include_once "views/login.php";
 $pgv->embeddedStyle = "<style>
     *{
      box-sizing:border-box;
      vertical-align: baseline;
      font-weight: inherit;
      font-family: inherit;
      font-style: inherit;
      font-size: 100%;
      border: 0;
      outline: 0;
      padding: 0;
      margin: 0;
    }

    .homepage{
      background: url(img/aerial2.webP) no-repeat center fixed;
      background-attachment: fixed;
      filter:blur();
      backdrop-filter:blur;
      background-size:cover;
      max-width:100%;
      color:#999;
      height:auto;
      position:relative;
    }

    .bg-overlay{
            background: rgb(0,0,0,0.45);
            height:100%;
            width:100%;
            padding:15px;
    }

    .homepage>header{
      position: absolute;
      bottom:0;
      left:0;
      height:50%;
      width:100%;
      padding: 20px 10px;
      background:inherit;
      background-attachment:fixed;
      overflow:hidden;
      margin-top:200px;
    }
 </style>";
} // lobster fonts
$page="
<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en' dir='ltr'>
  <head>
    <title>Xkroll: Seek help, share vital info or alert people nearby</title>
    <meta charset='utf-8'>
    <meta name='description' content='Seek, gist, inform or alert nearby people urgently about a potential threat, needs for rescue or help anytime anywhere. Get started with Xkroll now!'>
    <meta name='Homepage' content='Xkroll homepage'>
    <meta name='theme-color' content='#f01e6b'>
    <meta name='twitter:title' content='Xkroll homepage'>
    <meta name='twitter:description' content='Seek help, inform or alert nearby people urgently about a potential threat, needs for rescue or help anytime anywhere. Get started with Xkroll now!'>
     <meta name='twitter:creator' content='@_xkroll'>

    <meta http-equiv='Content-Type' content='text/html' charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
    <meta http-equiv='x-ua-compatible' content='ie=edge'>
    <link rel='canonical' href='https://xkroll.com/' />
    <link rel='manifest' href='manifest.json' />
    <link rel='apple-touch-icon' href='img/logo192.png' />
    <link rel='stylesheet' href='css/master.css' />
    <link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons' />
    $pgv->embeddedStyle
    $pgv->css
  </head>
  <body class='RBtn body xkroll'>
    <main role='main'>
      <article itemscope itemtype='http://schema.org/checkoutPage'>
        <meta itemprop='datePublished' content='2020-01-02 09:00:20 -0700 -0700'>
        <meta itemprop='dateModified' content='2021-02-02 10:30:55 -0700 -0700'>
        <div style='width:100%; display:flex; justify-content:center;'>
        <div id='overlay'></div>
        <div id='homevideo' style='z-index:90; width:100%; position:fixed; top:0;'></div>
        </div>
        <div id='response' style='z-index:80;'>
        </div>
        $pgv->content
      </article>
    </main>  
    $pgv->scriptElements
   </body>
</html>";
echo $page;