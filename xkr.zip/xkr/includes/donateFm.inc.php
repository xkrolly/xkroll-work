<?php
return "<form id='FDI_data' class='form-horizontal' role='form'>
            <h5 class='text-center' style='color:#2196f3; font-weight:bold;'>FDI Zone</h5>
            <div class='peem' style='padding:0 30px 0 30px; font-weight:bold; color:#fff'>Your kind gesture today could make the world a better place.</div><br>
            <div class='form-group'>
                          <div class='col-sm-12'>
                             <input type='text' name='item' id='item' class='form-control sm' required value='' placeholder='Item to offer'/>
                        </div>
                   </div>
                    <div class='form-group'>
                      <div class='col-sm-12'>
                          <div class='input-group'>
                              <select name='currency' class='input-group-addon' style='border:.5px solid #ccc; border-radius:4px 0px 0px 4px; background-color:white;'>
                                <option value='₦'> Naira (₦) </option>
                                <option value='USD'>USD ($)</option>
                                <option value='£'>Pounds (£) </option>
                                <option value='€'>Euro (€) </option>
                                <option value='¥'>Yuan (¥) </option>
                              </select>
                              <input type='number' class='form-control peem' min='100' max='' name='worth' id='worth' value='' placeholder='Current worth?' style='border-right:0px; border-left:0px' required
                                    pattern='^(?=.{10,})([\d]>=10)$'
                                        title='Input must be only numeric characters.'/>
                              <button style='border-radius:0px 4px 4px 0px; background-color:white; border:.5px solid #ccc' class='input-group-addon towem'>.00</button>
                          </div>
                      </div>
                   </div>
                    <div class='form-group'>
                            <div class='col-sm-12'>
                                <input class='form-control sm' type='text' placeholder='Your Phone number' name='contact' id='contact' required
                            pattern='^(\d{11})$'
                            title='Input must not be more or less than 11 numeric characters.'/>
                            </div>
                    </div>
                    <div class='form-group'>
                       <div class='col-sm-12'>
                           <span><input type='file' name='file' id='file' value='property_snapshot' required class='file-input' data-multiple-caption='{count} files selected' multiple/>
                            <label for='file' class='label'><i class='fa fa-upload'></i>&nbsp;&nbsp;Item image<span></span></label></span>

                      </div>
                    </div>    
                    <div class='form-group'>
                        <div class='col-sm-12'>
                           <button type='submit' style='' class='' name='submit'>Donate
                          </button>
                        </div>
                    </div>
            </form><br>
            <div style='text-align:center'>
            <a href='#' class='sm'>About FDI</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href='#' class='sm'>FDI policy</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href='#' class='sm'>About us</a></div>";