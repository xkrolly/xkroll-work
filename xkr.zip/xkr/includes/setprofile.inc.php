<?php

include('autoloader.inc.php');
	
	$usersContr = new usersContr();
	$usersView = new usersView();
	$userData = $usersView->fetchUser();

$uid = $userData[0]['profile_id'];
$H_target=$uid.'H'.time();
$P_target=$uid.'P'.time();

isset($_POST['sex']) ? $gender = $_POST['sex'] : $gender='';
isset($_POST['religion']) ? $religion = $_POST['religion'] : $religion = '';
isset( $_POST['contact']) ? $contact = $_POST['contact'] : $contact='';
isset($_FILES['imgH']['name']) ? $imgH = $_FILES['imgH']['tmp_name'] : $imgH = '';
isset($_FILES['imgP']['name']) ? $imgP = $_FILES['imgP']['tmp_name'] : $imgP = '';
isset( $_POST['show-profile']) ? $show_profile = $_POST['show-profile'] : $show_profile='0';


isset($_FILES['imgH']['tmp_name']) ? move_uploaded_file($imgH, '../img/header/'.$H_target.".webp") : $nothing = '';

isset($_FILES['imgP']['tmp_name']) ? move_uploaded_file($imgP, '../img/profiles/'.$P_target.".webp") :  $nothing = '';

$user = $uid;
!empty($imgP) ? $profile = $P_target.', ' : $profile='';
!empty($imgH) ? $header = $H_target.', ' : $header='';
//!empty($show_profile) ? $showProfile = $show_profile.', ' : $showProfile = '';
$showProfile = $show_profile.', ';
!empty($contact) ? $contact = $contact.', ' : $contact='';

!empty($imgP) ? $profileC = 'picture=?, ' : $profileC ='';
!empty($imgH) ? $headerC = 'headerImg = ?, ' : $headerC ='';
//!empty($show_profile) ? $showProfileC = 'show_profile = ?, ' : $showProfileC = 'show_profile = ?, ';
$showProfileC = 'show_profile = ?, ';
!empty($contact) ? $contactC = 'contact = ?, ' : $contactC='';
$userC = 'profile_id = ?';

$_selectedCols = $contactC.$profileC.$headerC.$showProfileC;
//delete the last two string
$selectedCols = substr($_selectedCols, 0, -2);

$vals = $contact.$profile.$header.$showProfile.$user;

$usersContr->update('profile', $selectedCols.' WHERE profile_id = ?', $vals);

echo json_encode(array('ajaxReply'=>'Profile update successful'));
