<?php

$searchForm='<div class="viewWidth">
 <form method="post" id="search_data">
      <input type="hidden" name="searchType" value="3">
      <div style="display:flex; flex-direction:column; align-items:center; margin:20px;">
            <div style="display:flex; font-size:20px; border:1px solid #aaa; border-radius:5px;">
              <button type="submit" name="submit" tabindex=3 class="" id="search_btn" style="width:10vw; background:#fff; border:1px solid #aaa; border:transparent; border-top-left-radius:5px; border-bottom-left-radius:5px; padding:6px;">
                  <i class="fa fa-search" style="font-size:16px; color:#aaa;"></i>
              </button>
              <input type="search" incremental name="input" placeholder="Search your needs..." aria-label="Search the pool of found properties for your lost item" style="padding:6px; font-size:16px; width:82vw; border-right:1px solid #aaa; border:transparent;" />
            </div>
        </form>
      </div>
      <div style="padding:20px; margin-bottom:30px;">
          <span id="search_results"></span>
      </div></div>';

return $searchForm;
/*<div class="viewWidth">
 <form method="post" id="search_data">
      <input type="hidden" name="searchType" value="1">
      <div style="display:flex; flex-direction:column; align-items:center; margin:20px;">
        <a style="font-size:40px; font-family:Lobster;" href="index.php?page=home">
          Xkroll
        </a>
            <div style="display:flex; font-size:20px; border:1px solid #aaa; border-radius:5px;">
              <button type="submit" name="submit" tabindex=3 class="" id="search_btn" style="width:10vw; background:#fff; border:1px solid #aaa; border:transparent; border-top-left-radius:5px; border-bottom-left-radius:5px; padding:6px;">
                  <i class="fa fa-search" style="font-size:16px; color:#aaa;"></i>
              </button>
              <input type="search" incremental name="input" placeholder="Input lost item..." aria-label="Search the pool of found properties for your lost item" style="padding:6px; font-size:16px; width:42vw; border:1px solid #aaa; border:transparent; border-right:1px solid #aaa;" />
              <input type="search" name="city" placeholder="City where lost..." style="border-top-right-radius:5px; width:42vw; padding:6px; font-size:16px; border:1px solid #aaa; border:transparent; border-bottom-right-radius:5px;" />
            </div>
        </form>
      </div>
      <div style="padding:20px;">
          <span id="search_results"></span>
      </div>
      <br></div>';
*/