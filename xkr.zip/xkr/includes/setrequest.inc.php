<?php
include('autoloader.inc.php');
	
	$usersContr = new usersContr();
	$usersView = new usersView();

	$userData = $usersView->fetchUser();
	$uid = $userData[0]['profile_id'];
	$user_audio = $userData[0]['tmp_aud'];
	$req_total = $userData[0]['req_total'];
    $getMailed = $userData[0]['mailNote'];
	$lat = $userData[0]['lat'];
  	$lng = $userData[0]['lng'];

  	$last_req_date = $userData[0]['req_date'];
	//var_dump('Lat: '.$lat.' Long:'.$lng.' Total:'.$req_total);
	$userData[0]['def_range'] == 0 ? $default_range = 2500 : $default_range = $userData[0]['def_range'];

	$last_reqTime_numVal = strtotime($last_req_date);
    $time_diff = time() - $last_reqTime_numVal;

    isset($_POST['callRange']) ? $r=$_POST['callRange'] : $r=$default_range;

//	$user_audio!='' ? $user_audio=$user_audio : $user_audio='';
    $proof = $usersView->sanitise($_POST['proof']);
	$heading = $usersView->sanitise(ucfirst($_POST['heading']));
	
	!empty($proof) ? $callType = 't' : $callType = 'a';

	(empty($proof) && $user_audio=='nul') ? $proof='' : ($user_audio!='nul' ? $proof = $user_audio : $proof=$proof);

	$proof == $user_audio ? $updVal = "rqst_aud" : $updVal = "rqst_letr";	
    $usersContr->updUserActivity($uid, $updVal);

	(!empty($user_audio) && $user_audio!='nul') ? $useMedia = 1 : $useMedia = 0;
	//!empty($_POST['xkroll_callType']) ? $xkroll_callType=$_POST['xkroll_callType'] : $xkroll_callType=0;
//	$xkroll_callType=2;

    !empty($_POST['global']) ? $global=$_POST['global'] : $global=0;
	
	$range=round($r/100)/10;

	
	$tableName = 'donation';
//	 $userData = $usersContr->userProfile($uid);
//	 $lat=$userData['lat']; $lng=$userData['lng'];
//	INSERT INTO `donation` (`tuser_id`, `callType`, `useMedia`, `lat`, `lng`, `rnge`, `global`, `item`, `proof`) VALUES
//(1, 1, 1, 13.5, 11.9, 0.1, 0, 'Capitol', 'proof');

	$data = array("tuser_id"=>$uid, "callType"=>$callType, "useMedia"=>$useMedia, "lat"=>$lat, "lng"=>$lng, "rnge"=>$range, "global"=>$global, "item"=>$heading, "proof"=>$proof);
	
		$time_diff > 86400 ? $req_total=1 : $req_total;
		$time_diff > 86400 ? $last_req_date=date('Y-m-d H:i:s') : $last_req_date;
 		  
		if($time_diff > 86400 || $req_total<4 ){
			if($usersContr->setRequest($tableName, $data)){
				//remove the audio frm db
				$vals = 'nul, '.$req_total.', '.$last_req_date.', '.$uid;
				$usersContr->update('profile', 'tmp_aud=?, req_total=?, req_date=? WHERE profile_id = ?', $vals);

				$reqResp = $usersContr->reqResp;
			}
				
		}
 		else{
 				$reqResp = "You have reached your request limit for today!";
 		}
		echo json_encode(array('ajaxReply'=>$reqResp));