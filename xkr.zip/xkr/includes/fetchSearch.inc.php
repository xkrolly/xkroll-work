<?php
include('autoloader.inc.php');
  
	$usersView = new usersView();
	$searchInput = $usersView->sanitise($_POST['input']);
	$searchType = $usersView->sanitise($_POST['searchType']);

	isset($_POST['city']) ? $city=$usersView->sanitise($_POST['city']) : $city=''; 
if($searchType == 1 || $searchType == 3){ 
	$rows = $usersView->fetchSrch($searchInput, $city, $searchType);
	$total = count($rows);
	$id = array();
	$ppt = array();
	$time = array();
	$city = array();
	$description = array();
	$geoDist = array();

	if($total>0){
//		var_dump($total);
		foreach($rows as $row){
			$searchType==1 ? $id[] = $row['found_id'] : $id[] = $row['lst_id'];; 
			$ppt[] = $row['ppt']; 
			$time[] = $usersView->time($row['reporting_date']); 
			$searchType == 1 ? $city[] = $row['city'] : $description[] = $row['description'];
			$lat = $row['lat'];
			$lng = $row['lng'];
			$geo = $usersView->fetchUser();
			$uid = $geo[0]['profile_id'];
			$userLat = $geo[0]['lat']; 
			$userLng = $geo[0]['lng'];

			$geoDist[] = round($usersView->harvesineF($lat, $userLat, $lng, $userLng));
		}
	}
echo json_encode(array("type"=>$searchType, "id" => $id, "ppt"=>$ppt, "city"=>$city, "description"=>$description, "time"=>$time, "geoDist"=>$geoDist, "total"=>$total));	
}
elseif($searchType==4){
	$rows = $usersView->fetchSrch($searchInput, '', $searchType);
	$total = count($rows);
	$id = array();
	$ppt = array();
	$qtty = array();
	$time = array();
	$geoDist = array();

	//var_dump('I am your needs');
	if($total>0){

		foreach($rows as $row){
			$id[] = $row['donlist_id'];; 
			$ppt[] = $row['item_list']; 
			$qtty[] = $row['qtty']; 
			$time[] = $usersView->time($row['donation_date']); 
			$source_lat = $row['lat'];
			$source_lng = $row['lng'];
			$geo = $usersView->fetchUser();
			$uid = $geo[0]['profile_id'];
			$userLat = $geo[0]['lat']; 
			$userLng = $geo[0]['lng'];

			$geoDist[] = round($usersView->harvesineF($source_lat, $userLat, $source_lng, $userLng));
		}
	}
		echo json_encode(array("type"=>$searchType, "id" => $id, "item_list"=>$ppt, "qtty"=>$qtty, "time"=>$time, "geoDist"=>$geoDist, "total"=>$total));
}
elseif($searchType==2){
  $rows = $usersView->fetchSrch($searchInput, '', $searchType);
	count($rows) > 0 ? $total = count($rows) : $total=0;
	$firstname = array();
	$lastname = array();
	$cii = array();
	$n_assist = array();
	$regDate = array();
	
	$requests = array();
	$returns = array();
	$nImpacts = array();
	$fdItems = array();
	$rank = array();
	$jd = array();
	if($total>0){
		foreach($rows as $row){
			$firstname[] = ucfirst($row['firstname']);
			$lastname[] = ucfirst($row['lastname']);
			$cii[] = $row['cii'];
			$n_assist[] = floor($row['cii']/2);
//			$regDate[] = $row['join_date'];
			$xkrollite = $row['profile_id'];
			$vals= $xkrollite.', 1';
	//		$reqVals = $xkrollite.', 0';
			$fdiVals = $xkrollite.', 1';
  $userData = $usersView->select('skyman_user', ' WHERE profile_id=?', $xkrollite);
  $jd[] = $userData[0]['join_date'];
  $rank[] = $usersView->CiL($row['cii'], $userData[0]['join_date']);
			
  $ret = $usersView->select('found_asset', ' WHERE user_id=? AND claimed=?', $vals);
  $req = $usersView->select('donation', ' WHERE tuser_id=?', $xkrollite);
  $fdi = $usersView->select('donlist', ' WHERE donor=? AND claimed=?', $fdiVals);
  $fdItems[] = count($fdi);
  $requests[] = count($req);
  $returns[] = count($ret);
  $nImpacts[] = count($ret) + floor($row['cii']/2) + count($fdi);
  		}
	}
echo json_encode(array("type"=>2, "fn" => $firstname, "ln"=>$lastname, "cii"=>$cii, "nAss"=>$n_assist, "rank"=>$rank, "nReq"=>$requests, "nRtn"=>$returns, "nFdi"=>$fdItems, "nImpacts"=>$nImpacts, "jd"=>$jd, "total"=>$total));
}
else{

}