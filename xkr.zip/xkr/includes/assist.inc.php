<?php
include('autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();
//echo 'assist loaded';
if(isset($_POST['helperContact'])){
    $don_contact=$_POST['helperContact'];
    $i = $_POST['i'];
//    $needy=$_POST['needy'];
    $donation_id=$_POST[$i.'don_id'];
    $userData = $usersView->fetchUser();

    $donorid=$userData[0]['profile_id'];
//get the needy
    $row0 = $usersView->select('donation', ' WHERE donation_id=?', $donation_id);
    $needy=$row0[0]['tuser_id'];

    $itemReq=$row0[0]['item'];
    $dateGiven=$row0[0]['d_date'];
    $profile_id=$donorid;
    $itemGiven=$donation_id;
    $beneficiary='';
    $assResp='';
    $help_supplied_already = $row0[0]['supplied'];

    $donorProfile = $usersView->fetchUser($donorid);
$pastBeneficiaries = $donorProfile[0]['helped'];
//$don_contact = $donorProfile[0]['contact'];
//check whether needy was helped in the past
      $helpedUsers_list=str_replace("','", " ", $pastBeneficiaries);
        $all_helpedUsers=explode(" ", $helpedUsers_list);
        $eachHelped=array(); $among='';

    foreach ($all_helpedUsers as $each){
            $eachHelped[]=$each;
       if($each==$needy){
          $assResp.='Error, please ensure you are not helping a single needy all the time';
           $among.=true;
       }
       else{$among.=false;}
    }
    
    if($among==false){
        //capture needy ip
      $rowNI = $usersView->select('skyman_user', ' WHERE user_id=?', $needy);
      $needyIP=$rowNI[0]['ip'];
        //check if dsame wt user ip
      $rowUI = $usersView->select('skyman_user', ' WHERE user_id=?', $donorid);
      $donorIP=$rowUI[0]['ip'];
      //check nd correct below line
          if( $help_supplied_already == 0 ){
            //$donorIP=='' || $donorIP!==''){    
              $supplied=1; $hAcesd=0;
              $vals=$don_contact.', '.$donorid.', '.$supplied.', '.$hAcesd.', '.$donation_id;
           $usersContr->update('donation', 'don_contact=?, donor=?, supplied=?, hAcesd=? WHERE donation_id=?', $vals);
 
              $usersContr->updUserActivity($donorid, 'btn_assist');
             //notify needy
              $recipient_id=$needy;
              $found_id=1;
              $donation_id=$donation_id;
              $distress_id=1;
              $msg_id='2';
              $usersContr->msger($recipient_id, $msg_id, $found_id, $donation_id, $distress_id);
              
              $ndy=$usersView->fetchUser($needy);

              $needyName=$ndy[0]['lastname']." ".$ndy[0]['firstname'];
              $needyMail=$ndy[0]['email'];

//              $doNor=$usersView->fetchUser($donorid);
              $donorName=$donorProfile[0]['lastname']." ".$donorProfile[0]['firstname'];
              $willHelpList=$donorProfile[0]['willHelp'];
              $mailNote=$donorProfile[0]['mailNote'];

              //update donor profile
             $newList=$willHelpList.",'".$needy."'";
             $donorVals = $newList.', '.$donorid;
             $usersContr->update('profile', 'willHelp=?, WHERE profile_id=?', $donorVals);
           
            //mail the needy
              $subject='Assist Rendered';
              $to='oladeleolatayojamiu@gmail.com';
              $msg=$donorName." donated ".$itemReq." to ".$needyName;

              //$usersContr->mailer($to, $subject, $msg);
              
              $subjNdy='Help found';
              $msgNdy="Congratulations! Someone has shown interest in gifting you your request of ".$itemReq.". Call ".$don_contact." to retrieve it.";
              $toNeedy=$needyMail;
  
             /*if($mailNote==1){ $usersContr->msger($toNeedy,  $msg_id, $found_id, $donation_id, $distress_id); }
*/
                $assResp.='Your intent to provide help on the needed '.$itemReq.' is acknowledged and the needy has been notified, thanks.';
            //  }else{$assResp.="Error occured, please try again.";}
             }else{$assResp.="Sorry, someone already helped on this. Kindly pick another.";}
            
    }//end of if
}
   echo json_encode(array("ajaxReply" => $assResp));
