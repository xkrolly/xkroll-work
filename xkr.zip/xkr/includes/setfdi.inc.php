<?php
	include('autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();

	$item_code = $usersView->sanitise($_POST['giftList']);
	$qNum = $usersView->sanitise($_POST['qNum']);
	$uom =$usersView->sanitise($_POST['uom']);

        switch($item_code){
        	case 1:	$item = "Movies"; break;
        	case 2:	$item = "Rice"; break;
        	case 3:	$item = "Beans"; break;
        	case 4:	$item = "Yam"; break;
        	case 5:	$item = "Petrol"; break;
        	case 6:	$item = "Cooking gas"; break;
        	case 7:	$item = "Pressing Iron"; break;
        	case 8:	$item = "Electric Fan"; break;
        	case 9: $item = "Air con"; break;
        	case 10: $item = "Cooking cylinder"; break;
        	case 11: $item = "Microwave"; break;
        	case 12: $item = "Tuition fee"; break;
        	case 13: $item = "Rental fee"; break;
        	case 14: $item = "Textbook"; break;
        	case 15: $item = "Novels"; break;
            case 16: $item = "Others"; break;
         	return $item;
        }
       


if($item_code==1){
	$all_movies = count($_FILES['file']['name']);
$mv = array();
	for($i=0; $i<$all_movies; $i++){
		$file = $_FILES['file']['name'][$i];
		//$file=str_replace('.mp4', '', $file);
		$file = substr($file, 0, strrpos($file, '.'));
		array_push($mv, $file);
    }
    empty($qNum) ? $qNum = $all_movies : $qNum = 1;
}

    $item_code == 1 ? $item_names = implode('..', $mv) : $item_names= $item;

switch($uom){
    case 1: $unitQ = 1; break;
    case 2: $unitQ = 1; break;
    case 3: $unitQ = 1; break;
    case 4: $unitQ = 10; break;
    case 5: $unitQ = 500; break;
    case 6: $unitQ = 1; break;
    case 7: $unitQ = 1; break;
    case 8: $unitQ = 1000; break;
return $unitQ;
}
	$qtty = $qNum * $unitQ;

$user = $usersView->fetchUser();
$lat = $user[0]['lat'];
$lng = $user[0]['lng'];
$donor = $user[0]['profile_id'];

$ddr = time() + (48*3600);
$elapse_date = date('Y-m-d h:i:s', $ddr);

$reply='';

/*var_dump('item_code = '.$item_code.'  item_list = '.$item_names.' qtty = '.$qtty.'  donor = '.$donor.'  lat = '.$lat.'  lng = '.$lng.'  elapse_date = '.$elapse_date);
*/
	$data = array('item_code'=>$item_code, 'item_list'=>$item_names, 'qtty'=>$qtty, 'donor'=>$donor, 'lat'=>$lat, 'lng'=>$lng, 'elapse_date'=>$elapse_date);
    $usersContr->insert('donlist', $data);
$reply.="Successfully donated now";


echo json_encode(array("ajaxReply"=> $reply));