<?php
	include('autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();

$selectedOption = $usersView->sanitise($_POST['selectedOption']);
$did = $usersView->sanitise($_POST['did']);

//check if nhelp accessed
$rowH = $usersView->select('donation', ' WHERE donation_id = ?', $did);
$helpAccessed = $rowH[0]['hAcesd'];
if($helpAccessed == 0){
	$vals='1, '.$did;
	$usersContr->update('donation', 'hAcesd=? WHERE donation_id = ?', $vals);

	$row = $usersView->select('donation', ' WHERE donation_id = ?', $did);
	$donor = $row[0]['donor'];

	$donor_row = $usersView->select('profile', ' WHERE profile_id = ?', $donor);
	$donor_cii = $donor_row[0]['cii'];
	$updated_donor_cii = $donor_cii + $selectedOption; 
	$donor_data = $updated_donor_cii.', '.$donor;

	$usersContr->update('profile', 'cii=? WHERE profile_id = ?', $donor_data);
		echo json_encode(array("ajaxReply"=> 'Helper successfully assessed', "did"=>$did));
}
