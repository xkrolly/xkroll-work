<?php
include('autoloader.inc.php');
$login='';
$href='';

$usersView = new usersView();
$usersContr = new usersContr();

if(isset($_POST['uname']) && isset($_POST['pwd'])){
//	$uname=$usersView->sanitizer($_POST['uname']);
    $uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $lat_login = $usersView->sanitise($_POST['latd']);
    $lng_login = $usersView->sanitise($_POST['lngd']);
   
    isset($_POST['kpLogged']) ? $dur=$_POST['kpLogged'] : $dur=0;
   
        if(!empty($uname) && !empty($pwd)){
            $userData=$usersView->select('skyman_user', ' WHERE username = ?', $uname);
/*is_numeric($uname) ? 
            $userData2=$usersView->select('profile', ' WHERE contact = ?', $uname);
            
            if(count($userData2) > 0){
                $userProfile = $userData2[0]['profile_id'];
                $userData = $usersView->select('skyman_user', ' WHERE user_id = ?', $userProfile);
            }
*/
            if(password_verify($pwd, $userData[0]['password'])){
                $pwd=password_hash($pwd, PASSWORD_DEFAULT);

               if($userData[0]['ban']==0){
                     $pid = $userData[0]['user_id'];
                     $_SESSION['user_id'] = session_id().sha1($uname);
                  
                    !empty($lat_login) ? $_SESSION['loadNewsFeed'] = true : $_SESSION['loadNewsFeed']=false;
//                     New insertion
                    $_SESSION['geoloc_switch_query']=0;
                    $_SESSION['lat'] = $lat_login;
                    
                    /*$userLoginData=$usersView->select('skyman_user', ' WHERE session = ?', $_SESSION['user_id']);*/
                    $regCompleted='';
                    
                    $userData2=$usersView->select('profile', ' WHERE profile_id = ?', $pid);
                    $regCompleted='';
                    
                    if(!empty($userData2['lastname']) && !empty($userData2['firstname']) && !empty($userData2['city']) && !empty($userData2['contact'])){
                        $regCompleted.=1;
                    }else{
                        $regCompleted.=0;
                    }
                    $vals= $regCompleted.', 0, '.$lat_login.', '.$lng_login.', '.$pid;
                    $usersContr->update('profile', 'regCompleted = ?, pgvw = ?, lat=?, lng=? WHERE profile_id = ?', $vals);

                  $usersView->update_Impact($pid, 0);


//                    $session=session_id();
//                    $_SESSION['user_id'] = session_id();//.sha1($userData2[0]['contact']);
                  
                    $ip = $usersView->getIP();
                    $vals2= $_SESSION["user_id"].', 1, '.$dur.', '.$ip.', '.$userData[0]['user_id'];;
                    $usersContr->update('skyman_user', 'session = ?, online = ?, eternity=?, ip=? WHERE user_id = ?', $vals2);
                    $href.='login';
                }
                else{
          
                $login.="Sorry, No access for you! Your Xkroll account has been banned due to violation of our policies.";
                }
            }
            else{
          
                $login.="Sorry! you must enter a valid username and password to log in.";
            }
        }
        else{
            $login.='Sorry! You must enter your username and password to log in.';
        }
    	echo json_encode(array('ajaxReply' => $login, 'url' =>$href));
}