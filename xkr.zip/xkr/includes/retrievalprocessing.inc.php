<?php
  include('autoloader.inc.php');
$usersContr = new usersContr();
$usersView = new usersView();

//mssg the owner
$city = $usersView->sanitise($_POST['cityy']);
$contact = $usersView->sanitise($_POST['tel']);
$lst_id = $usersView->sanitise($_POST['lid']);
$_ppt_img = $_FILES['file']['name'];

    

$lstData = $usersView->select('lst_item', ' WHERE lst_id=?', $lst_id);
$lst_item = $lstData[0]['ppt'];
$recipient_id = $lstData[0]['user_id'];
$msg_id = 7;
$donation_id = 1;

$distress_id = 1;

$userData = $usersView->fetchUser();
$uid = $userData[0]['profile_id'];
$lat = $userData[0]['lat'];
$lng = $userData[0]['lng'];

$imgDir='';
if(!empty($_ppt_img)){
$ppt_img = $_FILES['file']['tmp_name'];
$storage_folder='retrieved';
	$imgDir.=$uid.substr($storage_folder, 0, 1).time();
      move_uploaded_file($ppt_img, "../img/".$storage_folder."/".$imgDir.".webp");
}
$data = array('user_id'=>$recipient_id, 'contact'=>$contact, 'city'=>$city, 'img'=>$imgDir, 'ppt'=>$lst_item, 'lat'=>$lat, 'lng'=>$lng);
$usersContr->insert('found_asset', $data);

$vars = $recipient_id.' '.$contact.' '.$city.' '.$lst_item.' '.$lat.' '.$lng;
//var_dump($vars);
$found_Data = $usersView->select('found_asset', ' WHERE user_id=? AND contact=? AND city=? AND ppt=? AND lat=? AND lng=?', $vars);
$found_id = $found_Data[0]['found_id'];

$usersContr->msger($recipient_id, $msg_id, $found_id, $donation_id, $distress_id);
$Resp ='Wonderful! You have successfully informed the owner of the item. You will be reached on '.$contact.' to aid its retrieval by them. Thanks.';
   echo json_encode(array("ajaxReply" => $Resp));
