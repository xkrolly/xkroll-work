<?php
            echo          "<h5>Item description</h5><br>".
                             "<div class='form-group'>".
                                                "<label class='control-label col-sm-10'>Property</label>".
                                    "<div class='col-sm-12'>
                                                <input type='text' maxlength=20 class='form-control' name='ppt' id='ppt' placeholder='Name of property (20 characters max.)' autocomplete='true'
                                                pattern='^(?=.{2,20})(([\d]*).*\w*)*$'
                                                 title='Input must be 2 - 20 characters max.'/>
                                    </div>
                             </div>".
                      "<div class='form-group'>
                                    <label class='control-label col-sm-10'>Succinct Property description</label>".
                           "<div class='col-sm-12'>
                                    <textarea class='form-control' name='spec1' id='spec1' maxlength=100 rows=2 cols=20 placeholder='Describe in 100 characters max.'></textarea>".
                           "</div>
                       </div>";
