<?php

include('autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();


$mobile= $_POST['mobile'];
$otp_code = $_POST['otp'];
//echo 'I am otp: '.$otp_code;

$data = $mobile.' '.$otp_code;
$check = $usersView->select('rac', ' WHERE contact=? AND code=?', $data);

if(count($check) > 0){


	$mobile_array = array("contact"=>$mobile, "regCompleted"=>0);
	$newUserData = $usersView->select('profile', ' WHERE contact=?', $mobile);
  if(count($newUserData)==0){
		$usersContr->insert('profile', $mobile_array);
    	
    	$newUserData = $usersView->select('profile', ' WHERE contact=?', $mobile);
		$profile_id = $newUserData[0]['profile_id'];
		$userData_array = array("profile_id"=>$profile_id, "online"=>'1');
    
		$usersContr->insert('skyman_user', $userData_array);
		$newUserID = $usersView->select('skyman_user', ' WHERE profile_id=?', $profile_id);

		//delete rac
		$usersContr->delete('rac', ' WHERE contact=?', $mobile);

		$_SESSION['user_id'] = $newUserID[0]['user_id'];
		$_SESSION['loadNewsFeed'] = true;
		$_SESSION['geoloc_switch_query'] = 0;
		header('location: ../index.php');
	}else{
		//echo json_encode(array('ajaxReply' => 
		echo "Sorry, this mobile already exists";
		//));
	}

}else{
//	echo json_encode(array("ajaxReply"=> 
	echo "Your OTP is incorrect, try again!";
	//));
 
}