<?php
include('autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();

if(isset($_POST['mobileNum'])){

    //$userNum=$usersView->sanitizer($_POST['mobileNum']);
    //$v_code = bin2hex(random_bytes(16));
    $code=rand(10000, 99999);
    $email=$_POST['mobileNum'];


if(!empty($userMail)){
  $userData = $usersView->select('profile', ' WHERE email=?', $userMail);

  if(count($userData) == 0){
      $data=array('user_id'=>'', 'email'=>$userMail, 'code'=>$code);

    $usersContr->insert('rac', $data);
    $email_wt_code = $userMail.', '.$code;
 
    $userInfo = $usersView->select('rac', ' WHERE email=? AND code=?', $email_wt_code);

    if(count($userInfo) == 0){

    $rac_id = $userInfo['rac_id'];
       $rlink='https://www.xkroll.com/regconf.php?rc='.$rac_id.'&m='.$userMail;
    $usersView->confirmReg($rlink, $userMail);
        $reply='You are one step away, check '.$userMail.' to access your confirmatory link to complete your registration.';
    }
    else{
          $reply="The email already exist, kindly use another one to register. Thanks!";
    }
  }
    else{
          $reply="Sorry, an error occured. Please try again.";
    }
  echo json_encode(array("ajaxReply"=> $reply));
  
 }
}