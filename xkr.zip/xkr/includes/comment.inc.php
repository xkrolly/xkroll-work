<?php
	include('../includes/autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();

	  $comment = $_POST['comment'];
	  $discussId= $_POST['discussId'];
	  $user = $_SESSION['user_id'];

$val=$comment.' '.$discussId;
	$dbPresence = $usersView->select('comments', ' WHERE comment=? AND discussId=?', $val);
	  $data = array("comment"=>$comment, "discussId"=>$discussId, "user"=>$user);
	if(count($dbPresence)==0){
	  if($usersContr->setValue('comments', $data)){
	  		echo json_encode(array("commentResp"=> $comment, "discussId"=>$discussId, ));

	  	}else{
	  		$reply = 'failed';
			echo json_encode(array("commentResp"=> $reply));
	  	}
	  }
