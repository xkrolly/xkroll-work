<?php
  
  include('autoloader.inc.php');
$usersContr = new usersContr();
$usersView = new usersView();

isset($_POST['dm']) ? $dm=$_POST['dm'] : $dm='';

isset($_POST['media']) ? $med_setn=$_POST['media'] : $med_setn=0;
isset($_POST['mailNote']) ? $mailNote=1 : $mailNote=0;

isset($_POST['img']) ? $p1=$_POST['img'] : $p1='';
isset($_POST['pinfo']) ? $p2=$_POST['pinfo'] : $p2='';
isset($_POST['address']) ? $p3=$_POST['address'] : $p3='';
isset($_POST['contact']) ? $p4=$_POST['contact'] : $p4='';
isset($_POST['mediaDetail']) ? $p5=$_POST['mediaDetail'] : $p5='';

isset($_POST['def_range']) ? $dr=$_POST['def_range'] : $dr='';
isset($_POST['req_range']) ? $rr=$_POST['req_range'] : $rr='';
isset($_POST['aud_req']) ? $ar=$_POST['aud_req'] : $ar='';

$other_setins=$ar.$rr;

isset($_POST['unblock']) ? $unblock_s=' "\'0\'"' : $unblock_s='';
$unblock_s=='' ? $blocked='' : $blocked=', blocked=?';

//auto media
$usersView->fetchUser();
$user_id = $userData[0]['profile_id'];
isset($_POST['autoMed']) ? $autoMed=$_POST['autoMed'] : $autoMed='0';
$profile_det=$p1.$p2.$p3.$p4.$p5;
$vals=$dm.', '.$other_setins.', '.$dr.', '.$profile_det.', '.$autoMed.', '.$mailNote.', '.$med_setn.$unblock_s.', '.$user_id;
	
	$usersContr->update('profile', 'dm=?, other_setins=?, def_range=?, prof_setin=?, media_auto=?, mailNote=?, media_setin=?'.$blocked.' WHERE profile_id=?', $vals);

		$setnReply="Settings saved!";

	echo json_encode(array("ajaxReply" => $setnReply));

	