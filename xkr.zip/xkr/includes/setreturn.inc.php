<?php
	include('autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();
	$rptType=$usersView->sanitise($_POST['report-type']);

//	$user = $usersView->fetchUser();
	$user = $usersView->fetchUser();
	$uid = $user[0]['profile_id'];
	$user_lat = $user[0]['lat'];
	$user_lng = $user[0]['lng'];
	$description = $user[0]['tmp_aud'];
			
		if($rptType==1 || $rptType==2){
			$ppt=$usersView->sanitise($_POST['item']);
		$rptType == 1 ? $city = '' : $city=$usersView->sanitise($_POST['city']); 

		$rptType == 1 ? $tableName ='lst_item' : $tableName ='found_asset';
		
		$rptType == 1 ? $updVal="rpt" : $updVal = "rtn";

		
		$rptType==1 ? $column="description" : $column="city";
		$rptType==1 ? $columnVal=$description : $columnVal=$city;
		
		$data = array("ppt"=>$ppt, $column=>$columnVal);
	    $usersContr->updUserActivity($uid, $updVal);
    
	    if($usersContr->setReport($tableName, $data, $rptType)){
	    	$reply = $usersContr->reply;
		}else{$reply= 'Report failed, pls try again!';}
	
	}elseif($rptType==3){
		$user = $usersView->fetchUser();
		$user_lat = $user[0]['lat'];
		$user_lng = $user[0]['lng'];
		$uid = $user[0]['profile_id'];
		$description = $usersView->sanitise($user[0]['tmp_aud']);

		$ppt = $usersView->sanitise($_POST['property']);
		$item = $usersView->sanitise($_POST['item']);
		if($ppt == 6){
			//$item = $usersView->sanitise($_POST['item']);
			$data = array("user_id"=>$uid, "ppt"=>$item, "stolen"=>1, "description"=>$description, "lat"=>$user_lat, "lng"=>$user_lng);
		}
		elseif($ppt == 7){
			//$item = $usersView->sanitise($_POST['item']);
			$data = array("user_id"=>$uid, "ppt"=>$item, "stolen"=>1, "description"=>$description, "lat"=>$user_lat, "lng"=>$user_lng);
		}else{

			$ppt_img = '';
			//$usersView->sanitise($_FILES['pptImg']['name']);
	 		//$desc = $usersView->sanitise($_POST['desc']);
	 		
	 		$make = $usersView->sanitise($_POST['make']);
			$model = $usersView->sanitise($_POST['model']);
			$color = $usersView->sanitise($_POST['color']);
			$engnum = $usersView->sanitise($_POST['engine-number']);
			$chasisnum = $usersView->sanitise($_POST['chassis-number']);
			$numplate = $usersView->sanitise($_POST['number-plate']);

				switch($ppt){
					case 1:
						$_ppt = 'Car';
						break;
					case 2:
						$_ppt = 'Bus';
						break;
					case 3:
						$_ppt = 'Truck';
						break;
					case 4:
						$_ppt = 'Motorcycle';
						break;
					case 5:
						$_ppt = 'Powerbike';
						break;
				}

			$data = array("reporter"=>$uid, "ppt"=>$_ppt, "make"=>$make, "model"=>$model, "color"=>$color, "engine_num"=>$engnum, "chassis_num"=>$chasisnum, "num_plate"=>$numplate, "ppt_img"=>$ppt_img, "description"=>$description, "lat"=>"", "lng"=>"");
		}
	
		$ppt == 6 ? $tableName= 'lst_item' : $tableName ='stolen_asset';
	 		$data['lat'] = $user_lat;
			$data['lng'] = $user_lng;

		$updVal="theft";	
 		$usersContr->updUserActivity($uid, $updVal);
		$usersContr->setReport2($tableName, $data);
		$reply = $usersContr->reply;
	}
	echo json_encode(array("ajaxReply"=> $reply));		
	