<?php

//include('autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();
	$uid = $_SESSION['user_id'];

	$un = $_POST['_username'];
	$pwd = $_POST['_passphrase'];
	$w_pn = $_POST['_contact'];
	$fn = $_POST['_firstname'];
	$sn = $_POST['_lastname'];
//	$data = $fn.", ".$sn.", ".$w_pn.", 1, ".$uid;

            //if(password_verify($pwd, $userData[0]['password'])){}
                $pw=password_hash($pwd, PASSWORD_DEFAULT);

if(!empty($un) && !empty($pw) && !empty($w_pn) ){
	$data = $fn.", ".$sn.", ".$w_pn.", 1, ".$uid;
	$usersContr->update('profile', 'firstname=?, lastname=?, wContact=?, regCompleted=? WHERE profile_id=?', $data);

$data2 = $un.", ".$pw.", ".$uid;
	
$usersContr->update('skyman_user', 'username=?, password=? WHERE user_id=?', $data2);

	$reply = "Registration successfully completed. You may upload your profile image right now or later.";

}
else{$reply = "Fill out all the form fields!";}
	echo json_encode(array("ajaxReply"=> $reply));
