<?php
$nav='<header style="position:fixed; bottom:0; z-index:9;">
            
        <nav class="navbar" onclick=$("#completeReg").show() style="width:100%; position:fixed; bottom:0%; filter:drop-shadow(2px 2px 2px #999); background-color:#fff; color:#ccc; display:flex; justify-content:space-around;"> 
                    <div><a class="nav-link hover" href="home" onclick="getLocation()">
                      <span class="material-icons nav-icon">&#xe88a;</span>
                    </a></div>
                    <div><a href="returns" class="nav-link hover">
                      <span class="material-icons nav-icon">&#xe15e;</span>
                    </a></div>
                    <div><a class="nav-link hover" id="notifier" href="notification">
                      <span class="material-icons nav-icon">&#xe7f4;</span><sub class="inbox notifier"></sub>
                    </a></div>
                    <div><a class="nav-link hover" href="search">
                      <span class="material-icons nav-icon">&#xe8b6;</span>
                    </a></div>
                    <div><a class="nav-link hover" onclick=$("#navOverflow").show()>
                      <span class="material-icons nav-icon">&#xe5d2;</span>
                    </a></div>
                
        </nav>
        <div id="navOverflow" class="navOverflow" style="display:none; position:fixed; right:0; background:#fff; padding:10px; border:1px solid #ccc; border-bottom:0px;">
                          <a class="nav-link hover" href="profile" style="border-bottom:0px; color:#eee;">
                             <span class="material-icons nav-icon">&#xe7fd;</span>
                                    Profile000
                          </a>
                          <a class="nav-link hover" href="settings" style="border-bottom:0px;">
                             <span class="material-icons nav-icon">&#xf02e;</span>Account Settings
                          </a>
                          <hr>
                          <a href="logout" class="nav-link hover" style="text-decoration:none; margin-top:-15px;">
                                <span class="material-icons nav-icon">&#xe9ba;</span>Logout
                          </a>
            </div>
      </header>';
/*      $nav .='<div class="them" id="searchPanel" style="background:#888; padding:1px; position:fixed; right:0; left:0; bottom:0; z-index:20; display:none;">
        <div style="text-align:center;"><i class="fa fa-minus" style="font-size:20px; color:white;" onclick=$("#searchPanel").slideUp("slow");></i></div>
        <form method="post" id="search_data">
          <input type="hidden" name="searchType" value="1">
          <div style="display:flex; flex-direction:column; align-items:center; margin:20px;">
            <div style="display:flex; font-size:20px; border:1px solid #aaa; border-radius:5px;">
              <button type="submit" name="submit" tabindex=3 class="" id="search_btn" style="width:10vw; background:#fff; border:1px solid #aaa; border:transparent; border-top-left-radius:5px; border-bottom-left-radius:5px; padding:6px;">
                  <i class="fa fa-search" style="font-size:16px; color:#aaa;"></i>
              </button>
              <input type="search" incremental name="input" placeholder="Search losts or needs..." aria-label="Search the pool of found properties for your lost item" style="padding:6px; font-size:16px; width:52vw; border:1px solid #aaa; border:transparent; border-right:1px solid #aaa;" />
                        <input type="search" name="city" placeholder="add City..." style="border-top-right-radius:5px; width:32vw; padding:6px; font-size:16px; border:1px solid #aaa; border:transparent; border-bottom-right-radius:5px;" />
    
            </div>
          </div>
        </form>
       </div>
      <div style="padding:2px; margin-bottom:0px;">
          <span id="search_results"></span>
      </div>';
*/
return $nav;