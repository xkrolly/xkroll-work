<?php
 $usersView = new usersView();
$row = $usersView->fetchUser($_SESSION['user_id']);
$regCompleted = $row[0]['regCompleted']; 
$nav = '';
if($regCompleted==0){
  $nav .= $usersView->showModal('includes/completeReg.inc.php', 'completeReg', 'file');
}

$nav .='<header style="position:fixed; bottom:0; z-index:19;">
            
        <nav class="navbar" onclick=$("#completeReg").show() style="width:100%; position:fixed; bottom:0%; filter:drop-shadow(2px 2px 2px #999); background-color:#fff; color:#ccc; display:flex; justify-content:space-around;"> 
                    <div><a class="nav-link hover" href="home" onclick="getLocation()">
                        <span class="material-icons" style="font-size:30px;">&#xe88a;</span>
                    </a></div>
                    <div><a href="returns" class="nav-link hover">
                        <span class="material-icons" style="font-size:30px;">&#xe15e;</span>
                    </a></div>
                    <div><a class="nav-link hover" id="notifier" href="notification">
                         <span class="material-icons" style="font-size:30px; padding:0px; margin:0px;">&#xe7f4;</span>
                         <sub class="inbox notifier"></sub>
                    </a></div>
                    <div><span class="nav-link hover" href="search" onclick=$("#searchPanel").slideDown("slow")>
                    <span class="material-icons" style="font-size:30px;">&#xe8b6;</span>
                    </span></div>
                    <div onclick=$("#navOverflow").show()>
                      <span class="nav-link hover">
                          <span class="material-icons" style="font-size:30px;">&#xe5d2;</span>
                      </span>
                    </div>
        </nav>
        <div id="navOverflow" class="navOverflow" style="display:none; position:fixed; right:0; background:#fff; padding:10px; border:1px solid #ccc; border-bottom:0px;">
            <a class="nav-link hover" href="profile" style="border-bottom:0px;">
                            <i class="fa fa-user nav-icon" style="margin-right:10px;"></i>
                                    Profile
                          </a>

                          <a class="nav-link hover" href="settings" style="border-bottom:0px;">
                            <i class="fa fa-cog nav-icon" style="margin-right:10px;"></i>
                             Account Settings
                          </a>
                          <a class="nav-link hover" href="distress" style="border-bottom:0px;">
                            <i class="fa fa-fire nav-icon" style="margin-right:10px;"></i>
                             Distress Settings
                          </a>
                          <hr>
                          <a href="logout" class="nav-link hover" style="text-decoration:none; margin-top:-15px;">
                            <i class="fa fa-log-out nav-icon" style="margin-right:10px;"></i>
                                Logout
                          </a>
          </div>
      </header>';
       $nav.=$usersView->searchPanel();

return $nav;