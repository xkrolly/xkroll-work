<?php
//<a href='sms:{07037940894}?body={how far}'>send msg</a>
      $did= $fd[$ln]['donation_id']; 
      $needy= $fd[$ln]['tuser_id']; 
      $donor= $fd[$ln]['donor']; 
      $item = $fd[$ln]['item'];
      $txt= $fd[$ln]['proof'];
      $emp= $fd[$ln]['empathy'];
      $ban= $fd[$ln]['nonreal'];
      $_snapshot= $fd[$ln]['img_proof'];
      $useMedia= $fd[$ln]['useMedia'];
      $media_setins= $fd[$ln]['media_setins'];
      
      $nplayed= $fd[$ln]['played'];
      $callType=$fd[$ln]['callType'];
      $global= $fd[$ln]['global'];
      $fd_lat = $fd[$ln]['lat'];
      $fd_lng = $fd[$ln]['lng'];
      $user_lat = $fd[$ln]['userLat'];
      $user_lng = $fd[$ln]['userLng'];
      $prof_pic = $fd[$ln]['picture'];
      $fdPoster=$needy;
      $vote= $fd[$ln]['vote'];
$txt2='just testing it to see if it is working.';    
  $txt3 = 'text3';
  $allComments = $this->select('comments', ' WHERE discussId = ?', $did);

      $_dist = $this->harvesineF($user_lat, $user_lng, $fd_lat, $fd_lng);
      $dist = round($_dist, 2) . 'km';
  
      $global==1? $status='fa-globe fa-spin' : $status='fa-location-arrow';
      $global==1? $statusDesc = 'Global' : $statusDesc = 'Local ~';
      $global==1 ? $dist = '' : $dist = $dist;
// capture user-specific data
  $user_id=$_SESSION['user_id'];
  $userSetin = $this->fetchUser($user_id);
  
  $callerId = $this->fetchUser($needy);
  $caller_pic = $callerId[0]['picture'];
  
  $ndyData = $this->fetchUser($needy);
  $ndyContact = $ndyData[0]['contact'];
            
  $userContact = $userSetin[0]['contact'];
  $other_setins=$userSetin[0]['other_setins'];
  $empathy = $userSetin[0]['n_assist'];
  $prof_setin = $userSetin[0]['prof_setin'];
  $gender = $userSetin[0]['gender'];
  $gender=='m'? $gender='Male':($gender =='f' ? $gender = 'Female' : $gender = 'Custom');
  
  $_aud_req=1;
  similar_text($other_setins, $_aud_req, $perc);
  $perc > 0 ? $useAudioReq=1 : $useAudioReq=0;  

  $def_range=$userSetin[0]['def_range']*1000;
  $_useDefRange=2;
  similar_text($other_setins, $_useDefRange, $perc2);
  $perc2 > 0 ? $useDefRange=2 : $useDefRange=0;  
      
  $callType==1 ? $imgDir='donations/' : $imgDir='request/';
  $snapshot=$imgDir.$_snapshot;                     
  ($this->media_setins==1 || $this->media_setins==4 || $this->media_setins==5) ? $snapshot=$snapshot : $snapshot='request/';
  $snapshot1="<img src='$snapshot' class='img-round img-thumbnail image-responsive'>";

    $b=$a++;
    $p1=str_ireplace("1", "a", $b);
    $p2=str_ireplace("2", "b", $p1);
    $p3=str_ireplace("3", "c", $p2);
    $p4=str_ireplace("4", "d", $p3);
    $p5=str_ireplace("5", "e", $p4);
    $p6=str_ireplace("6", "f", $p5);
    $p7=str_ireplace("7", "g", $p6);
    $p8=str_ireplace("8", "h", $p7);
    $p9=str_ireplace("9", "i", $p8);
    $p0=str_ireplace("0", "j", $p9);
    $i=$p9;

      $callType==3 ? $imgDir='donations/' : $imgDir='request/';
      
        $vote==2 ? $emp_color='red' : $emp_color='#929292';
        $vote==2 ? $ban_color='#000' : $ban_color='#929292';
        $emp_style='color:transparent; margin-bottom:10px; -webkit-text-stroke-width:1.4px; -webkit-text-stroke-color:'.$emp_color.'';
        $ban_style='color:transparent; margin-bottom:10px; -webkit-text-stroke-width:1.4px; -webkit-text-stroke-color:'.$ban_color;

      $myMode=$this->dm;
      $myMode==1? $mode="#232323" : $mode="#fff"; 
      $myMode==1? $mode2="#fff" : $mode2="#232323";
      $myMode==1? $mode3="#fff" : $mode3="#858588";   
      $useMedia==1 ? $LorV='Listens' : $LorV='Views';

  $nnplay="<label class='nnplay-".$did."' id='nnplay-".$did."' style='color:#2196f3'>".$nplayed."</label>";
  $activity = "<sub>".$nnplay." ".$LorV."</sub>";

  $nComments=count($allComments);
  $comment = "<sub>".$nComments." Comments</sub>";

      $callType == 1 ? [$headingBgColor="#f01e6b", $headingColor="white", $alert="<i class='fa fa-bell' style='-webkit-text-stroke-width:1px; -webkit-text-stroke-color:black; color:white;'></i>"] : [$headingBgColor = "#ddd", $headingColor ="#555", $profileImg="<img src='img/".$caller_pic."' loading='lazy' alt='profile picture' style='border-radius:50%; width:30px; height:30px;'/>"];
      $fontSize="35px";
      $itemReq="<label class='item".$did."' style='padding:2px; font-size:35px; font-weight:bold; font-family:Lobster; color:$headingColor;'>$item</label>";
  
      empty($txt) ? $heading='' : $heading=$item;

      //eachFeed starts here
       $form=$this->searchPanel();

$form.="<div class='homeFeed homeFeed".$i."' id='homeFeed".$did."' style='margin-bottom:10px; filter:drop-shadow(-1px 1px 1px #444)'>
        <div class='container'>
          <div class='far-left'>$profileImg</div>
          <div class='title' style='border-radius:10px; padding:1px; color:$headingColor'>
          </div>
          <div class='far-right' onclick=$('#".$i."info').show()>
            <span class='material-icons md'>&#xe5d4</span>
          </div>
        </div>";

      ($media_setins == 3 || $media_setins == 5) ? 
      $source = "<source src='sounds/user_audio/$txt.webm' type='audio/webm'>" : 
      $source = "";

      $audioProof="<audio controls id='u_note".$did."' class='u_note'>".$source."</audio>";
      $useMedia==0 ?
      $proofFormat = $txt : $proofFormat =$audioProof;
      empty($proofFormat) ? $proofFormat = $itemReq : $proofFormat;

$form.="<div class='container'>
          <div class='content item' id='itemContainer".$did."'>".$itemReq."
          </div>
        </div>";
$form.="<div class='container' id='proof".$did."' style='display:none;'>
         <div style='text-align:center;'>".$proofFormat."</div>
        </div>";
      
      $actionBtn="<form id='grabFDI".$did."'>";
      if($needy==$user_id){
          $callType == 2 ? 
          $actionBtn.="<div onclick=$('#".$i."deletable') class='btnSmall btn' style='background:#fbf9fb;'>Delete</div>" :
          ($callType==3 ? $actionBtn.="<div class='btnSmall btn grabFDI' style='color:green'>Grab</div>" : $actionBtn="");
      }
      else{  
          $callType == 2 ? 
          $actionBtn.="<div class='btn sm btnColor' onclick=$('#".$i."assist').show()>Assist</div>" :
          
          ($callType==3 ? $actionBtn.="<div class='btnSmall btn grabFDI' style='color:green'>Grab</div>" : $actionBtn="");
      }
      $actionBtn.="<input type='hidden' name='donid' value='$did'></form>";

$callType==2 ? $icon1="&#xe87d;" : $icon1='&#xe8dc;';
$callType==2 ? $fa_icon1="&#xe87e;" : $fa_icon1='&#xe8dc;';
$callType==2 ? $fa_icon2='&#xe14b;' : $fa_icon2='&#xe8db;';
$callType==2? $fa_text1='Empathy' : $fa_text1='Like';
$callType==2? $fa_text2='Ban' : $fa_text2='Dislike';
$callType==1? $faAction="&#xe24c;" : ($useMedia==1 ? $faAction="&#xe1c4;" : $faAction="&#xe873;");

        $all_votes ="<div style='display:flex; align-items:center; font-size:1.5em;'>
                      <sub class='e".$did."' id='e".$did."' style='color:#2169f3'>".$emp."</sub>
                      <span class='material-icons' style='font-size:12px; margin:1px; color:red;'>".$icon1."</span>
                      <span class='material-icons' style='font-size:12px; margin:1px; color:#929292;'>".$fa_icon2."</span>
            <sub class='b".$did." ban_votes' id='b".$did."' style='color:#2196f3; margin:3px;'>".$ban."</sub>
          <label style='margin:3px; height:3px; width:3px; border-radius:50%; background:#aaa;'></label>
            <label style='color:$mode3; font-size:13px; margin:3px;'>
              $activity
            </label>
            <label style='margin:3px; height:3px; width:3px; border-radius:50%; background:#aaa;'></label>
            <label style='color:$mode3; font-size:13px; margin:3px;'>
              $comment
            </label>
          </div>";


$form.="<div class='container '>
         <div class='all_votes'>".$all_votes."</div>
         <div class='actionBtn'>".$actionBtn."</div>
        </div>";
        //    <input type='hidden' value='".$txt."' id='proof".$did."'>
            
$voteBtn = "<form action='' method='post'>
                <input type='hidden' value='".$did."' class='donation_id' id='did".$did."'>
                <input type='hidden' value='".$user_id."' id='tid'>
                <input type='hidden' value='".$callType."' id='callType'>
                <input type='hidden' value='$media_setins' id='media_setins".$did."'>
                <input type='hidden' value='$txt' id='txt".$did."'>
                <input type='hidden' value='0' id='Clikplay".$did."'>
                <input type='hidden' value='".$useMedia."' id='useMedia".$did."'>
                <input type='hidden' value='".$vote."' id='clicked".$did."'>
                <input type='hidden' value='".$emp."' id='".$did."empAll'>
                <input type='hidden' value='".$ban."' id='".$did."banAll'>
            <div class='container'>
              <div class='far-left emp voteBtn' id='emp".$did."' style='width: 100%; text-decoration:none;'>
                            <span class='material-icons'  id='icon".$did."' style='$emp_style; font-size:20px;'>".$fa_icon1."</span>
                                &nbsp;&nbsp;<span style='color:#000; font-family:lucida; text-decoration:italic; font-size:12px; font-weight:bold'>$fa_text1</span>
              </div>
              <div id='comment".$did."' class='center voteBtn' style='text-decoration:none'>
<a href='comment&cid=$did' style='text-decoration:none;'>
        <span class='material-icons' style='color:white; margin-bottom:10px; -webkit-text-stroke-width:1px; -webkit-text-stroke-color:black; font-size:20px;'>".$faAction."</span>
</a>
<span style='color:#878787; font-family:lucida; text-decoration:italic; font-size:12px; font-weight:bold'>
                </span>
              </div>
              <div id='ban".$did."' class='ban voteBtn far-right' style='text-decoration:none;')>
                          <span class='material-icons md ajax' id='icon2".$did."' style='$ban_style; font-size:20px;'>".$fa_icon2."</span>
                <span style='color:#001; font-family:lucida; text-decoration:italic; font-size:12px; font-weight:bold'>$fa_text2
                </span>
              </div>
            </div>
            </form>";

$form.="  <div class='' style='margin-top:2px; padding:5px 10px;'>".$voteBtn."</div>";
$form.="</div>";

//MODAL BELOW
//assist modal
            $chatContact='234'.substr($ndyContact, 1, 10);
            $assistNote="I am ready to assist you on your request of *".$item."*.";
    !empty($userContact) ?
      $addContact="
              <label style='margin-left:-10px; margin-bottom:0px' class='helper_tel collapse'>
                <input type='checkbox' name='helperContactBox' value='".$userContact."' onclick=$('.helper_tel').val('".$userContact."')>&nbsp;&nbsp;Use ".$userContact."
              </label>" : $addContact = '';

$form.=$this->showAssistModal('includes/assistFm.inc.php', $i.'assist', $i, $item, $chatContact, $userContact, $did, $addContact, $assistNote, $ndyContact); 

              $shareNeedy="Please, kindly help out this fellow in need of *".$item."*, and could be reached through ".$ndyContact.". Thanks, God bless you abundantly.\n\nTo contribute in making the world a better place, Join me on Tracus now via https://helpme.com.ng";

              $shareMsg='With this COVID-19 and stay-at-home policy, join me on Tracus community to help people around you or seek help(like food, money etc) when needed. Register now on: https://xkroll.com';
       

$modal_content="<div class='' id='".$i."info' tabindex='-1' role='dialog' aria-hidden='true'>
                  <h5 style='text-decoration:none; color:#454545; text-decoration:italic; text-align:center; padding:1px 0 1px 0; border:2px solid #454545;'>$itemReq</h5>";
                
                $callType==3 ? $callToAction="Recommend to Needy" : 
                  ($callType==2 ? $callToAction = "Recommend to Helper(s)": $callToAction = "Broadcast alert");
$modal_content.="<div style='display:flex column; text-align:left;'>";

$modal_content.="
    <a href=# data-toggle='modal' data-target='#".$i."share' class='optwem hover' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic'>
      <span class='material-icons'>&#xe9d2;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$callToAction."
    </a><br><br>";

      $callType==2 ?
      $addAccount= "<a href=# data-toggle='modal' data-target='#".$i."acctDetail' class='optwem hover' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic'><i class='fa fa-thumbs-up'></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Donate to this course</a><br><br>" :
      $addAccount = "";
                      
$modal_content.=$addAccount;
$modal_content.=" <a href=# class='optwem hover' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic' data-toggle='modal' data-target='#".$i."userProfile'><span style='color:#eee;'>&#xe7fd;</span>User profile</a>";

      $callType!=1 ? 
      $donorDist="<br><br>                  
                      <a href=# class='optwem hover ' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic'><i class='fa $status'></i>&nbsp;&nbsp;&nbsp;&nbsp;$statusDesc $dist</a>" :
      $donorDist = "";

      $needy!=$user_id ?
      $mapLoc=" <br><br>                  
                <a href=# class='optwem hover' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic' data-toggle='modal' data-target='#".$i."mapModal'>
                                 <span class='material-icons' style='color:#eee;'>&#xe0c8;</span>&nbsp;&nbsp;&nbsp;&nbsp;View on map</a>" :
      $mapLoc = "";

$modal_content.=$mapLoc;


      $needy!=$user_id ?
      $whois=" <br><br>                  
                <a href=# class='optwem hover' style='text-decoration:none; color:red; font-family:lucida; text-decoration:italic' data-toggle='modal' data-target='#".$i."blockModal'><span style='color:#eee;' class='material-icons'>&#xe510;</span>Block this user</a>" :
      $whois = "";

$modal_content.=$whois;
$modal_content.="      </div></div>";
$form.=$this->showModal($modal_content, $i.'info', 'code');

        $text='this is text';
        $share_url='https://t.me/share/url?url='.rawurldecode($shareNeedy).'&text='.rawurldecode($text); 
         
$form.="<div class='modal fade' id='".$i."share' tabindex='-1' role='dialog' aria-hidden='true'><br>
            <div class='modal-dialog' role='document'>
              <div class='modal-content'>
                <div class='modal-body'>
                <h5 class='text-center'><a href=#>$callToAction via:</a></h5><hr>
                
                <div class='container'>
                <a href='https://twitter.com/intent/tweet?text=$shareMsg' style='text-decoration:none' class='far-left'><i class='fab fa-twitter' style='font-size:15vmin'></i>
                </a>
                <a href='whatsapp://send?text=".rawurlencode($shareNeedy)."' data-action='share/whatsapp/share' style='text-decoration:none'><i class='fab fa-whatsapp' style='font-size:15vmin'></i>
                </a>
                <a href=\"{$share_url}\" style='text-decoration:none' class='far-right'><i class='fab fa-telegram' style='font-size:15vw'></i>
                </a>
                </div></div>
              </div>
            </div>
          </div>";
          
/*$form.="<div class='modal fade' id='".$i."grabFDI' tabindex='-1' role='dialog' aria-hidden='true'><br>
            <div class='modal-dialog' role='document'>
              <div class='modal-content'>
                <div class='modal-body'>
                <strong>FDI proper</strong><br><br>
                AMOUNT: <strong class='warning'>".$amount."</strong><br>
                BANK: ".$bank_name."<br>
                ACCT NAME: ".$act_name."<br>
                ACCT NUMBER: ".$act_num."<br>
                </div>
              </div>
            </div>
          </div>";*/
$form.="<div class='modal fade' id='".$i."deletable' tabindex='-1' role='dialog' aria-hidden='true'><br>
            <div class='modal-dialog' role='document'>
              <div class='modal-content'>
                <div class='modal-body text-center'>
                <h6>Delete <a href='#'>$itemReq</a> request?</h6><br>
                <p onclick=$('#".$i."deletable').modal('hide')><button onclick=$('#".$i."hid').hide('slow') id='MyReq".$did."' class='delete' style='margin-right:50px;'>Yes</button><button>No</button></p>
                </div>
              </div>
            </div>
          </div>";
return $form;