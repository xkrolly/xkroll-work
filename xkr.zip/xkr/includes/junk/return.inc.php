<?php

 $usersView = new usersView();
 $usersContr = new usersContr();
 $user=$usersView->fetchUser($_SESSION['user_id']);
 $regCompleted = $user[0]['regCompleted'];
// $contact=$user[0]['contact'];
//$audio = $usersView->voiceRec_countDown();

$rForm=$usersView->searchPanel();
$rForm .="
<div class='rtnLxFm' style='align-items:center; justify-content:center; padding-top:1px;'>

           <div style='font-size:1em; font-family:Lucida calligraphy; text-align:center; background:#f01e6b; color:#fff; '>

<p style='margin-bottom:0px;'>Lost & found</p>
<p style='color:yellow; padding:6px; border-radius:4px; font-size:.6em; font-family:Lucida calligraphy;'>Dont lose hope, lets retrieve your lost property together...</p></div>
            <form method='POST' class='form-horizontal rptFm' role='form' id='return_data' style='border-radius:10px; background:#fff; padding-top:0px;'>
            <div style='padding:30px;'>         
                  <div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Select Report*</label>
                    </div>
                    <div class='col-sm-12'>
                        <select class='form-control' required name='rptType' id='rptTyper'>
                            <option value='0'>Select one</option>
                            <option value='1' id='rptType' class='rptType'>Loss</option>
                            <option value='2' required id='rptType' class='rptType'>Discovery</option>
                              <option value='3' id='rptType'>Theft (Stolen)</option>
                        </select>
                        <span id='rpt-select-check'></span>
                    </div>
                </div>
                <div class='form-group pptType' style='display:none;'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Property*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                    <select class='form-control ppt' name='ppt' id='ppt'>
                      <option value='0'>Select property</option>
      
                      <optgroup label='Vehicle'>
                        <option value='1'>Car</option>
                        <option value='2'>Bus</option>
                        <option value='3'>Truck</option>
                      </optgroup>
                      <optgroup label='Motorcycle'>
                        <option value='4'>Bike</option>
                        <option value='5'>PowerBike</option>
                        </optgroup>
                     <optgroup label='Others'>
                        <option value='6'>Others</option>
                     </optgroup>
                   
                    </select>
                    <span id='ppt-select-check'></span>
                    </div>
                </div>
                <div class='form-group item'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Item name*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                        <input type='text' placeholder='e.g. Wrist watch' name='item' id='item' class='form-control em typewriter-effect' value='' max-length='30' required>
                        <span id='item-input-check'></span>

                    </div>
                </div>
                <div class='form-group city' style='display:none;'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>City*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                        <input type='text' placeholder='e.g. Ibadan' name='city' id='city' class='form-control em' value=''>
                        <span id='city-input-check'></span>

                    </div>
                </div>
                <div class='form-group model' style='display:none;'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Make, Model & Color</label>
                    </div>
                
                    <div class='col-sm-12' style='display:flex;'>
                        <select class='form-control col-sm-6' placeholder='Make' style='width:35%; margin-right:2%;' name='make' id='make'>
                        <option value=''></option>
                          <option>Tesla</option>
                          <option>Toyota</option>
                          <option>Mercedes</option>
                          <option>Peugeot</option>
                        </select>
                        <input type='text' class='form-control col-sm-6' placeholder='Model' style='width:35%; margin-right:2%;' name='model' id='model'>
                        <input type='color' value='' class='form-control chasisCol' style='width:10%; padding:2px;' name='color' id='color'>
                    </div>
                </div>

                <div class='form-group vins' style='display:none;'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>VINs</label>
                    </div>
                
                    <div class='col-sm-12' style='display:flex;'>
                    <input type='text' class='form-control col-sm-4' placeholder='Engine num...' style='width:30%; margin-right:2%;' name='vin1' id='vin1'>
                    <input type='text' class='form-control col-sm-4' placeholder='Chassis num...' style='width:30%; margin-right:2%;' name='vin2' id='vin2'>
                    
                    <input type='text' class='form-control col-sm-4' placeholder='Number plate...' style='width:30%; margin-right:2%;' name='vin3' id='vin3'>
                    </div>
                </div>

                 
                <!--<div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Date & Time*</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                        <input type='date' placeholder='city e.g. Ibadan' name='date' id='date' class='form-control col-sm-4' value=''>
                    
                        <input type='time' placeholder='area e.g. Iwo-road' name='time' id='time' class='form-control col-sm-4' value='' style='margin-left:2px;'/>
                        
                    </div>
                </div>

                <div class='form-group'>
                    <div class='col-sm-12' style='margin-top:25px;'>
                        <label></label>
                        <input type='file' multiple name='file' class='fileinput' />
                    </div>
                </div>-->
                <div class='form-group img' style='display:none; margin-bottom:25px;'>
                    <div style='display:flex; margin-top:20px;'>
                        
                        <div class='col-sm-6'>
                           
                            <div onClick='' class='hover' style='margin-top:10px;'><span style='padding:15px; border:1px solid #fff; border-radius:10px; filter:drop-shadow(1px 2px 1px #aaa); background:#fff;'>Upload pictures</span>
                            </div>
                        </div>
                        <div class='col-sm-6'><div style='border-radius:10px; padding:10px 10px 10px 20px; font-size:12px; background:#eee; text-align:left;'><i class='fa fa-info' style='margin-right:5px;'></i> Upload front, rear & sides pictures of the property.<span style='color:#2196f3;'> (optional)</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='form-group desc'>
                    <div style='display:flex; margin-top:10px;'>
                        
                        <div class='col-sm-6'>
                            <label style='font-weight:bold; margin-bottom:20px;'>Describe item*</label>
                            <div style='display:flex; align-items:flex-end;'>
                                <button onClick='startRec(20, 1);' class='hover' id='startRecBtn' style='background:transparent; border:0px;'><div style='padding:15px; border:1px solid #fff; border-radius:10px; filter:drop-shadow(1px 2px 1px #aaa); background:#fff; margin-right:10px; padding-left:15px;'><i class='fa fa-microphone'></i></div>
                                </button>
                                <div class='countDowntime' style='color:red; margin-left:10px;'></div>
                            </div>
                        </div>
                        <div class='col-sm-6'><div style='border-radius:10px; padding:10px 10px 10px 20px; font-size:12px; background:#eee; text-align:left; margin-top:20px;'><i class='fa fa-info' style='margin-right:5px;'></i> Describe the unique features of the item/property succintly in 20s voice recording.<span style='color:red;'> (Required)</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='col-sm-12'>
                        <button type='submit' name='proceed' class='btn btn-default em hover theme' id='reportBtn' style='padding:10px 15px 10px 15px; font-size:16px;'>Report</button>
                         <input type='hidden' value='' name='myaudio' id='myaudio'>
              
                </div><br><br><br>
            </form>
        </div></div>";
/* if($regCompleted=='0'){$rForm.=$usersView->showModal('includes/completeReg.inc.php', 'completeReg', 'file');
}
*/       
return $rForm;