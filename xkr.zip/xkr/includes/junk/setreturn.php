<?php
	include('../includes/autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();

	$rptType=$usersView->sanitise($_POST['rptType']);
	$uid = $_SESSION['user_id'];
		if($rptType==1 || $rptType==2){
			$ppt=$usersView->sanitise($_POST['item']);
		$rptType == 1 ? $city = '' : $city=$usersView->sanitise($_POST['city']); 

		$rptType == 1 ? $tableName ='lst_item' : $tableName ='found_asset';
		
		$rptType == 1 ? $updVal="rpt" : $updVal = "rtn";

		$user = $usersView->fetchUser($uid);
		$user_lat = $user[0]['lat'];
		$user_lng = $user[0]['lng'];
		$description = $user[0]['tmp_aud'];

		$rptType==1 ? $column="description" : $column="city";
		$rptType==1 ? $columnVal=$description : $columnVal=$city;
		
		$data = array("ppt"=>$ppt, $column=>$columnVal);
	    $usersContr->updUserActivity($uid, $updVal);
    
	    if($usersContr->setReport($tableName, $data, $rptType)){
	    	$reply = $usersContr->reply;
		}
		else{
			$reply = "Failed, try again";
		}
	
	}elseif($rptType==3){
		$uid = $_SESSION['user_id'];
		$user = $usersView->fetchUser($uid);
		$user_lat = $user[0]['lat'];
		$user_lng = $user[0]['lng'];
		$description = $user[0]['tmp_aud'];

		$ppt = $usersView->sanitise($_POST['ppt']);
		if($ppt == 'Others'){ 
			$ppt = $usersView->sanitise($_POST['item']);
			$data = array("ppt"=>$ppt, "description"=>$description, "lat"=>"", "lng"=>"");
		}else{
			$ppt = $usersView->sanitise($_POST['ppt']);

			$ppt_img = $usersView->sanitise($_POST['img']);
	 		$desc = $usersView->sanitise($_POST['desc']);
	 		
	 		$make = $usersView->sanitise($_POST['make']);
			$model = $usersView->sanitise($_POST['model']);
			$color = $usersView->sanitise($_POST['color']);
			$engnum = $usersView->sanitise($_POST['vin1']);
			$chasisnum = $usersView->sanitise($_POST['vin2']);
			$numplate = $usersView->sanitise($_POST['vin3']);

			$data = array("ppt"=>$ppt, "make"=>$make, "model"=>$model, "color"=>$color, "engnum"=>$engnum, "chasisnum"=>$chasisnum, "numplate"=>$numplate, "pictures"=>$ppt_img, "lat"=>"", "lng"=>"");
		}
	
		$updVal="theft";	

			$data['lat'] = $user_lat;
			$data['lng'] = $user_lng;

	 		$usersContr->updUserActivity($uid, $updVal);
	    
	 		$tableName ='stolen_asset';
	 		
			$usersContr->setReport2($tableName, $data, $ppt);
			$reply = $usersContr->reply;
	}
	echo json_encode(array("ajaxReply"=> $reply));