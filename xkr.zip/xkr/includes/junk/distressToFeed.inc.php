<?php
include('autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();

$userData = $usersView->fetchUser();
$lat2 = $userData[0]['lat'] - 0.05;
$lng2 = $userData[0]['lng'] - 0.05;
$lat1 = $userData[0]['lat'] + 0.05;
$lng1 = $userData[0]['lng'] + 0.05;

$now = time();
$prev = $now - 3600;
$nowDate = date('Y-m-d H:i:s', $now);
$prevDate = date('Y-m-d H:i:s', $prev); 	
//select distress call located around this user
$vals = $lat2.', '.$lat1.', '.$lng2.', '.$lng1.', '.$prevDate.', '.$nowDate;
//	if(isset($_GET['getVid'])){
/*$geo = $lat2.', '.$lat1.', '.$lng2.', '.$lng1;
$date =$nowDate.', '.$prevDate;
$date2 =$prevDate.', '.$nowDate;
*/
//var_dump($vals);
$dist_data = $usersView->select('distress', ' WHERE lat BETWEEN ? AND ? AND lng BETWEEN ? AND ? AND distress_date BETWEEN ? AND ?', $vals);


//$dist_data = $usersView->select('distress', ' WHERE lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?', $geo);
//$dist_data = $usersView->select('distress', ' WHERE distress_date BETWEEN ? AND ?', $date2);

//	$newsFeed = array();
if(count($dist_data) > 0){
	$newVid = $dist_data[0]['d_video'];

	echo json_encode(array("dvUrl" => $newVid));
}	
	/*if(count($dist_data)>0){
		foreach($dist_data as $feed){
     		array_push($newsFeed, array('vd' => $feed[0]['video']));
		}
		echo json_encode(array("dvUrl" => $newsFeed));
	}*/

//}