<?php
$now = time();
$global = "<div class='collapse unselected2 coverage' id='globalCoverage' style='text-align:center;'><span id='rangeValue' style='font-weight:bold; padding:2px;color:#ccc;'></span></div>";

$rangeMeter = "<div class='input-group input-group-sm hidden-sm-down unselected2 radiusCoverage' id='radiusCoverage' style='display:none; margin-top:20px; width:100%; border-radius:50px;'>
                      <div style='display:flex; border:1px solid #ccc; width:100%; border-radius:50px;'>
                      <input type='range' name='callRange' min='0' max='5000' value='' id='callRange' class='myRange form-control slider' style='color:#f01e6b; margin: auto 25px auto 25px;'>
                      <button type='submit' name='submit' tabindex=3 class='input-shadow' id='radiusCoverageCloser'  style='border:0; border-top-right-radius:50px; border-bottom-right-radius:50px; background:#fff;'><i class='fa fa-times fa-fw'></i></button>
                      </div>

                    </div><br>";

$fdi="<div id='addFDIspec' class='addFDIspec'></div>";
$text = "<div class='input-group input-group-sm hidden-sm-down unselected input' id='textProof' style='display:none; margin-bottom:20px; width:100%; border-radius:50px;'>
                      <textarea tabindex=1 class='form-control' name='proof' id='proof' maxlength='200' rows='2' pattern='^(?=.{4,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$' title='Needys convincing story' placeholder='Describe the purpose...' style='color:blue; border:1px solid #ccc; font-size:16px; color:#f01e6b; height:40px; border-top-left-radius:50px; border-bottom-left-radius:50px;'></textarea>
                      <button type='button' name='submit' tabindex=3 id='textProofCloser' style='border:0; border-top-right-radius:50px; border-bottom-right-radius:50px; background:#fff;'><i class='fa fa-times fa-fw'></i></button>
                    </div>";
$audio =   "";/*<div class='unselected' style='display:none; margin-bottom:20px; width:100%;'>
              <div>
                <div class='countDown' style='text-align:center;'>
                  <div style='border-radius:50%; border:5px solid #4196f3; width:120px; height:120px; display:flex; justify-content:center; align-items:center;'>
                    <div style='display:flex column;'>
                      <div style='font-size:35px; color:red; margin-bottom:-10px;'>
                        <span id='timer'>15</span>
                      </div>
                      <div style='font-size:12px; color:brown;'>Speaki now..</div>
                    </div>
                  </div>
                </div>

                <div id='audioMeter'></div>
                <input type='hidden' value='' name='myaudio' id='myaudio'>
              </div>
            </div>";
*/
/*$useDefRange==2 ? $def_range=$def_range*1000 : $def_range=5000;
$useAudioReq==1 ? $communiType = $audio : $communiType = $text;
*/
return"     <form id='request_data' method='post' enctype='multipart/form-data' class='form-horizontal' role='form'>
            <input type='hidden' id='now' value='".$now."' name='now'>
            <input type='hidden' id='global' name='global'>
            <h5 class='text-center' style='color:#444; font-weight:bold;'>Xkroll call</h5><br>
                  <!-- <div class='form-group'>
                    <div>
                      <select onchange='FDIorNot($(this).val())' class='form-control input' title='Xkroll call type' id='xkroll_callType' name='xkroll_callType' style='background:#eff; color:#f01e6b;' >
                          <option value='' disabled>Select Call purpose:</option>
                          <option value=2>Request Help</option>
                          <option value=4>Inspect vehicles/motorcycles</option>

                          <option value=1 disabled>Alert Neighborhood</option>
                          <option value=3 disabled>FDI Giveaway</option>
                         
                      </select>
                  </div>
               </div>-->
              <div>
                    <div>
                      <div class='opt-list' style='margin-top:-10px;'>
                     <input type='text' list='items' name='heading' id='heading' maxlength='40' style='font-size:16px; color:#f01e6b;' class='form-control input' required value='' placeholder='Nature of help...'/>
                     <datalist id='items' class='datalist'>
                     </datalist>
                     </div>
                     $fdi
                     <div style='display:flex; flex-wrap:nowrap; margin:5px auto auto auto; color:#777; font-size:12px; display:flex; justify-content:flex-end;'>
                      

                     <div style='margin-right:auto;'>$global</div>
                     <div style='margin-right:20px;'><span style='font-size:18px; color:#fff; filter:drop-shadow(2px 2px 1px #ccc);' class='material-icons unselectedCaller' id='audioProofCaller'>&#xe7f4</span>&nbsp;&nbsp;&nbsp;<span style='font-size:16px;' class='material-icons unselectedCaller small_Icons' id='audioProofCaller'>&#xe029</span>&nbsp;&nbsp;&nbsp;<span class='material-icons unselectedCaller small_Icons' id='textProofCaller' style='font-size:16px;'>&#xe873</span></div>
                     <div style='font-weight:bold; color:#ccc; font-size:16px;'>|</div>
                     <div style='margin-left:20px;'><span class='material-icons unselectedCaller2 small_Icons' id='radiusCoverageCaller' style='font-size:16px;'>&#xe569</span>&nbsp;&nbsp;&nbsp;<span class='material-icons unselectedCaller2 small_Icons' style='font-size:16px;' id='globalCoverageCaller'>&#xe80b</span></div>
                   </div>
                   </div>".
                   //$rangeMeter.$text.$audio.
                   "
                   <div>
                        <div style='text-align:right;'>
                           <button type='submit' name='submit' id='post' class='btn btn-default sm theme' style='border-radius:20px; padding:10px 25px;'>
                            Submit
                           </button>
                        </div>
                    </div>
            </form>";