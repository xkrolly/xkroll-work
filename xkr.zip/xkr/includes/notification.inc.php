<?php
$usersContr =  new usersContr();

      $msg_id= $allNotes[$ln]["msg_id"]; 
      $found_id= $allNotes[$ln]["found_id"]; 
      $donation_id= $allNotes[$ln]["donation_id"]; 
      $item_requested = $allNotes[$ln]["item"];
      $ppt= $allNotes[$ln]["ppt"];
      $city= $allNotes[$ln]["city"];
      $owner_id= $allNotes[$ln]["owner_id"];
        $finder_id= $allNotes[$ln]["user_id"];
      $rep_date= $this->time($allNotes[$ln]["reporting_date"]);
      $claim_time=$this->time($allNotes[$ln]["claimed_date"]);
      $donor= $allNotes[$ln]["donor"];
      $d_date= $allNotes[$ln]["d_date"];
      $remove= $allNotes[$ln]["remove"]; 
      $supplied= $allNotes[$ln]["supplied"];
      $donor_contact = $allNotes[$ln]["don_contact"]; 
      $req_time =$this->time( $allNotes[$ln]["d_date"]);      
      $callType = $allNotes[$ln]["callType"];
      $needy = $allNotes[$ln]["tuser_id"];
      $claimer = $allNotes[$ln]["claimer"];
      $claimer_contact = $allNotes[$ln]["claimer_contact"];
      $finder_contact = $allNotes[$ln]["contact"];
      $viewed = $allNotes[$ln]["iview"];
      $distress_sender = $allNotes[$ln]["distress_sender"];
      $distress_video_url = $allNotes[$ln]["distress_video_url"];
      $notifi_time = $this->time($allNotes[$ln]["idate"]);      

      $hAcesd = $allNotes[$ln]["hAcesd"];
      $img = $allNotes[$ln]["img"];
    
      $userData = $this->fetchUser();
      $user_id = $userData[0]['profile_id'];
  
$inbox="<section class='each-section' style='padding:5px; color:#555; background:#fff; margin-left:10px; margin-right:10px; margin-bottom:-2px; font-family:serif;'>";
$inbox.="<div id='hvResp".$donation_id."' style='z-index:1; display:none;' class='md' onclick=$('#hvResp').hide('slow')></div>";
$heading='';
$msg='';
if($msg_id==1){
             $heading.="<div class='msg_heading'><h6>Welcome</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>Welcome to Xkroll community. A ton of useful features await you as you join Xkroll. Follow us on @_xkroll to contribute in making Xkroll better. Thanks!
             </div>";
    }
elseif($msg_id==2){
  $tellFriend="Hello. I am going to meet someone right now. The person's contact is *".$donor_contact."*, just for security reason.\n\nJoin Xkroll today on https://xkroll.com to benefit and contribute your quota in making the world a better place.";

             $heading.="<div class='msg_heading'><h6 style=''>".$item_requested."</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>Congrats! A kind fellow is ready to grant your request of ".$item_requested.". Reach out on <a href='tel:".$donor_contact."'>".$donor_contact."</a> to receive it. As safety measure, you may <a href='whatsapp://send?text=".rawurlencode($tellFriend)."' data-action='share/whatsapp/share' class='optwem hover' style='text-decoration:underline; color:black'>
              Tell a friend</a> about your meeting.";

              if($hAcesd==0){
                $msg.="<div id='helperGrader".$donation_id."' style='padding:2px; border:2px solid #fff; border-radius:10px; margin-left:25px;'><h6 style='margin-left:25px; margin-top:10px;'>After you meet up with the potential helper, kindly answer the following...</h6>

                <form method='post' id='confirmHelp_data".$donation_id."' style='display:flex column; margin-left:35px;'>
                  <p style='margin-bottom:0px;'><label style='margin-left:10px;' onclick='assessHelper(2, $donation_id)'><input type='radio' name='confirmHelp' value='1'>&nbsp;&nbsp;&nbsp;You were kindly helped.</label></p>
                  <p style='margin-bottom:0px;'><label style='margin-left:10px;' onclick='assessHelper(0, $donation_id)'><input type='radio' name='confirmHelp' value='2'>&nbsp;&nbsp;&nbsp;You could not locate the helper.</label></p>
                  <p style='margin-bottom:0px;'><label style='margin-left:10px;' onclick='assessHelper(-6, $donation_id)'><input type='radio' name='confirmHelp' value='3'>&nbsp;&nbsp;&nbsp;It was all a lie and deception.</label></p>
                </form></div>";
              }
          $msg.="    </div>";
    }
elseif($msg_id==3){
             $heading.="<div class='msg_heading'><h6>Help confirmed</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>The help you provided was acknowledged to be true. What a commendable act! You are a star Xkrollite. You have won more impact.</div>";
    }
elseif($msg_id==4){
             $heading.="<div class='msg_heading'><h6>Unrealistic request</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>Your request was voted unrealistic by the public. Try to make a new and realistic one.</div>";
    }
elseif($msg_id==5){
                 $heading.="<div class='msg_heading'><h6>Alert Successful</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>You have successfully alerted the community. A community response awaits you.</div>";
    }
elseif($msg_id==6){
               $heading.="<div class='msg_heading'><h6>FDI claimed</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>You have grabbed an FDI successfully, meet up the owner on <a href='tel:".$FDIcontact."'>".$FDIcontact."</a> to receive it.</div>";
    }
elseif($msg_id==7){
             $heading.="<div class='msg_heading'><h6>".$ppt."</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>Your lost ".$ppt." was found at ".$city.". Call the finder on <a href='tel:".$finder_contact."'>".$finder_contact."</a> to retrieve it.";
             if(!empty($img)){$msg.=" The image of the ".$ppt." is as shown. Check thoroughly to confirm if it is truly yours.<br><p> 
              <picture class='lazy'>
                <source srcset='img/retrieved/".$img.".webp' media='(min-width:1200px)'>
                <source srcset='img/retrieved/".$img.".webp' media='(min-width:700px)'>
                <source srcset='img/retrieved/".$img.".webp' media='(min-width:300px)'>
                <img src='img/retrieved/".$img.".webp' loading='lazy' style='height:250px; width:100%;'>
                </picture>
                </p>";}
             $msg.="</div>";
    }
elseif($msg_id==8){
             $heading.="<div class='msg_heading'><h6>Claimed item</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>The item you searched was already claimed by <a href='tel:".$claimer_contact."'>".$claimer_contact."</a>, call the finder on <a href='tel:".$finder_contact."'>".$finder_contact."</a> to look for it.</div>";
    }
elseif($msg_id==9){
             $heading.="<div class='msg_heading'><h6>Warning</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>Assist prank is strictly prohibited. Kindly stay away from it.</div>";
    }
elseif($msg_id==10){
             $heading.="<div class='msg_heading'><h6>Warning</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>You are banned from using Xkroll due to your involvement in assist prank.</div>";
    }
elseif($msg_id==11){
             $heading.="<div class='msg_heading' style='color:red;'><h6>Distress signal</h6><div class='far-right'>".$notifi_time."</div></div>"; 
             $msg.="<div class='msg_body'>
                     <div>".$distress_sender." is requesting a swift response from you. Kindly gravitate to help out in due course. A delay might be disastrous. Watch the video below.
                     </div>
               <div style='margin-top:10px;'><video controls style='width:106%; height:auto; margin:10px -20px -16px -10px; border-bottom-right-radius:10px; border-bottom-left-radius:10px; aspect-ratio:4/3;' frameborder='0' allowfullscreen>
                  <source src='videos/distress/".$distress_video_url.".webm' />
               </video>
               </div>
             </div>";
    }

if(!empty($msg)){
  $inbox.="<div style='padding:10px; background:#eee; border-radius:10px;'>".$heading.$msg;
$inbox.="</div>";}
$inbox.="</section>";
$vals = '1, '.$user_id;
  //update db on msg viewed status
$usersContr->update('xnote', 'iview = ? WHERE user_id = ?', $vals);

return $inbox;