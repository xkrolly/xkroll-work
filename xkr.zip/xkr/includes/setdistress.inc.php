<?php
	include('../includes/autoloader.inc.php');
	$usersContr = new usersContr();
	$usersView = new usersView();

	$fam1=$usersView->sanitise(substr($_POST['contactF1'], -10));
	$fam2=$usersView->sanitise(substr($_POST['contactF2'], -10));
	$friend1=$usersView->sanitise(substr($_POST['contactFr1'], -10));
	$friend2=$usersView->sanitise(substr($_POST['contactFr2'], -10));
	$sec1=$usersView->sanitise(substr($_POST['contactS1'], -10));
	$sec2=$usersView->sanitise(substr($_POST['contactS2'], -10));
	$neigh1=$usersView->sanitise(substr($_POST['contactN1'], -10));
	$neigh2=$usersView->sanitise(substr($_POST['contactN2'], -10));
	isset($_FILES['image-clue
']['name']) ? $image_clue=$usersView->sanitise($_FILES['image-clue
']['name']) : $image_clue='';
	
	$all = array($fam1, $fam2, $friend1, $friend2, $sec1, $sec2, $neigh1, $neigh2);
//	var_dump($all);
 	if(count(array_filter($all))==8){
 	$output = array_unique($all);
	 	if(count($output)==count($all)){

			$allRecipients = $fam1.'..'.$fam2.'..'.$friend1.'..'.$friend2.'..'.$sec1.'..'.$sec2.'..'.$neigh1.'..'.$neigh2;
		
			$userData = $usersView->fetchUser();
			$user = $userData[0]['profile_id'];
			$vals = $allRecipients.', '.$user;
					

			$usersContr->update('profile', 'dSignal_recipients = ? WHERE profile_id = ?', $vals);
			$reply="All recipients saved!";
		

	 	}else{ $reply = 'contact number repetition exist, check and correct.';}
	}else{$reply = 'All contact fields are required.';}
	echo json_encode(array("ajaxReply"=> $reply));

