<?php
  include('autoloader.inc.php');
$usersContr = new usersContr();
$usersView = new usersView();

$found_id = $usersView->sanitise($_POST['fid']);
$city = $usersView->sanitise($_POST['city']);
$foundData = $usersView->select('found_asset', ' WHERE found_id = ?', $found_id);
$finder_contact = $foundData[0]['contact'];
$_city = $foundData[0]['city'];
$claim_status = $foundData[0]['claimed'];

//msg the owner
$userData = $usersView->fetchUser();
$recipient_id = $userData[0]['profile_id'];
$msg_id = 7;
$donation_id = 1;
$distress_id = 1;

$usersContr->msger($recipient_id, $msg_id, $found_id, $donation_id, $distress_id);
if($city == $_city && $claim_status==0){
        //update found_asset that it is claimed
        $vals = '1, '.$recipient_id.', '.$found_id;
        $usersContr->update('found_asset', 'claimed = ?, owner_id = ? WHERE found_id = ?', $vals);
        $Resp = 'Your information matches, kindly reach the finder on '.$finder_contact.' for retrieval.';
}
elseif($city == $_city && $claim_status==1){
    $owner = $foundData[0]['owner_id'];
    $profileData = $usersView->fetchProfile($owner);
    $claimerContact = $profileData[0]['contact'];
    $claimerName = $profileData[0]['lastname'].' '.$profileData[0]['firstname'];
    $Resp = 'This property was already claimed by '.$claimerName.'. Call this person on '.$claimerContact.' Or the original finder on '.$finder_contact;
    //msg the inbox about the claimed ppt?
}
elseif($city != $_city){ $Resp = 'Sorry, this is not your property';}
else{$Resp='Error occured, please try again.';}
echo json_encode(array("ajaxReply" => $Resp));