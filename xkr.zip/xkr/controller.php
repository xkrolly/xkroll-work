<?php
session_start();
error_reporting(E_ALL & ~ E_NOTICE);
require ('textlocal.class.php');

class Controller
{
    function __construct() {
        $this->processMobileVerification();
    }
    function processMobileVerification()
    {
        switch ($_POST["action"]) {
            case "send_otp":
                
                $mobile_number = $_POST['mobile_number'];
                
                $apiKey = urlencode('YOUR_API_KEY');
                $Textlocal = new Textlocal(false, false, $apiKey);
                
                $numbers = array(
                    $mobile_number
                );
                $sender = 'PHPPOT';
                $otp = rand(100000, 999999);
                $_SESSION['session_otp'] = $otp;
                $message = "Your One Time Password is " . $otp;
                
                try{
                    $response = $Textlocal->sendSms($numbers, $message, $sender);
                    require_once ("verification-form.php");
                    exit();
                }catch(Exception $e){
                    die('Error: '.$e->getMessage());
                }
                break;
                
            case "verify_otp":
                $otp = $_POST['otp'];
                
                if ($otp == $_SESSION['session_otp']) {
                    unset($_SESSION['session_otp']);
                    echo json_encode(array("type"=>"success", "message"=>"Your mobile number is verified!"));
                } else {
                    echo json_encode(array("type"=>"error", "message"=>"Mobile number verification failed"));
                }
                break;
        }
    }
}
$controller = new Controller();

/*html for getting phonr number

!DOCTYPE html>
<html>
<head>
<title>How to Implement OTP SMS Mobile Verification in PHP with TextLocal</title>
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<body>

    <div class="container">
        <div class="error"></div>
        <form id="frm-mobile-verification">
            <div class="form-heading">Mobile Number Verification</div>

            <div class="form-row">
                <input type="number" id="mobile" class="form-input"
                    placeholder="Enter the 10 digit mobile">
            </div>

            <input type="button" class="btnSubmit" value="Send OTP"
                onClick="sendOTP();">
        </form>
    </div>

    <script src="jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="verification.js"></script>
</body>
</html>
*/



/*the html part for submitting the code

<div class="error"></div>
<div class="success"></div>
<form id="frm-mobile-verification">
    <div class="form-row">
        <label>OTP is sent to Your Mobile Number</label>        
    </div>

    <div class="form-row">
        <input type="number"  id="mobileOtp" class="form-input" placeholder="Enter the OTP">        
    </div>

    <div class="row">
        <input id="verify" type="button" class="btnVerify" value="Verify" onClick="verifyOTP();">       
    </div>
</form>
*/