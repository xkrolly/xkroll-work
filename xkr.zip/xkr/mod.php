<?php phpinfo(); ?>
/////
Options +FollowSymLinks
RewriteEngine On
RewriteRule ^(\w*)/?$ index.php?page=$1 [N]
RewriteRule ^(\w*)/?$ $1 [QSA,L]
