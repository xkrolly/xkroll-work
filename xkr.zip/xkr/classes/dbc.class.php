<?php

class Dbc {
	private $host = "localhost:3308";//"35.241.229.251";
	private $user = "root";
	private $pwd = "";//"C__tprT><?-s";
	private $dbName = "xkroll_db";
	private $charset = "utf8mb4";
	protected $con;

	public function __construct() {
		$this->con = mysqli_connect($this->host, $this->user, $this->pwd, $this->dbName);
	}

	protected function connect() {
		$dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbName;// . ';charset=';// . $this->charset;
		$pdo = new PDO($dsn, $this->user, $this->pwd);
		$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		return $pdo;
	}
}