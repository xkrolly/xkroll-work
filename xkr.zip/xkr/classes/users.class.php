<?php
class Users extends Dbc {
	public $excluded;
	public $order;
	public $lat;
	public $lng;
	public $did;
	public $media_setins;
	public $dm;
	public $count; 
	public $regCompleted;
	protected $lastId;

	protected function harvesine($lat1, $lng1, $lat2, $lng2) {
		$dLat = ($lat2 - $lat1) * M_PI/180.0;
		$dLng = ($lng2 - $lng1) * M_PI/180.0;
		
		$lat1 = $lat1 * M_PI / 180;
		$lat2 = $lat2 * M_PI / 180;
		
		$a = pow( sin($dLat / 2), 2) + pow( sin( $dLng / 2), 2) * cos($lat1) * cos($lat2);

		$rad = 6371;
		$c = 2 * asin(sqrt($a));
		return $rad * $c;
	}

	protected function matchStrStmt($input) {
	    $firstLetter = substr($input, 0, 1); 
	    $lastLetter = substr($input, -1, 1); 
		$len=strlen($input);
		$length=$len-2;

	    $par= substr($input, 1, $length);
		$para9=str_ireplace(['a','e','i','o','u','_', '.', ',', ' ', '-'], "", $par);

		$para10 = str_split($para9);
		$paraArray=array_unique($para10);
	    $paraStr=implode('', $paraArray);
		$output=str_ireplace("sh", "s", $paraStr);
	    $finalWord=strtolower($firstLetter.$output.$lastLetter);
    return $finalWord;
	}

	protected function selectStmt($tableName, $whereOpr, $whereVal) {
		$whereVal = explode(', ', $whereVal);

		$sql="SELECT * FROM ".$tableName.$whereOpr;
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute($whereVal);
		$this->count = $stmt->rowCount();
		$results = $stmt->fetchAll();
		return $results;
	}
	protected function deleteStmt($tableName, $whereOpr, $whereVal) {
		$whereVal = explode(', ', $whereVal);

		$sql="DELETE FROM ".$tableName.$whereOpr;
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute($whereVal);
	}

	protected function userProfile($where) {
		return $this->selectStmt('profile', ' WHERE profile_id = ?', $where);
	}
	protected function userId() {
		
		if(isset($_SESSION['user_id'])){
		 $session = $_SESSION['user_id'];

  		$row = $this->selectStmt('skyman_user', ' WHERE session = ?', $session);
		  	if(count($row) > 0){
		  		$profile_id = $row[0]['profile_id'];
				return $this->selectStmt('profile', ' WHERE profile_id = ?', $profile_id);
			}else{
				session_destroy();
			header('Location: index');
			}
		}
	}
	
	protected function fetchFeed() {
		$user = $this->userId();
		$user_id = $user[0]['profile_id'];
		$blocked=$user[0]['blocked'];
		$benefIds=$user[0]['helped'];
		$this->excluded=$blocked.','.$benefIds;
		$_order=$user[0]['o_rder'];
		$_order==1? $this->order='ASC' : $this->order='DESC';
		$this->lat=$user[0]['lat'];
		$this->lng=$user[0]['lng'];
		$this->dm=$user[0]['dm'];
		$picture=$user[0]['picture'];
		$regCompleted = $user[0]['regCompleted'];
		$this->media_setins=$user[0]['media_setin'];

	 	$sql="SELECT * FROM donation WHERE supplied=0";// 
	 	//WHERE tuser_id='".$_SESSION['user_id']."' AND supplied=0 AND deleted='0' OR ".$this->lat." BETWEEN lat-rnge AND lat+rnge AND $this->lng BETWEEN lng-rnge AND lng+rnge AND $this->lat NOT BETWEEN lat-dz AND lat+dz AND $this->lng NOT BETWEEN lng-dz AND lng+dz OR global='1' AND supplied=0 AND deleted='0' AND nonreal<5 AND tuser_id NOT IN (".$this->excluded.") OR supplied=0 AND deleted='0' AND nonreal<5 AND $this->lat BETWEEN lat-rnge AND lat+rnge AND $this->lng BETWEEN lng-rnge AND lng+rnge AND tuser_id NOT IN (".$this->excluded.") ORDER BY empathy ".$this->order;
  			
	 	$stmt = $this->connect()->query($sql);
		$homeFeedArray=array();
	
	while($row = $stmt->fetch()){
			$did=$row['donation_id'];
	        $callType=$row['callType'];

//			$vals = $user_id.' '.$did;
            $sql1="SELECT vote FROM voter WHERE user_id='".$user_id."' AND donation_id='$did'";
            $data=mysqli_query($this->con, $sql1);
            $rows=mysqli_fetch_array($data);
                  $vote =$rows['vote'];
      
          	 $eachFeed = array('donation_id'=>$did, 'tuser_id'=>$row['tuser_id'], 'donor'=>$row['donor'], 'item'=>$row['item'], 'proof'=>$row['proof'], 'empathy'=>$row['empathy'], 'nonreal'=>$row['nonreal'], 'img_proof'=>$row['img_proof'], 'useMedia'=>$row['useMedia'], 'media_setins'=>$this->media_setins, 'played'=>$row['played'], 'global'=>$row['global'], 'lat'=>$row['lat'], 'lng'=>$row['lng'], 'userLat'=>$this->lat, 'userLng'=>$this->lng, 'vote'=>$vote, 'picture'=>$picture, 'regCompleted'=>$regCompleted);
			$homeFeedArray[] = $eachFeed;
		}
		return $homeFeedArray;
	}

	protected function fetchNotes() {// INNER JOIN distress USING (distress_id)   found_asset USING (found_id) INNER JOIN
		$userData = $this->fetchUser();
		$user_id = $userData[0]['profile_id'];
		$sql="(SELECT * FROM xnote INNER JOIN donation USING (donation_id) INNER JOIN found_asset USING (found_id) INNER JOIN distress USING (distress_id) WHERE xnote.user_id='".$user_id."' ORDER BY idate DESC LIMIT 25) ORDER BY idate ASC";
		$stmt = $this->connect()->query($sql);
		$notesArray=array();

		while($row1 = $stmt->fetch()){
			$claimer_id = $row1['owner_id'];
			$distress_sender_id = $row1['sender_id'];
			//$row=$this->userProfile($claimer_id);
			$sql2 = "SELECT firstname, lastname, contact FROM profile WHERE profile_id='$claimer_id'";
    		$data=mysqli_query($this->con, $sql2);
            $row2=mysqli_fetch_array($data);
           
		    $claimer_contact=$row2['contact'];
			$claimer=$row2['firstname']." ".$row2['lastname'];

	$sql3 = "SELECT firstname, lastname, contact FROM profile WHERE profile_id='$distress_sender_id'";
    		$data3=mysqli_query($this->con, $sql3);
            $row3=mysqli_fetch_array($data3);
         	$distress_sender = $row3['firstname']." ".$row3['lastname'];

			$eachNote =array("msg_id"=>$row1['msg_id'], "found_id"=>$row1['found_id'], "donation_id"=>$row1['donation_id'], "item"=>$row1['item'], "ppt"=>$row1['ppt'], "city"=>$row1['city'], "owner_id"=>$row1['owner_id'], "reporting_date"=>$row1['reporting_date'], "claimed_date"=>$row1['claimed_date'], "donor"=>$row1['donor'], "remove"=>$row1['remove'], "supplied"=>$row1['supplied'], "hAcesd"=>$row1['hAcesd'], "don_contact"=>$row1['don_contact'], "d_date"=>$row1['d_date'], "callType"=>$row1['callType'], "tuser_id"=>$row1['tuser_id'], "user_id"=>$row1['user_id'], "contact"=>$row1['contact'], "claimer"=>$claimer, "claimer_contact"=>$claimer_contact, "iview"=>$row1['iview'], "img"=>$row1['img'], "idate"=>$row1['idate'], "distress_sender"=>$distress_sender, "distress_video_url"=>$row1['d_video']);
	
			$notesArray[] = $eachNote;
		}
		return $notesArray;
	}

	protected function insert2Db($tableName, $data) {
		$num = count($data);
		$tag=array_fill(0, $num, '?');
		$all_tags=implode(", ", $tag);

	 	$sql = "INSERT INTO ".$tableName." (";
	 	$sql .= implode(", ", array_keys($data)) . ") VALUES (".$all_tags.")";
	 	$values = array_values($data);	
	 	$stmt = $this->connect()->prepare($sql);
		$stmt->execute($values);
//	$lastID = $this->connect()->lastInsertId();
	}

	protected function updateStmt($tableName, $setOPRs, $setWhereVals) {
	    
	    $setWhereVals = explode(', ', $setWhereVals);
	 	$sql = "UPDATE ".$tableName." SET ".$setOPRs;
	 	$stmt = $this->connect()->prepare($sql);
		$stmt->execute($setWhereVals);
		$results = $stmt->fetchAll();
		return $results;
	}
}
