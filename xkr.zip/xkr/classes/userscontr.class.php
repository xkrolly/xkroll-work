<?php

class UsersContr extends Users {
	private $found_id;
	public $reply;
	public $reqResp;
	
	public function cr8matchStr($input) {
		return $this->matchStrStmt($input);
	}

	public function update($tableName, $valSpace, $vals){
		return $this->updateStmt($tableName, $valSpace, $vals);
	}
	public function delete($tableName, $valSpace, $vals){
		return $this->deleteStmt($tableName, $valSpace, $vals);
	}

	public function insert($tableName, $data){
		return $this->insert2Db($tableName, $data);
	}

	public function updUserActivity($userId, $btnPressed){
		$active= $this->selectStmt('userActivity', ' WHERE user_id = ?', $userId);

            if(count($active)>0){
				$newVal = $active[0][$btnPressed] + 1;
				$vals = $newVal.', '.$userId;
				$this->update('userActivity', $btnPressed.' = ? WHERE user_id = ?', $vals);
            }
            else{
        		$vals = array('user_id'=>$userId, $btnPressed=>1);
				$this->insert2Db('userActivity', $vals);
            }
	}

	public function setRequest($tableName, $data) {
       $this->insert2Db($tableName, $data);
		return $this->reqResp = "Request successful";
	}

	public function setVote($tableName, $data) {
		$this->insert2Db($tableName, $data);
	}

	public function setValue($tableName, $data) {
		$this->insert2Db($tableName, $data);
		return $data['comment'];
	}

 	public function msger($recipient_id, $msg_id, $found_id, $donation_id, $distress_id){
		$inboxData = array("user_id"=>$recipient_id, "found_id"=>$found_id, "msg_id"=>$msg_id, "donation_id"=>$donation_id, "distress_id"=>$distress_id);
$whereVal=$donation_id.', '.$found_id.', '.$distress_id.', '.$recipient_id;
		$sameNote=$this->selectStmt('xnote', ' WHERE donation_id=? AND found_id = ? AND distress_id = ? AND user_id = ?', $whereVal);
		
		if(count($sameNote)==0){
			$this->insert2Db('xnote', $inboxData);
		}
	}
/*
	public function setReport($tableName, $data, $rptType) {

		$ppt = $data['ppt'];
		$city = $data['city'];
		$area = $data['area'];
		
		$iarea = $this->cr8matchStr($area);
		$icity = $this->cr8matchStr($city);
		
		$rptType == 1 ? $tableName ='lst_item' : ($rptType==2 ? $tableName ='found_asset' : $tableName ='stolen_asset');
		//fetch user info
		$user_id = $_SESSION['user_id'];
		$userData = $this->userProfile($user_id);
	    $lat = $userData[0]['lat'];
	    $lng = $userData[0]['lng'];
		
		//inbox params
        $msg_id=7;
        $donation_id='1';
        $owner_id = $user_id;

        //data to insert
        $userDataArray = array("user_id"=>$_SESSION['user_id']);
	    $userGeo = array("lat"=>$lat, "lng"=>$lng); 
		$rptType == 2 ? $userDataArray=array_merge($userDataArray, $userGeo) : $userDataArray;
	    
	    $rtnData = array_merge($data, $userDataArray);

	   //check if the rpt is already in DB
		$whereOpr = ' WHERE ppt = ? AND city = ? AND area = ?';

		$rptVals = $ppt.' '.$icity.' '.$iarea;
		$rtnVals = $ppt.' '.$city.' '.$area;

		$check = $this->selectStmt('lst_item', $whereOpr, $rptVals);
		$check2 = $this->selectStmt('found_asset', $whereOpr, $rtnVals);
		//catch the error below in case no past lst rpt
		$found_id = '';
			//var_dump($check2);
		if(count($check2)>0){
		   $found_id .= $check2[0]['found_id'];
		}
		
		$owner_id = '';
		if($rptType == 2){
			if(count($check) > 0){
				$owner_id .=  $check[0]['user_id'];
			}
			else{
				$owner_id .= "";
			}
		}

		$reply='';
		empty($found_id) ? $found_id=1 : $found_id;
        $inboxData = array("user_id"=>$owner_id, "found_id"=>$found_id, "msg_id"=>$msg_id, "donation_id"=>$donation_id);
    	if($rptType == 1){
			if(count($check2) > 0){
				$loser_id =$_SESSION['user_id'];
				$rtnDataStr = $loser_id.', '.$ppt.', '.$city;

				$inboxData['user_id'] = $loser_id;
				//msg owner(user)
				$this->insert2Db('xnote', $inboxData);
			  	$this->updateStmt('found_asset', 'owner_id = ? WHERE ppt = ? AND city = ?', $rtnDataStr);
				$reply .= "Congrats, your lost item was found.";
			}
			else{
				if(count($check) > 0){
				 $reply .= 'You have reported this loss already';
				}
				else{
					$rptDataArray = array("user_id"=>$_SESSION['user_id'], "ppt"=>$ppt, "description"=>$description, "city"=>$icity, "contact"=>$contact);
					$this->insert2Db('lst_item', $rptDataArray);
					$reply .= "Your report was successful";
				}
			}
		}
		else{
			if(count($check) > 0){
				$inboxData['user_id'] = $owner_id;
			//	var_dump($inboxData);
		
				//msg owner(anotherUser)
				$this->insert2Db('xnote', $inboxData);
				$this->insert2Db('found_asset', $rtnData);
		    	$reply .= "Successful and quite timely. Good job.";
			}
			else{
				if(count($check2) > 0){
				  	$reply .= 'You have already filed a return report on this.';
				}
				else{
					$this->insert2Db('found_asset', $rtnData);
				   	$reply .= "The found item report was successful.";
				}
			}
		}
		return $this->reply = $reply;
	}
*/

	public function setReport($tableName, $data, $rptType){
		//add official hyphen to prevent miscleaving
		$_ppt = $data['ppt'];
		($rptType != 2) ? $_desc_r_city = $data['description'] : $_desc_r_city = $data['city']; 

		$ppt=str_replace(' ', '-', $_ppt);
		$rptType == 2 ? $desc_r_city = str_replace(' ', '-', $_desc_r_city) : $desc_r_city = $_desc_r_city;

/*		$area=str_replace(' ', '-', $_area);

		$iarea = $this->cr8matchStr($area);
		$icity = $this->cr8matchStr($city);
*/		
		//fetch user info
		$userData = $this->userId();
		$user_id = $userData[0]['profile_id'];
	    $lat = $userData[0]['lat'];
	    $lng = $userData[0]['lng'];
	    $contact = $userData[0]['contact'];
		
		//inbox params
        $msg_id=7;
        $donation_id='1';
        $distress_id='1';
        $owner_id = $user_id;

//add finders contact only
        //data to insert
        $userDataArray = array("user_id"=>$user_id, "lat"=>$lat, "lng"=>$lng);
	    $userContact = array("contact"=>$contact); 
$rptType == 2 ? $userDataArray=array_merge($userDataArray, $userContact) : $userDataArray;


	    $rtnData = array_merge($data, $userDataArray);
		$concludingQuery=' AND user_id = ?';
		$concludingVal= ', '.$user_id;
	   //check if the rpt is already in DB
		$whereOpr = ' WHERE ppt = ? AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?';
		
		$lat1 = $lat - 1; $lng1 = $lng - 1;
		$lat2 = $lat + 1; $lng2 = $lng + 1;
		
		$Vals = $ppt.', '.$lat1.', '.$lat2.', '.$lng1.', '.$lng2;
		// add time diff too

		$whereOprA='';
		$whereOprB='';
		$rtnVals ='';
		$rptVals ='';
		
		if($rptType==1){
			$whereOprA .=  $whereOpr.$concludingQuery;
			$rptVals .= $Vals.$concludingVal;
			$whereOprB .= $whereOpr;
			$rtnVals .= $Vals;
		}
    	if($rptType==2){
			$whereOprA .=  $whereOpr;
			$rptVals .= $Vals;
			$whereOprB .= $whereOpr.$concludingQuery;
			$rtnVals .= $Vals.$concludingVal;
		}
		$check = $this->selectStmt('lst_item', $whereOprA, $rptVals);
		$check2 = $this->selectStmt('found_asset', $whereOprB, $rtnVals);
		//catch the error below in case no past lst rpt
		
		$found_id = '';
		if(count($check2)>0){
		   $found_id .= $check2[0]['found_id'];
		}

		/*---------START---------*/
        
		$inboxData = array("user_id"=>$owner_id, "found_id"=>$found_id, "msg_id"=>$msg_id, "donation_id"=>$donation_id, "distress_id"=>$distress_id);
		$reply='';



		if($rptType==1 && count($check)==0){
	   		//Congrats, your item was found
	   		if(count($check2) > 0){
	   			$userData = $this->userId();
				$loser_id = $userData[0]['profile_id'];

				$rtnDataStr = $loser_id.', '.$_ppt.', '.$lat1.', '.$lat2.', '.$lng1.', '.$lng2;

				$inboxData['user_id'] = $loser_id;
				//msg owner(user)
				$this->insert2Db('xnote', $inboxData);
			  	$this->updateStmt('found_asset', 'owner_id = ?  WHERE ppt = ? AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?', $rtnDataStr);
				$reply .= "Congrats, your lost item was found.";
			}
			elseif(count($check2)==0){
				//insert to db
				$userData = $this->userId();
				$user = $userData[0]['profile_id'];
		   		$rptDataArray = array("user_id"=>$user, "ppt"=>$_ppt, "description"=>$desc_r_city, "lat"=>$lat, "lng"=>$lng);
				$this->insert2Db('lst_item', $rptDataArray);
				$reply .= "Your report was successful.";
			
			}
			
		}

		elseif($rptType==2 && count($check2)==0){
	   		//Great job, the owner is notified
			if(count($check) > 0){
				$owner_id =  $check[0]['user_id'];
				$inboxData['user_id'] = $owner_id;
				$rtnData['contact'] = $contact;

				$this->insert2Db('found_asset', $rtnData);
//select fndid here
				$check22 = $this->selectStmt('found_asset', $whereOprB, $rtnVals);
				$found_id = $check22[0]['found_id'];
				$inboxData['found_id'] = $found_id;

				//msg owner(anotherUser)
				$this->insert2Db('xnote', $inboxData);
		    	$reply .= "Successful and quite timely. Good job.";
		    }
		    elseif(count($check)==0){
		   			//insert to db
	   			$this->insert2Db('found_asset', $rtnData);
				$reply .= "The found item report was successful.";

		    }
		}
		elseif($rptType==1 && count($check) >0){
			//sorry, you cant report twice
	    	 $reply .= 'You have reported this loss already';
		}
		elseif($rptType==2 && count($check2) >0){
			//sorry, you cant report twice
			 $reply .= 'You have reported this already';
		}
		return $this->reply = $reply;
	}

	public function setReport2($tableName, $data){
	
			$this->insert2Db($tableName, $data);
			$reply = "The theft report of your ".$data['ppt']." was successful";
		
		return $this->reply = $reply;
	}


}