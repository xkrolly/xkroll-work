<?php
class UsersView extends Users {
    public $scriptElements = "";
   	public $contact;
   	public $css = '';
   	public $embeddedStyle = '';
   	public $content = '';
   	const SM_UPLOADPATH = '../spymages/';
   	const PHPUPL = 'img/';
   	const PROFILE = 'img/profiles/';
   	const HEADER = 'img/header/';
   	const DONATIONS = '../donations/';
   	const REQUEST = '../request/';
   	const SM_MAXFILESIZE = 1000000;
   	public function spinner(){
   		$time = microtime(TRUE);
   		//if()
   		return "<div class='spinner'></div>";
   	}
	
	public function imgProcessor($file_name, $file_tmp_name, $height, $width, $destination_URL){
		$maxDimW= 1000;
		$maxDimH=800;
		//adjustImg();

		//function adjustImg(){
			list($width, $height, $type, $attr) = getimagesize( $file_name );
			if ( $width != $maxDimW || $height != $maxDimH ) {
			    $target_filename = $file_name;
			   $ratio = $width/$height;
			    if( $ratio > 1) {
			        $new_width = $maxDimW;
			        $new_height = $maxDimH;
			    } else {
			        $new_width = $maxDimW*$ratio;
			        $new_height = $maxDimH;
			    }
			    $src = imagecreatefromstring( file_get_contents( $file_name ) );
			    $dst = imagecreatetruecolor( $new_width, $new_height );
			    imagecopyresampled( $dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
			    imagedestroy( $src );
			    imagepng( $dst, $target_filename, 9 ); // adjust format as needed
			    imagedestroy( $dst );
			}
		
//add other codes below
			 $check=getimagesize($file_tmp_name);
			  $imageFileType = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
     	   if($check!== false){
                // Allow certain file formats
	            if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif" ){

	            	  $target = $destination_URL/$user_id.substr($destination_URL, 0, 1).time().'.'.$imageFileType;
	     
	                if (move_uploaded_file($file_tmp_name, $target)){
	                  return true;
	                }else{return false;}
	            }
	            else{
	               $reqResp.="<strong>Only PDF, DOC, JPG, PNG & JPEG files are allowed!</strong>";
	            }
	        }
	        else{
                $reqResp.="<strong>Sorry, file size too large!</strong>";
            }


		//}

	}   	
   	public function showModal($modalContent, $selector, $contentType){
   		$contentType == 'file' ? $modalContent = include($modalContent) : $modalContent;

		$modal="<div id='".$selector."' class='".$selector."' style='display:none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background: rgba(0,0,0,0.2);'>
				<div style='display:flex; justify-content:center; align-items:center; text-align:center;'>
			
					<div style='background:white; height:auto; border-radius:10px; position: fixed; left: auto; top: 6%; z-index:1; padding:5px 10px 5px 10px;'>
						<div class='' onclick=$('#".$selector."').fadeOut(-500) style='text-align:right;'>
            	          <span class='close md'><strong>&times</strong></span>
                	    </div>
            	        <div style='padding: 20px; text-align:center;'>";
		$modal.= $modalContent;
 		$modal.="		</div>
					</div></div>
				</div>";
 		return $modal;
	}

	public function sanitise($input){
		$data = trim($input);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		$data = strip_tags($data);
	    $data = filter_var($data, FILTER_SANITIZE_STRIPPED);

		return $data;
	}
	public function searchPanel(){
	
		$panel='<div class="them" id="searchPanel" style="background:#fff; filter:drop-shadow(2px 2px 150px #aaa); padding:1px; position:fixed; right:0; left:0; bottom:0; z-index:20; display:none;">
        <div style="text-align:center;"><i class="fa fa-minus" style="font-size:20px; color:#f01e6b; margin-top:-2px;" onclick=$("#searchPanel").slideUp("slow");></i></div>
        <form method="post" id="" class="search_data">
          <input type="hidden" name="searchType" id="searchType" value="1">
          <div style="display:flex; flex-direction:column; align-items:center; margin:2px;">
            <div style="display:flex; font-size:20px; border:1px solid #aaa; border-radius:15px;">
              <button type="submit" name="submit" tabindex=3 class="" id="search_btn" style="width:10vw; background:#fff; border:transparent; border-top-left-radius:15px; border-bottom-left-radius:15px; padding:6px;">
                  <i class="fa fa-search" style="font-size:16px;"></i>
              </button>
              <input type="search" incremental name="input" placeholder="Search lost item..." aria-label="Search the pool of found properties for your lost item" style="padding:6px; font-size:16px; width:52vw; border:1px solid #aaa; border:transparent; border-right:1px solid #aaa;"/ id="srchLossFm">
                        <input type="search" name="city" id="addCityFm" placeholder="add City..." style="border-top-right-radius:15px; width:32vw; padding:6px; font-size:16px; border:1px solid #aaa; border:transparent; border-bottom-right-radius:15px;" />
            </div>
          </div>

        </form>
        <hr>
        <div>
    		<p id="searchRpts" style="margin-left:20px;"><a href=# onclick="switchSrchForm()" style="color:#000;">Verify Ownership</a></p>
        </div>
       </div>
      <div style="padding:2px; margin-bottom:0px;">
          <span id="search_results"></span>
      </div>';
return $panel;
	}
	public function showAssistModal($modalContent, $selector, $i, $item, $chatContact, $userContact, $did, $addContact, $assistNote, $ndyContact){
		$modal="<div id='".$selector."' style='display:none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background: rgba(0,0,0,0.2);'>
					<div style='display:flex; justify-content:center; align-items:center; text-align:center;'>
					<div style='background:white; height:auto; border-radius:10px; position: fixed; left: auto; top: 5%; z-index:1; padding:15px 25px 15px 25px;'>
 		                <div style='display:flex;'>
 		                <div class='far-left md'>
    		            	<strong class='backToOptList collapse'>&lt;&lt;</strong>
            		    </div>
						<div class='' onclick=$('#".$selector."').fadeOut(-500) style='text-align:right;'>
            	          <span class='close md'><strong>&times</strong></span>
                	    </div>
                	    </div>
            	        <div style='padding: 0 25px 25px 0; '>";
		$modal.=  			include($modalContent);
 		$modal.="		</div>
					</div></div>
				</div>";
 		return $modal;
		//return $this->showModal($modalContent, $selector);
	}
	
   	public function logout(){
		$home_url='index';
		//'./';

		if(isset($_SESSION['user_id'])){
			$userData = $this->fetchUser();
			$user = $userData[0]['user_id'];
		  $vals = ' , 0, 0, ' . $user;
		  $this->updateStmt('skyman_user', 'session = ?, online = ?, eternity = ?, WHERE user_id = ?', $vals);

		    $_SESSION=array();
		    if(isset($_COOKIE[session_name()])){
			    setcookie(session_name(),'', time()-3600);
				session_destroy();
		    }
		}
		   //add dis
		if(isset($_COOKIE['id']) && isset($_COOKIE['sess'])){
		    setcookie('id', '', time() - 60*60*24*30, '/');
		    setcookie('sess', '', time() - 60*60*24*30, '/');
		    header('Location: ' .$home_url);
		    die();
		}
		header('Location: ' .$home_url);
   	}

   	public function session(){
   		$userData = $this->fetchUser();
		$user_id = $userData[0]['profile_id'];
		isset($_SESSION['user_id']) ? $vals=  $user_id . ', 1' : $vals='0, 1';
		
		$keepLoggedIn = $this->select('skyman_user', ' WHERE user_id = ? AND eternity = ?', $vals);
		
		if(count($keepLoggedIn)==0){
		
		    if(isset($_SESSION['timeout'])){
		        $diff=time()-$_SESSION['timeout'];
			       
		        if($diff>1200){
					session_destroy();
		    	    header("location:./");
		        	exit();
		        }
		     }
		}
		$_SESSION['timeout']=time();

   	}
   	public function addScript( $src ){
		$this->scriptElements .= "<script src='$src'></script>";
	}
	public function addCSS( $href ){
		$this->css .= "<link href='$href' rel='stylesheet'/>";
	}

	public function update_Impact($user, $help_status){
		$userProfile = $this->userProfile($user);
		$helps_perWk = $userProfile[0]['n_assist'];
		$cii = $userProfile[0]['cii'];
		$current_time=time();
		$new_wk_begins_date = $userProfile[0]['impact_date'];
  		$new_wk_begins = strtotime($new_wk_begins_date);
  		$time_diff=time() - $new_wk_begins;
		$newDate = date('Y-m-d h:i:s', time());
  		$aDay = 1*24*60*60;

		$num_days = floor($time_diff/$aDay);
			
		if($help_status==0){
			if($num_days >= 1){

			$new_cii = $cii - $num_days;

			$vals = $new_cii.', '.$newDate.', '.$user;
			$this->updateStmt('profile', 'cii = ?, impact_date=? WHERE profile_id = ?', $vals);
	  		}
		}elseif($help_status!=0){
			$score_per_assist = 2;
			$new_cii = $cii + ($help_status * $score_per_assist);
			$help_status > 0 ? $new_n_assist= $n_assist + 1 : $new_n_assist = $n_assist;
			$vals = $new_cii.', '.$new_n_assist.', '.$user;
	  		$this->updateStmt('profile', 'cii = ?, n_assist=? WHERE profile_id = ?', $vals);
		}
	}

	public function getIP(){
		if(!empty($_SERVER['HTTP_CLIENT_IP'])){
			$ip=$_SERVER['HTTP_CLIENT_IP'];
		}
		elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else{
			$ip=$_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	public function CiL($score, $startDate){
		//, $num_months){
		$start_date=strtotime($startDate);
	    $current_time=time();
	    $time_diff=$current_time-($start_date);//+32450);
	    $days=($time_diff)/86400;

	     $newDate = date('Y-m-d h:i:s', time());
//	     $new_num_months = $num_months + floor($days/28);
 		$new_num_months = floor($days/28);
	    $new_num_months <= 0 ? $new_num_months = 1 : $new_num_months;  
	    //num helped per 2wks
	     $user_grade = $score/(8* $new_num_months);
	     $userTitle ='';
	     $bg='';
	     $userGrade=round($user_grade);
	    // var_dump($userGrade);
	     //cii is total help rendered ever since
	     //$cii=a1b2c3d4e5;

	     switch($userGrade){
			case 0 :
			case 1 :
				$userTitle .= "Agent X";
				$bg .= '#ddd';
				break;
			case 2 :
				$userTitle .= "Cadet officer";
				$bg .= '#ccc';
				break;
			case 3 :
				$userTitle .= "Corporal III";
				$bg .= '#aaa';
				break;
			case 4 :
				$userTitle .= "Corporal II";
				$bg .= 'brown';
				break;
			case 5 :
			case 6 :
				$userTitle .= "Corporal";
				$bg .= 'orange';
				break;
			case 7 :
			case 8 :
			case 9 :
			case 10 :
			case 11 :
			case 12 :
			case 13 :
				$userTitle .= "LeutenanX";
				$bg .= 'gold';
				break;
			case 14 :
			case 15 :
			case 16 :
			case 17 :
			case 18 :
			case 19 :
			case 20 :
				$userTitle .= "CaptainX";
				$bg .= 'lime';
				break;
			case 21 :
			case 22 :
			case 23 :
			case 24 :
			case 25 :
			case 26 :
			case 27 :
				$userTitle .= "Major";
				$bg .= '#f98feb';
				break;
			case 28 :
			case 29 :
			case 30 :
			case 31 :
			case 32 :
			case 33 :
			case 34 :
				$userTitle .= "Colonel";
				$bg .= 'purple';
				break;
			case 35 :
			case 36 :
			case 37 :
			case 38 :
			case 39 :
			case 40 :
			case 41 :
				$userTitle .= "General III";
				$bg .= 'aqua';
				break;
			case 42 :
			case 43 :
			case 44 :
			case 45 :
			case 46 :
			case 47 :
			case 48 :
				$userTitle .= "General II";
				$bg .= 'turquoise';
				break;
			case 49 :
			case 50 :
			case 51 :
			case 52 :
			case 53 :
			case 54 :
			case 55 :
			case 56 :
			case 57 :
			case 58 :
			case 59 :
			case 60 :
			case 61 :
			case 62 :
			case 63 :
			case 64 :
			case 65 :
			case 66 :
			case 67 :
			case 68 :
			case 69 :
				$userTitle .= "X General";
				$bg .= '#2196f3';
				break;
			case 70 :
			case 71 :
			case 72 :
			case 73 :
			case 74 :
			case 75 :
			case 76 :
			case 77 :
			case 78 :
			case 79 :
			case 80 :
			case 81 :
			case 82 :
			case 83 :
			case 84 :
			case 85 :
			case 86 :
			case 87 :
			case 88 :
			case 89 :
				$userTitle .= "X Marshal";
				$bg .= '#f01e6b';
				break;
			default :
				$userTitle .= "White Angel";
				$bg .= '#fff';
			}

			$new_num_months < 1? $duration = $new_num_months * 30 .' days' : $duration=$new_num_months.' months';
			$new_num_months>=12 ? $duration = round($new_num_months/12, 2) .' years' : $duration; 
			$bg == '#fff' ? $color = "#bbb" : $color = "#fff";
			$bg == '#fff' ? $border = "1px solid #ccc;" : $border = "0";
			
	     return '<span style="color:'.$color.'; border:'.$border.'; background:'.$bg.'; padding:2px; font-size:12px; filter:drop-shadow(1px 1px 1px #ccc); border-radius:2px;">'.$userTitle.'</span>';
	     //' ~ '.$duration.' CII: '.$score;
	}

	public function ciBar($mark){
	  $numObj = $mark/10;
		
		switch($numObj){
			case 1 :
				$color = "red";
				break;
			case 2 :
				$color = "red";
				break;
			case 3 :
				$color = "red";
				break;
			case 4 :
				$color = "#f40808";
				break;
			case 5 :
				$color = "#f45e08";
				break;
			case 6 :
				$color = "#f4f016";
				break;
			case 7 :
				$color = "#9ff416";
				break;
			case 8 :
				$color = "#4ef416";
				break;
			case 9 :
				$color = "green";
				break;
			case 10 :
				$color = "green";
				break;
			case 11 :
				$color = "green";
				break;
			case 12 :
				$color = "#2196f3";
				break;
		}
	  $numObj<4? $color="red" : ($numObj<7 ? $color="orange" : ($numObj<20 ? $color="green" : $color="#2196f3"));

	  $eachBar="<div style='width:10px; height:19px; border-radius:2px; border:1px solid #fff; background:$color;'></div>";
	   $emptyBar="<div style='width:10px; height:19px; border-radius:2px; border:1px solid #fff; background:#ddd;'></div>";
	 
	  $cap="<div style='width:5px; height:7px; border:1px solid #ccc; align-self:center;'></div>";
	   	$bar='';
	   	$numObj > 10 ? $numObj = 10 : $numObj;
	   	$numObj<1 ? //when ccii is negative
	   	$remObj = 10 : $remObj = 10 - $numObj;
	   for($i=0; $i<$numObj; $i++){
	   	$bar.=$eachBar;
	   }

	   for($i=1; $i<$remObj; $i++){
	   	$bar.=$emptyBar;
	   }
	   $bar.=$cap;
	  return "<div style='display:flex;'>
	  			<div style='display:flex; border:1px solid #ccc; padding:2px;'>".$bar."</div>
	  		<div style='width:3px;'></div><span style='color:#aaa;'>$mark%</span>
	  		</div>";

	}

	public function harvesineF($lat1, $lng1, $lat2, $lng2) {
		return $this->harvesine($lat1, $lng1, $lat2, $lng2);
	}

	public function settingsPage(){
		$rows= $this->fetchUser();

		$pag = include('views/settingsFm.php');
		return $pag;
	}

	/*below is solely for interactive button updates*/
	public function homeFeed(){
		return $this->fetchFeed();
	}

	public function showComment($discussId){
		$c = $this->select('donation', ' WHERE donation_id = ?', $discussId);
		$proof = $c[0]['proof'];
		$useMedia = $c[0]['useMedia'];
		$useMedia == 0 ? $proof = $proof : $proof = '<span style="color:red; font-size:14px;">AUDIO FILE not available!</span><br><br>';
		$userData= $this->fetchUser();
		$user_id = $userData[0]['profile_id'];
		$vals = $user_id.', '.$discussId;
		$comment = $this->select('comments', ' WHERE user = ? AND discussId = ?', $vals);
			
		$allComments=count($comment)-1;

		//$proof = $c[0]['proof'];

		$commentList = "
		<div style='background:#fff; padding:5px;'>
		  <div style='margin:2px;'><a href='home' style='text-decoration:none; color:#000;'><i class='fa fa-arrow-left'></i></a>

			<div style='display:block; text-align:center; border:1px solid #ccc; padding:10px; border-radius:5px; width:95vw;'>".$proof."
			<p style='display:flex; justify-content:space-around; margin-bottom:0px; color:#ddd'><i class='fa fa-comment' onclick=$('.commentCase').show()></i><i class='fa fa-thumbs-down fa-flip-horizontal'></i>
				<i class='fa fa-bookmark'></i>
				<i class='fa fa-share-alt'></i></p>
			</div>
		  </div>
		</div>";
	
	$commentList.="
		<div class='addComment' style='overflow:auto; padding:20px;' id='addComment'>
		<label id='commentOpener'></label>";	
	while($allComments >= 0){
		$commentList.='
		<div class="container">
						<div class="far-left"><img src="img/helpmee.png" style="width:25px; border:1px solid #666; border-radius:50%;"/></div>
					   <div class="center" style="flex:2; flex-basis:76%; border:1px solid #ccc; border-radius:5px;">'.
					   		$comment[$allComments]['comment'].' <br>'.$this->time($comment[$allComments]['comment_date']).'
					   </div>
					  </div>

					   <br>';
		
//		$commentList.='<label>'.$comment[$allComments]['comment'].' '.$this->time($comment[$allComments]['comment_date']).'</label><br>';
			
		$allComments--;
		}

$commentList .= "</div><br>
	<div>
	<form method='post' id='commentForm'>
	  	<input type='hidden' name='discussId' value='".$discussId."'>

  		<div class='container collapse commentCase' style='position:fixed; bottom:10px; margin-top:10px; background-color:white; z-index:6; width:100%; border-top:1px solid #bbb; padding-top:2px;'>
  				<span onclick=$('.commentCase').hide()>&times</span>
	  		<textarea placeholder='Add your comment...' id='commentBox' class='form-control' name='comment' style='padding:5px; margin:0;'></textarea><br>
	  		<button type='submit' name='submit' id='submit' class='commentBtn'>Submit</button>
	  	</div>
	</form>
	</div>";  	
		return $commentList;
	}

	public function showFeed(){
		//check for geolocation activity
		$homeFeedPanel='';
				if(	$_SESSION['loadNewsFeed'] != false){
					$_SESSION['geoloc_switch_query']+=1;
				$_SESSION['geoloc_switch_query'] >= 3 ? $info = '<div style="color:red; font-size:13px; padding:5px; font-weight:bold;">Ensure your device location is on and allow access of this application to your device location under location settings.</div>' : $info='';
			$homeFeedPanel.='<div style="display:flex; z-index:20; font-size:16px; font-family:roboto; border-radius:5px; text-align:center; position:fixed; left:5%; right:5%; bottom:12%; margin-left:auto; margin-right:auto; padding:5px; color:#fff;">

					<div style="align-items:center; justify-content:center; padding:5px; box-shadow:2px 2px 2px #bbb, -1px -1px 1px #bbb; border-right:1px solid #fff; background:#f01e6b; border-top-left-radius:10px; border-bottom-left-radius:10px;">
						<span class="material-icons" style="font-size:20px; color:#fff;">&#xe0c8</span>
					</div>
					<div style="background:#fff; box-shadow:2px 2px 2px #bbb, 0px -1px 2px #bbb; padding:5px; border-top-right-radius:10px; border-bottom-right-radius:10px; color:black;">Turn on your device location and click on <a href="" onclick="getLocation()">show nearby feeds</a>.'.$info.'
					</div>
				</div>';
		}

		$a=1;
		$fd = $this->fetchFeed();
		$ln=count($fd)-1;
		$ln>0 ? $regCompleted = $fd[0]['regCompleted'] : $regCompleted='';

		$homeFeedPanel.="<div class='viewWidth'>
		<div draggable='true' onclick=$('#mdd2').show() class='hover inspectBtn' style='padding:10x; margin-bottom:8px;'>
				<i class='fa fa-search hover' style='font-size:16px; color:#f01e6b;'></i>
		</div>
		<div draggable='true' onclick=$('#mdd').show() class='hover requestBtn'>
			<strong>
				<a href=# style='color:#fff;' onclick='getLocation()'>
					<i class='fa fa-bullhorn' style='font-size:15px;'></i>
				</a>
			</strong>
		</div>";

/*if($regCompleted==0){
	$homeFeedPanel.=$this->showModal('views/completeRegFm.php', 'completeReg', 'file');
}*/
$homeFeedPanel.=$this->showModal('views/requestFm.php', 'mdd', 'file');
$homeFeedPanel.=$this->showModal('views/searchNeedFm.php', 'mdd2', 'file');
//$homeFeedPanel.=$this->showModal('views/inspectFm.php', 'mdd2', 'file');

		if($ln<0){
			$homeFeedPanel.='<div style="display:flex; margin-top:45%; justify-content:center; align-items:center; font-weight:bold; color:#555; font-size:20px;">No request yet, make one</div>';
		}
		while($ln>=0){
			$homeFeedPanel.=include('views/homeFeed.php');
			$ln--;
		}
		$homeFeedPanel.="</div><br><br><br><br><br><br>";
		
			 return $homeFeedPanel;
	}

	public function select($a, $b, $c) {
		$result = $this->selectStmt($a, $b, $c);
		return $result;
	}

	public function rtnPg(){
		$r = $this->fetchUser();
		$contact = $r[0]['contact'];
		$returnPg =include('views/returnFm.php');
		return $returnPg;

	}

	/*public function confirmReg($rlink, $userMail){
	$msg="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
                'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
        <html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>
         <head></head>
         <body style='padding:10px'><div style='background-color:#eee; padding:10px;'><div style='border:2px solid #ff00e2; background-color:white; border-radius:10px; padding:10px; text-align:justified'>
            <h2 style='text-align:center; color:#ff00e2'>Welcome to Tracus!</h2><br>
           <p style='font-sise:20px; text-align:justified'>Click the confirmatory link below to complete your registration and start enjoying the free packages we've got for you.</p><br><a href='".$rlink."' style='text-decoration:underline; text-align:center'>Proceed to complete your registration</a><br><p style='text-align:center'>Xkroll, the timely help in dire need!</p><hr style='color:#ddd'><p class='pfem' style='color:white'></p>
         </div></div></body></html>";
   		$this->mailer($userMail, 'Registration Confirmatory Link', $msg);
	}*/

	public function fetchUser() {
		return $this->userId();
	}
	public function fetchProfile($where) {
		return $this->userProfile($where);
	}

	public function srchPg(){

		$r = $this->fetchUser();
		$city = $r[0]['city'];
		$searchPg = include('includes/searchFm.inc.php');
			
		return $searchPg;
	}

	/*public function fetchSrch($input, $city, $type) {
		$clean_search=str_replace(',', ' ', $input);
		$search_word=explode(' ', $clean_search);
		$srchWord_Array=array();
		
		if(count($search_word)>0){
			foreach($search_word as $word){
	        	if(!empty($word) && strlen($word)>2){
				   $srchWord_Array[]=$word;
				}
			}
		}

		$where_list=array();
		$whereVal=array();
    	if(count($srchWord_Array)>0){
        	foreach($srchWord_Array as $word){
        		if($type!=2){ //i.e $type==1 or 3
				  	if(!empty($city)){
			      		$where_list[]="ppt LIKE ? AND city = ? OR description LIKE ? AND city = ?";
			      		$whereVal[] = "%$word% ".$city." %$word% ". $city;
	          		}  
	    			elseif(empty($city)){
	    				$where_list[]="ppt LIKE ? OR description LIKE ?";
		         		$whereVal[] = "%$word% %$word%";
	         		}
         		}
         		elseif($type==2){
         				$where_list[]="firstname = ? OR lastname = ?";
		         		$whereVal[] = "$word $word";
		     	}
    		}
  		}
	
		$_where_clause =implode(' OR ', $where_list);
		$where_clause = $_where_clause . ' ORDER BY reporting_date DESC';
		
		$type == 2 ? $where_clause = $_where_clause : $where_clause;
		$type == 1 ? $dbTable = 'found_asset' : $dbTable = 'profile';
		$type == 3 ? $dbTable ='lst_item' : $dbTable;
		
		if(!empty($where_clause)){
		$whereVal = implode(', ', $whereVal);

		return $this->selectStmt($dbTable, ' WHERE '.$where_clause, $whereVal);
		}
	}*/
	public function fetchSrch($input, $city, $type) {
		//$clean_search=str_replace(',', ' ', $input);
		$search_word=explode(', ', $input);
		$srchWord_Array=array();
		
		if(count($search_word)>0){
			foreach($search_word as $word){
	        	if(!empty($word) && strlen($word)>2){
				   $srchWord_Array[]=$word;
				}
			}
		}

		$where_list=array();
		$whereVal=array();
		$userData = $this->fetchUser();
		$user = $userData[0]['profile_id'];
		$lat = $userData[0]['lat']; $lat1 = $lat - 1; $lat2 = $lat + 1;
		$lng = $userData[0]['lng']; $lng1 = $lng - 1; $lng2 = $lng + 1;
    	if(count($srchWord_Array)>0){
        	foreach($srchWord_Array as $word){
        		if($type==1){ 
        		  	if(!empty($city)){
			      		$where_list[]="ppt LIKE ? AND city = ?";
			      		$whereVal[] = "%$word%, ".$city;
	          		}  
	    			elseif(empty($city)){
	    				$where_list[]="ppt LIKE ? AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?";
			      		$whereVal[] = "%$word%, ".$lat1.", ".$lat2.", ".$lng1.", ".$lng2;
	         		}
         		}
         		if($type==3){
         			$where_list[]="ppt LIKE ? AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?";
			      		$whereVal[] = "%$word%, ".$lat1.", ".$lat2.", ".$lng1.", ".$lng2;
	          		}
         		elseif($type==2){

         			$where_list[]="firstname = ? OR lastname = ?";
		         	$whereVal[] = "$word, $word";
		     	}
         		elseif($type==4){
         			$where_list[]="item_list LIKE ? AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?";
			      		$whereVal[] = "%$word%, ".$lat1.", ".$lat2.", ".$lng1.", ".$lng2;
		     	}

    		}
  		}
	
		$_where_clause =implode(' OR ', $where_list);
		$where_clause = $_where_clause . ' ORDER BY reporting_date DESC';
		
		$type == 2 || $type == 4 ? $where_clause = $_where_clause : $where_clause;
		$type == 1 ? $dbTable = 'found_asset' : $dbTable = 'profile';
		$type == 3 ? $dbTable ='lst_item' : $dbTable;
		$type == 4 ? $dbTable = 'donlist' : $dbTable;
		
		if(!empty($where_clause)){
		$whereVal = implode(', ', $whereVal);
		return $this->selectStmt($dbTable, ' WHERE '.$where_clause, $whereVal);
		}
	}
	public function timeline($table, $userColumnName, $dateColumnName){
		$userData = $this->fetchUser();
		$user_id = $userData[0]['profile_id'];

		$rqst_Data = $this->selectStmt($table, ' WHERE '.$userColumnName.' = ? ORDER BY '.$dateColumnName.' DESC', $user_id);
		return $rqst_Data;
	}
	public function numOfYears($time){
		$time_ago=strtotime($time);
    $current_time=time();
    $time_diff=$current_time-($time_ago+32450);
    $days=($time_diff-10368000)/86400;
    $years=round($days/365.25);
    	return $years;
	}

	/*public function voiceRec_CountDown($sec){
		$audio =   "<div class='unselected' id='audioProof' style='display:none; margin-bottom:20px; width:100%;'>
                  <div'>
                    <div class='text-center' id='aud'>

                        <span id='countDownDisplay'>
                        </span>
                        <audio id='audio'></audio>
                    </div>
                          <input type='hidden' value='$sec' name='myaudio' id='myaudio'>
                  </div>
                </div>";
                return $audio;
	}
*/
/*	public function voiceRec_CountDown(){
		$audio =   "<div class='unselected' id='audioProof' style='display:none; margin-bottom:20px; width:100%;'>
                  <div'>
                    <div class='text-center dropshadow' id='aud'>
                      <div style='display:flex; justify-content:space-evenly;'>

                        <span id='countDownDisplay'>
                        </span>
                        <audio id='audio'></audio>
                      </div>   
                    </div>
                          <input type='hidden' value='' name='myaudio' id='myaudio'>
                  </div>
                </div>";

                return $audio;
	}
*/	
/*	public function time2($timestamp){
	  		$time_ago=strtotime($timestamp);
  			$current_time=time();
  
			$time_diff=$current_time-($time_ago);
  			$seconds=$time_diff;
  			$minutes=round($seconds/60);
			$hours=round($seconds/3600);
			$days=round($seconds/86400);
			$weeks=round($seconds/604800);
			$months=round($seconds/2629440);
			$years=round($seconds/31553280);
		  $r ="<label style='color:#aaa; font-size:12px'> ~";
		  if($seconds<=59){
		  	$r .= "<span style='color:#2166f3'>Just Now</span>";
		  }
		  else{
		  	if($seconds<3600){
		  		$seconds ==60 ?  $r .= "<span style='color:#2166f3'>1 min ago</span>" : $r .= "<span style='color:#2166f3'>$minutes mins ago</span>";
		  	}
		  	else{
		  		$r .= $hours." hrs";
		  	}
		  }
			

			if($minutes==1){
    			$r .= "<span style='color:#2166f3'>1 min ago</span>";
   			}
   			elseif($minutes<=5){
   				$r .= "<span style='color:#2166f3'>$minutes mins ago</span>";	
   			}
   			else{
    			$r .= $minutes." mins";
   			}
  		  }
  		  elseif($hours<24){
   			if($hours==1){
    			$r .= "1 hr";
   			}
   			else{$r .= $hours." hrs";}
  		  }
  		  elseif($days<=7){
   			if($days==1){
    			$r .= "yesterday";
    		}
   			else {
   				//$r .= date('D', $days);
   				$r .= $days." days";
   			}
   		  }
  		  elseif($weeks<=4.3){
//  			else {
   				$r .= date('M d', $seconds);
  				//}
   		  }
  		  elseif($months<=12){
   			if($months==1){
    			$r .= date('M d', $seconds);
    		}
   			else{
			    $r .= date('M d', $seconds);
			}
  		  }
  		  else{
   			if($years==1){
   				$r .= date('M d', $seconds);
   			}
   		  	else{
    			$r .= date('M, Y', $seconds);
    	   	}
  	      }
  	      $r.="</label>";
  	      return $r;
	}
*/
	public function time($timestamp){
	  		$time_ago=strtotime($timestamp);
  			$current_time=time();
  
			$time_diff=$current_time-($time_ago);
  			$seconds=$time_diff;
  			$minutes=round($seconds/60);
			$hours=round($seconds/3600);
			$days=round($seconds/86400);
			$weeks=round($seconds/604800);
			$months=round($seconds/2629440);
			$years=round($seconds/31553280);
		  $r ="<label style='color:#aaa; font-size:12px'> ~";
		  if($seconds<=59){
		  	$r .= "<span style='color:#2166f3'>Just Now</span>";
		  }
		  elseif($seconds>=60 && $seconds<120){
//		  elseif($minutes<=59){
  			$r .= "<span style='color:#2166f3'>1 min ago</span>";
   			}
   			elseif($seconds>120 && $seconds<3600){
   				$r .= "<span style='color:#2166f3'>$minutes mins</span>";	
   			}
  		  elseif($seconds>=3600 && $seconds<7200){
    			$r .= "1 hr";
   			}
          elseif($seconds>=7200 && $seconds <86400){$r .= $hours." hrs";
      		}

  		  elseif($seconds >= 86400 && $seconds<172800){
    			$r .= "yesterday";
    		}
   		elseif($seconds >= 172800 && $seconds < 604800) {
   				$r .= $days." days";
   		  }
  		  elseif($seconds > 604800 && $seconds < 1190000){
  				$r .= "1 week";
   		  	
  		  }
  		  elseif($seconds >= 1190000 && $seconds < 2419200){
  				$r .= $weeks." weeks";
   		  	
  		  }
  		  elseif($seconds >2419200){// && $seconds <31449600){
   				$r .= date('M d', $seconds);
  		  }
/*  		  else{
    			$r .= date('M, Y', $seconds);
  	      }
*/  	      $r.="</label>";
  	      return $r;
	}

	public function notePg(){
		$allNotes = $this->fetchNotes();
		$ln = count($allNotes)-1;
		$Notes="<div style='display:flex column; width:100vw; background:#fff; min-height:101vh; padding:50px auto 550px auto;'>";
		if($ln <0){
		 $Notes .= "<div style='position:fixed; margin-top:48%; width:100%; text-align:center; color:#555; font-family:san-serif; font-size:25px; font-weight:bold;'>No message!</div>";
		}
		else{
			while($ln>=0){
				$Notes .= include('includes/notification.inc.php');
				$ln--;
			}
			$Notes .='</div>';
		}
		return $Notes;
	}
	
	public function profile_page(){
		$Rquests=$this->timeline('donation', 'tuser_id', 'd_date');
		$Rpts=$this->timeline('lst_item', 'user_id', 'reporting_date');
		$Rtns=$this->timeline('found_asset', 'user_id', 'reporting_date');
		$DonList=$this->timeline('donlist', 'user_id', 'donation_date');
	
		$row = $this->fetchUser();
		//$profilePage="<div style='background:red;'>";
		$profilePage=include('views/profilePg.php');
		//$profilePage.="</div>";
		return $profilePage;	
	}

	public function btnUpd($don_id){
		$row = $this->select('donation', ' WHERE donation_id = ?', $don_id);
		$emp = $row[0]['empathy']; 
		$ban = $row[0]['nonreal']; 
		$did = $row[0]['donation_id'];
        return json_encode(array("upd_emp" => $emp, "upd_ban" =>$ban, "id"=>$did));
	}

	/*public function test($val){
		$test = $this->selectNow($val);
		return $test[0]['item'];
	}*/
}