<?php
//STRANDED IN DIRE SITUATION AND READY TO SEEK NEARBY HELP?

$page="<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en' dir='ltr'>
  <head>
    <meta charset='utf-8'>
    <meta name='description' content='Xkroll is a nearby help search platform for dire needs'>
    <meta name='Login page' content='Xkroll login page'>
    <meta http-equiv='Content-Type' content='text/html' charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta http-equiv='x-ua-compatible' content='ie=edge'>
    <meta name='theme-color' content='#f01e6b'>
    <link rel='manifest' href='manifest.json' />
    <link rel='apple-touch-icon' href='img/logo192.png' />

    <style>
.modal-header{
  padding: 2px 6px;
  color: #fff;
}

.modal-body{
  padding: 25px;
  text-align:center;
}

@keyframes animateflas{
  from {background: linear-gradient(to top right, white, black)}
  to {background: linear-gradient(45deg, white, black)}
  to {background: linear-gradient(45deg, black, white)}
}

/*.flex{
  display:flex;
  justify-content:center;
  align-items: center;
  height: 100px;
  width: 100%;
}*/
.flash{
/*  background: linear-gradient(45deg, #222 0 calc(50% - 10px), #666 calc(50% + 10px), #222 calc(50% + 10px) 100%);
*/
  background: linear-gradient(45deg, #222 0, #222 40%, #fff 50%, #222 62%, #222 100%);
  background-size:250% 100%;
  background-position: 100% 50%;
  transition: .4s all;
}

.flash:hover, .flash:focus{
  background-position:0% 50%;
  transition: .4s all;
}

.modal-footer{
  padding: 16px 16px;
  background: red;
  color: #fff;
  border-bottom-left-radius:5px;
  border-bottom-right-radius:5px;
}

.modal-content{
  border-radius:5px;
  position: relative;
  background-color: #fefefe;
  margin:auto;
  padding:0;
  border:1px solid #888;
  width: 80%;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  animation-name: animatetop;
  animation-duration: 0.4s;
}

@keyframes animatetop{
  from {top: -300px; opacity:0}
  to {top:0; opacity: 1}
}

.modal{
  display:none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: rgba(0,0,0,0.2);
}

.close{
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;

}

.close:hover, .close:focus{
  color:black;
  text-decoration: none;
  cursor: pointer;
}

.homepage{
      background: url(img/aerial2.jpg);
      background-attachment: fixed;
      background-size:cover;
      max-width:100%;
      color:#999;
      height:auto;
      position:relative;
}

.bg-overlay{
            background: rgb(0,0,0,0.7);
            height:100%;
            width:100%;
            padding:15px;
}

.homepage>header{
      position: absolute;
      bottom:0;
      left:0;
      height:50%;
      width:100%;
      padding: 20px 10px;
      background:inherit;
      background-attachment:fixed;
      overflow:hidden;
      margin-top:200px;
}
    
.subHeading2, .subheading2{
      font-size:28px;
}

.loginPgContent{
      font-size:20px;
}
*{
      box-sizing:border-box;
}

    </style>
    <title>Sample</title>
  </head>
  <body class='RBtn' style='background:#fcfcfc;'>
      <script>
          response();

function response(msg){
       var div = document.createElement('div');
          var node = document.createTextNode(msg);
          div.appendChild(node);
          var respPanel = document.getElementById('response');
          respPanel.appendChild(div);
          
        $('#response').css({'z-index':10, 'font-size':'16px', 'font-family':'roboto', 'border-radius':'5px', 'text-align':'center', 'position':'fixed', 'left':'5%', 'right':'5%', 'bottom':'10%', 'margin-left':'auto', 'margin-right':'auto', 'padding':'5px', 'color':'#fff', 'background-color':'red'});

            setTimeout(function(){
                            $('#response').fadeOut();
                           setTimeout(function(){
                             respPanel.removeChild(div);
                            }, 50);    
                        }, 5000);
    }
    function go(){
    response('WHen are you gonna doit');
  }
    </script>  

    <main role='main'>
      <article itemscope itemtype='http://schema.org/checkoutPage'>
        <meta itemprop='datePublished' content='2020-01-02 09:00:20 -0700 -0700'>
        <meta itemprop='dateModified' content='2021-02-02 10:30:55 -0700 -0700'>
        <script src='scripts/jquery-3.3.1.min.js'></script>
        <script src='scripts/login.js'></script>
        <div id='response'><span></span></div>
        

        <div class='homepage'>
          <div class='bg-overlay'>
          <div style='margin-bottom:100px; display:flex; color:#fff; justify-content:center; align-items:center;'>
          <div><img src='img/helpmee.webP' alt='xkroll logo' style='height:40px; width:40px;'/><label style='font-family:sans-serif; font-size:30px;'>kroll</label></div>
          <div style='margin-left:auto;' onclick=$('.loginPanel').slideDown(200)>Login</div>
          <div style='width:1px; height:18px; border:1px solid #fff; margin:auto 20px;'></div>
          <div onclick=$('.loginPanel').slideDown(200)>Sign up</div>
          </div>
          
          <header style='font-family:sans-serif;'><h1 style='color:#fff; font-size:30px; text-align:center; word-spacing:6px; line-height:35px;'>Need To Seek Help, Gist, Inform Or Alert Your Neighborhood Or People Nearby In A Jiffy?</h1>
          <h3 style='text-align:center; font-weight:normal; line-height:1.6em; padding:10px 20px; word-spacing:5px;'>
                Communicate with people nearby, disseminate urgent vital info or alert people locally and rapidly about a potential threat wherever you are anytime without previously having their contact, just with few clicks!
          </h3>

            <center id='regBtn1' style=''>
                <button type='button' style='color:#f41515; font-size:18px; font-family:sans-serif; background:#fff; border:0px; border-bottom:1px solid #ccc; padding:15px 20px;' class='btn-sm' tabindex='3' onclick=$('.loginPanel').slideDown(200)>
                  Get started with Xkroll
                </button>
            </center>
            
            </header>

            </div>
        </div>
        <div style='margin-top:50px;'>
                      <h4 class='subHeading2' style='color:#656565; text-align:center;  margin:60px auto 3px auto;'>Security tips</h4>
            <center class='loginPgContent content1' style='line-height:1.8em; padding:2px 20px; text-align:center; color:#232323;'>
                You get updates on vital info pertaining to location-based intelligence report from people wherever you are.
            </center>
   
            <h4 class='subheading2' style='color:#656565; text-align:center; margin:40px auto 3px auto;'>Urgent help sourcing</h4>
            <center class='loginPgContent content2' style='line-height:1.8em; padding:2px 20px; text-align:center; color:#232323;'>
                You get help from your nearby anywhere and anytime you are in dire need of it.
            </center>
            <h4 class='subHeading2' style='color:#656565; text-align:center; margin:40px auto 3px auto;'>More community impact</h4>
            <center class='loginPgContent content3' style='line-height:1.8em; padding:2px 20px; text-align:center; color:#232323;'>
                               You get to know about and thus be more informed on your neighbors or community's hidden challenges to offer a discreet help or contribute more to the development of your community.
            </center>
                <center>
                <button type='button' id='regBtn2' style='color:#fff; font-size:20px; background:#f41515; padding:15px 20px; border:0px; margin:60px 30px;' class='btn-sm' onclick=$('.loginPanel').slideDown(200)>
                  Sign Up
                </button>
            </center>
     
            <h4 class='subHeading2' style='color:#656565; text-align:center; margin:40px auto 3px auto;'>Privacy/Dignity</h4>
            <center class='loginPgContent content4' style='line-height:1.8em; padding:2px 20px; text-align:center; color:#232323;'>
                Privacy protection is non-negotiable to Xkroll. Your privacy is kept while outsourcing your request on your behalf unless you specify otherwise.
            </center>
   
            <h4 class='subHeading2' style='color:#656565; text-align:center; margin:40px auto 3px auto;'>
                Loss retrieval
            </h4>
            <center class='loginPgContent content5' style='line-height:1.8em; padding:2px 20px; text-align:center; color:#232323;'>
                               If you lose any valuable item, all you need to do is report here and relax while Xkroll retrieves it for you.
            </center>
            <br>

        </div>
        

         <center>
                <button type='button' id='regBtn22' style='color:#fff; font-size:20px; background:#f41515; padding:15px 20px; border:0px; margin:30px;' class='btn-sm' onclick=$('.loginPanel').slideDown(200)>
                  Join Xkroll
                </button>
            </center>

  <button type='button' onclick=$('#request_fm').show()>
                  Open
                </button>
  <button type='button' onclick=go()>
                  check Script
                </button><!-- animation-name: animateflash;
animation-duration: 3s;-->
               <div class='flex'> <div class='flash' style='width:100px; height:100px; border:1px solid red;'></div></div>
           
          </div>
          <br>
        <div style='background:#000; color:#fff; padding:10px;' class='footer-list'>
        <div style='display:flex; flex-direction:column; align-items:space-beween; justify-content:space-beween; margin:20px;'>
            <div>
              <a href='index.php' style='color:#fff; text-decoration:none; margin-top:10px;'>Home</a>
            </div>
            <div style='margin-top:10px;'>
              <a href=# style='color:#fff; text-decoration:none;' onclick=$('.about').show()>About</a>
            </div>
            <div style='margin-top:10px;'>
              <a href='policy.php' style='color:#fff; text-decoration:none;'>Policies</a>
            </div>
            <div style='margin-top:10px;'>
              <a href='terms.php' style='color:#fff; text-decoration:none;'>T&C</a>
            </div>
            <div style='margin-top:10px;'>
              <a href=# style='color:#fff; text-decoration:none;'>FAQ's</a>
            </div>
          </div>
          <div>
            <p style='text-align:center;'>
                mail@Xkroll.com
            </p>
            <center><footer style='color:#fff; font-size:12px;'>
              &copy  ".date('Y')." Xkroll Final=".$final_word."
            </footer></center>
          </div>
        </div>


<div class='loginPanel' style='display:none; margin-bottom:20%; overflow:scroll; filter: drop-shadow(2px 2px 3px #232); position:fixed; border-left:1px solid #ccc; top:0px; right:0px; width:80%; height:100%; padding:20px; background-color:white; z-index:1;'>
          <label onclick=$('.loginPanel').slideUp(500) style='text-align:left; color:black; font-size:20px;'>&times</label>
          <div style='display:flex; justify-content:center; align-self:center;'>
            <img src='img/helpmee.png' alt='Xkroll logo' style='height:35px; width:30px; margin:50px auto auto auto;' />
            </div>
            <p style='font-weight:bold; text-align:center; font-size:18px; color:black'>Not yet a member?</p>
            <form method='post'>
              <input type='text' style='padding-left:5px' title='email' class='sm' placeholder='Your Email' name='mail' id='mail'>
                <button type='button' class='btn-default sm'>REGISTER</button>
            </form>
            <p style='padding-left:10px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-facebook sm'></i>&nbsp;&nbsp;Sign in with Facebook
            </p>
            <p style='padding-left:10px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-google sm'></i>&nbsp;&nbsp;Sign in with Google
            </p>
            <p style='padding-left:10px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-twitter sm'></i>&nbsp;&nbsp;Sign in with Twitter
            </p>
            <p style='color:#aaa; font-size:12px'>
              By clicking on Sign in/REGISTER you agree to Xkroll <a href='terms.php'>Terms of use</a> and <a href='policy.php'>Privacy policy</a>.
            </p>
            <br>
            <p style='color:black; font-size:16px'>
              You are already a member? <a href=# onclick=$('#loginForm').show()>SIGN IN</a>
            </p>
            <div>
              <form method='post' id='login_data'>
                <input type='hidden' name='lat' id='lat'>
                <input type='hidden' name='lng' id='lng'>
                <input type='text' title='username' name='uname' id='uname' placeholder='Email' class='form-control' /><br>
              
<input type='password' title='password' name='pwd' id='pwd' placeholder='Password' class='form-control' /><br>
                <input type='submit' name='login' value='Login' class='btn'><br>
              </form>
            </div>
        </div>
      </div>


        <div id='request_fm' class='modal fade' tabindex='-1' role='dialog' aria-hidden='true'><br>
          <div class='modal-dialog' role='document'>
            <div class='modal-content'>
              <div class='modal-header addId collapse' onclick=$('#request_fm').fadeOut(-500) data-dismiss='modal' style='text-align:right'>
                <span class='close md'><strong>&times</strong></span>
              </div>
              <div class='modal-body'>HIIIII";
//        $page.=require_once('includes/requestFm.inc.php');
               
$page.="               </div>
            </div>
          </div>
        </div>

      </article>
    </main>  
    <script src='index.js'></script>
   </body>
</html>";
echo $page;