<?php
$usersView = new usersView();
$usersContr = new usersContr();

$user = $usersView->fetchUser();
$uid = $user[0]['profile_id'];
  
//$uid = $_SESSION['user_id'];//usersView::USERID;

//capture audio for storage
  $aud_input=$_FILES['audio_data']['tmp_name'];
  $aud_output=$_FILES['audio_data']['name'];
  if(!empty($aud_output)){
   // $aud_output == 1 ? $aud_tag ='H' : ($aud_output == 2 ? $aud_tag = 'L' : $aud_tag='T');

$aud_output == 1 ? $folder ='Loss' : ($aud_output == 2 ? $folder = 'Theft' : $folder='Request');

    	$target=$uid.substr($folder, 0, 1).time();
      move_uploaded_file($aud_input, 'sounds/'.$folder.'/'.$target.".webm");
    //check if previous note was used
      $row = $usersView->select('profile', ' WHERE profile_id = ?', $uid);
      $prev_aud=$row[0]['tmp_aud'];

      //choosing the right table to check
      $aud_output == 1? $table ='donation' : ($aud_output== 2 ? $table='stolen_asset' : $table == 'found_asset');
      $aud_output == 3 ? $recipientColumn = 'proof' : $recipientColumn = 'description';
      $row2 = $usersView->select($table, ' WHERE '.$recipientColumn.' = ?', $prev_aud);
   
      if(count($row2)==0){
    	 //unlink unused audio from folder
    	 @unlink('sounds/'.$folder.'/'.$prev_aud.'.wav');
      }
    //update profile
      $vals = $target.', '.$uid;
      //var_dump($vals);
      $usersContr->update('profile', 'tmp_aud = ? WHERE profile_id = ?', $vals);

  }else{return 'Your voice recording failed to upload, please try again!';}