<?php

return "<div style='padding:20px; margin-bottom:10px;'>
<form id='distress_data' method='post'>
    <div id='cdcontainer' onclick='countDown(300)' style='display:none;'>
        <div style='position:fixed; z-index:10; padding:5px; margin-right:20%; margin-left:20%; background:#eee; color:#000; width:50%; font-weight:bold; border-radius:5px; font-size:14px; text-align:center; border:1px inset #999;' id='countSecs'>
        </div>
    </div>
<h2 style='text-align:center; margin:10px auto 40px auto; font-weight:bold;'>Distress call settings</h2>
				<div class='form-group' style='display:flex-column;'>
                    <div class='col-sm-12'>
                       <label for='image-clue' style='font-weight:bold;'>Image clue*</label>
                    </div>
                    <div class='col-sm-12'>
                        <div style='display:flex;'>
                            <input type='file' style='width:60%;' name='image-clue' id='image-clue' multiple camera class='fileinput' value='' />
                            <div style='background:#eee; font-size:12px; border-radius:5px; padding:10px;'><i class='fa fa-info'></i> Images (e.g of a potential threat) related to your impending distress call
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
				<div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Comment*</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                        <textarea placeholder='Clue or comment relating to the likely impending distress call?' name='comment' required id='comment' class='form-control col-sm-12' value='' style='font-size:14px;'></textarea>
                        
                     </div>
                </div>
                <hr>
                <div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Distress recepient contacts*</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                     <div style='display:flex column'>
                        <input type='tel' required placeholder='Family 1' name='contactF1' id='contactF1' class='form-control col-sm-4' value=''>
                        <span id='check_contactF1'></span>
                     </div>
                     <div style='display:flex column'>
                        <input type='tel' placeholder='Family 2' name='contactF2' required id='contactF2' class='form-control col-sm-4' value='' style='margin-left:2px;'/>
                        	<span id='check_contactF2'></span>
                    
                     </div>   
                    </div>
                </div>
                <div class='form-group'>
                     <div class='col-sm-12' style='display:flex;'>
                      <div style='display:flex column'>
                       <input type='tel' placeholder='Friend 1' name='contactFr1' required id='contactFr1' class='form-control col-sm-4' value=''>
                    	<span id='check_contactFr1'></span>
                    	</div>
                    	<div style='display:flex column'>
                        <input type='tel' placeholder='Friend 2' name='contactFr2' required id='contactFr2' class='form-control col-sm-4' value='' style='margin-left:2px;'/>
                    	<span id='check_contactFr2'></span>
                    	</div>
                        
                    </div>
                </div>
                <div class='form-group'>
                     <div class='col-sm-12' style='display:flex;'>
                     	<div style='display:flex column'>
                        <input type='tel' placeholder='Neighbor 1' name='contactS1' required id='contactS1' class='form-control col-sm-4' value=''>
                    	<span id='check_contactS1'></span>
                    	</div>
                    	<div style='display:flex column'>
                        <input type='tel' placeholder='Neighbor 2' name='contactS2' required id='contactS2' class='form-control col-sm-4' value='' style='margin-left:2px;'/>
                       	<span id='check_contactS2'></span>
                    	</div>
                     
                    </div>
                </div>
                <div class='form-group'>
                     <div class='col-sm-12' style='display:flex;'>
                       	<div style='display:flex column'>
                    	<input type='tel' placeholder='security 1' name='contactN1' required id='contactN1' class='form-control col-sm-4' value=''>
                    	<span id='check_contactN1'></span>
                    	</div>
  						<div style='display:flex column'>
                         <input type='tel' placeholder='Security 2' name='contactN2' required id='contactN2' class='form-control col-sm-4' value='' style='margin-left:2px;'/>
                     	<span id='check_contactN2'></span>
                    	</div>
                        
                    </div>
                </div>
                <hr>
                <div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Distress Autolaunch timer<i style='color:#2196f3; font-size:12px;'> (optional)</i></label>
                    </div>
                    <div class='col-sm-12' style='display:flex;'>
                           <input id='autolaunch' type='radio' style='width:20px; height:20px;'>
                       <label for='autolaunch' style='margin-left:10px; margin-right:20px; font-size:16px;' onclick=$('#distressTimerSpan').show();>&nbsp;&nbsp;Autolaunch</label>
                        <span id='distressTimerSpan' style='display:none;'><input type='datetime-local' name='date' id='distressTimer' value='' style='font-size:16px; width:40vw;'/><br><span style='color:red'>set time</span>
                        </span>
                    </div>
                </div><br>
                <div class='form-group'>
                    <div class='col-sm-12'>
                      <button class='btn btn-default theme hover' style='font-size:20px;'>Update settings</button>
                    </div><br><br>

                </div>
</form></div>";