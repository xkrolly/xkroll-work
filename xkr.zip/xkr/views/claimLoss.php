<?php
/*include('../includes/autoloader.inc.php');
$usersView = new usersView();
*/if(isset($_POST['found_id'])){
  $found_id = $_POST['found_id'];
  $o_city = $_POST['city'];

/*$usersView->select('found_asset', ' WHERE found_id=?', $found_id);
$o_city
*/  $claim="<div id='verifyFm'><form class='form-horizontal' role='form' enctype='multipart/form-data' accept='image/jpg, image/gif, image/png' method='post' id='verify_data' style='z-index:21'>
                        <h6 style='text-align:center'>Where in ".$o_city."?</h6>
                    <input class='form-control' type='text' name='c-area' placeholder='Area' required
                        pattern='^(?=.{2,})(([a-z])*([A-Z])*)*$'
                    title='Input must be only text characters, with neither space nor hyphen character.'/>
                       <input class='form-control' type='text' name='c-street' placeholder='Street' required
                       pattern='^(?=.{2,})(([a-z])*([A-Z])*)*$'
                       title='Input must be only text characters, with neither space nor hyphen character.' />
                                <button type='submit' name='check' class='btn'/>Verify</button>
                              <input type='hidden' name='found_id' value='".$found_id."' />
                       </form></div>";
   
 return $claim;     
}
//return "Hello World";