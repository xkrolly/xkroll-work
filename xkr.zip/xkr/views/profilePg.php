<?php
    $timestamp=$row[0]['birthdate'];
    $n_assist=$row[0]['n_assist'];
    $db_cii=$row[0]['cii'];
    $profile_id = $row[0]['profile_id'];

    $userData = $this->select('skyman_user', ' WHERE user_id = ?', $profile_id);
    $joinDate = $userData[0]['join_date'];  
//$ccii = $this->ciBar($n_assist);
$ccii = $this->ciBar($db_cii);
$cil = $this->CiL($db_cii, $joinDate);

$years = $this->numOfYears($timestamp);
$row[0]['gender']=='m' ? $gender='Male':($row[0]['gender']=='f'?$gender='Female':$gender='Custom');
$_user = $this->fetchUser();
$user = $_user[0]['profile_id'];

$row2 = $this->select('skyman_user', ' WHERE user_id=?', $user);
$timestamp=$row2[0]['date_edit'];
$fullname = $row[0]['firstname']." ".$row[0]['lastname'];
   $initial=strtoupper(substr($row[0]['firstname'], 0,1).substr($row[0]['lastname'], 0,1));
    
$img_style="flex:1; z-index:2; width:6.5em; height: 6.5em; background: white; display:flex; align-items: center; justify-content: center; text-decoration: none; border-radius: 50%; border:2px solid #ccc; color:#999; font-size: 13px; opacity:1; margin-top:-50%; margin-right:auto;";
$header_style="flex:1; width:100%; height:80px; background: white; display:flex; align-items: center; justify-content: center; border-top-right-radius:10px; border-top-left-radius:5px; text-decoration: none; color:#999; font-size: 13px; opacity:1; font-family:calligraphy;";


    /*$imgEmpty="<div style='".$img_style."'>
                  <div style='display:flex;'>
                        <div style='width:100px; height:100px; background:#f01e6b; border-radius:50%; color:#fff; font-size:30px; font-weight:bold; display:flex; align-self:center; justify-content:center;'>
                              $initial  
                        </div>
                  </div>
                </div>"; */
 $imgEmpty="<div class='imgProf' style='margin-top:-50%;'>$initial</div>";
    $headerEmpty="<div style='".$header_style."; border:1px solid #ccc;'><strong> Upload Header Image </strong></div>";
  
    $img="<img src='".usersView::PROFILE.$row[0]['picture'].".webp' id='myprofpic' alt='profile picture' style='".$img_style."'>";
$header=$row[0]['headerImg'];
    $headerImg="<div>
                  <img src='".usersView::HEADER.$header.".webp' alt='header image' style='".$header_style."'>
                </div>";
        empty($row[0]['picture']) ? $img=$imgEmpty : $img=$img;
        empty($header) ? $headerImg=$headerEmpty : $headerImg;
//<div class='viewWidth' style='display:flex; flex-direction:column;'>
$page="<div style='position:fixed; top:0px; width:100%; margin-bottom:10px; padding-top:10px; background:#fff;'>
          <form id='' class='search_data' method='post'>
            <input type='hidden' name='searchType' id='searchType' value='2'>
            <div style='display:flex; margin-bottom:10px; padding-right:20px;'>
              <button type='submit' name='submit' class='' id='search_btn' style='margin-left:20px; background:#fff; border:1px solid #ccc; border-right:transparent; flex:1; border-top-left-radius:5px; border-bottom-left-radius:5px; padding:6px;'><i class='fa fa-search' style='font-size:1em; color:#ccc;'></i></button>
              <input type='search' name='input' id='input' placeholder='Search profile...' style='flex:8; padding:6px; font-size:1em; border:1px solid #ccc; border-left:transparent; border-top-right-radius:5px; border-bottom-right-radius:5px;'/>
            </div>
          </form>
          <div id='profilePg'>
            <div class='hideMe' style=''>
              $headerImg
            </div>
            <div class='hideMe' style='display:flex;'>
              <div style='justify-content:left; padding-left:30px; filter:drop-shadow(1px 1px 1px #eee);'>
                $img
              </div>
              <div style='display:flex; flex-direction:column;'>
                <div style='display:flex; flex:1; font-size:16px; font-family:sans-serif; font-weight:bold; margin-left:10px; color:#333;'>".strtoupper($fullname)."
                </div>
                <div style='display:flex; flex-direction:column; margin-left:10px;'>
                  $ccii
                  <div style='font-size:10px; color:#aaa;'>Cum. Community Impact
                  </div>
                </div>
                <div style='display:flex; flex-direction:column; margin-left:10px; margin-top:-7px;'>
                    <div>
                      $cil
                    </div>
                </div>

              </div>
              <div style='display:flex; margin-left:auto; align-self:bottom; margin-top:10px; margin-right:10px;' onClick='displayProfileMenu()' id='menuBar' class='menuBar'>
                <div style='background:#555; width:4px; height:4px;'></div>
                <div style='background:#555; width:4px; height:4px; margin-left:4px;'></div>
                <div style='background:#555; width:4px; height:4px; margin-left:4px;'></div>
              </div>
            </div>
            <div style='width:100%; background:#ddd; margin-top:10px; height:1px;'>
            </div>
            <div style='display:flex; justify-content:space-around; font-size:16px; color:#555;'>
                <div id='reqHx'>Request</div>
                <div id='rptHx'>Report</div>            
                <div id='rtnHx'>Return</div>
                <div id='userAssets' >Xkrolly</div>
            </div>
          </div>
        </div>
        <div style='background:#ececec; width:100%; padding-bottom:50px;'> 
          <div id='req' style='width:100%; font-size:16px; color:#555; margin-top:90px; min-height:100vh;'>";
foreach ($Rquests as $rquest) {
              $i=$rquest['donation_id'];
              $rquest['hAcesd']==1 ? $bdColor="green" : $bdColor="#fcfcfc";

$page.='    <div style="display:flex; font-style:italic; font-family:sans-serif; margin-left:10px; padding:0px; background:#eee; clear:both;">

              <div class="truncate" style="font-weight:bold; background:#eee;">'.$rquest['item'].'</strong>
              </div>
              <div  style="padding-right:5%; margin-left:auto;"> '.$this->time($rquest['d_date']).'
              </div>
            </div> 
            <div style="border:2px solid #fff; width:100%;"></div>';
}
$page.=" <br><br><br><br><br><br>
        </div>
          <div style='width:100%; font-size:16px; color:#555; background:#ececec; margin-top:85px;'>
          <div id='rpt' style='display:none; min-height:100vh;'>";
          if(count($Rpts)==0){
            $page.="<div style='display:flex; justify-content:center; align-items:center; font-family:sans-serif; font-size:25px; font-weight:bold;'>No report made yet!</div>";
          }else{
foreach ($Rpts as $rpt) {
              $i=$rpt['lst_id'];
  //            $rpt['hAcesd']==1 ? $bdColor="green" : $bdColor="#fcfcfc";
              
$page.='  <div style="display:flex; margin-left:20px; margin-right:20px; font-style:italic; font-family:sans-serif; padding:0px; background:#eee;">
            <div class="truncate"><strong>'.$rpt['ppt'].'</strong>
            </div>
            <div style="margin-left:auto;"> '.$this->time($rpt['reporting_date']).'
            </div>
          </div> 
          <div style="border:2px solid #fff; width:100%;"></div>';
}}
$page.="</div></div>
          <div style='padding-bottom:50px; width:100%; font-size:16px; color:#555; background:#ececec;'>
           <div id='rtn' style='display:none;; min-height:100vh;'>";
          if(count($Rtns)==0){
            $page.="<div style='display:flex; justify-content:center; align-self:center; font-family:sans-serif; font-size:25px; font-weight:bold'>No return made yet!</div>";
          }else{

foreach ($Rtns as $rtn) {
              $i=$rtn['found_id'];
$page.='  <div style="display:flex; margin-left:20px; margin-right:20px; font-style:italic; font-family:sans-serif; background:#eee;">
            <div class="truncate"><strong>'.$rtn['ppt'].'</strong>
            </div>
            <div style="margin-left:auto;"> '.$this->time($rtn['reporting_date']).'
            </div>
          </div>
          <div style="border:2px solid #fff; width:100%;"></div>';
}}
$page.="</div></div>

        <div style='width:100%; font-size:16px; color:#555; margin-top:-50px;'>
           <div id='assetsList' style='display:none;'>";
/*          if(count($DonList)==0){
            $page.="<div style='display:flex; justify-content:center; align-self:center; font-family:sans-serif; font-size:25px; font-weight:bold'>No Assets Listed!</div>";
          }else{
*/
$page.='<div style="text-align:center; padding:10px; margin:10px;">
<div  style="font-family:sans-serif;">

<div style="display:flex;"><h4 style="margin-left:auto; margin-right:auto;">Resource Pool</h4></div>
<form id="addFDI_data" method="post">
        <div style="display:flex; margin-bottom:10px; width:100%;">
            <select id="giftList" name="giftList" style="padding:5px; border-right:transparent; border-left:transparent; border:1px solid #ccc; font-size:1em; border-top-left-radius:5px; border-bottom-left-radius:5px;">
            <option>add to donate</option>
          <optgroup label="Movies">
            <option value="1">Add movies</option>
          </optgroup>
          <optgroup label="Foodstuff">
            <option value="2">Rice</option>
            <option value="3">Beans</option>
            <option value="4">Yam</option>
          </optgroup>
          <optgroup label="Utilities">
            <option value="5">Fuel(petrol)</option>
            <option value="6">Cooking gas</option>
          </optgroup>
          <optgroup label="Home app.">
            <option value="7">Pres. Iron</option>
            <option value="8">Elect. Fan</option>
            <option value="9">Air con</option>
            <option value="10">Cooking cyl</option>
            <option value="11">Microwave</option>
          </optgroup>
          <optgroup label="Bill">
            <option value="12">Tuition</option>
            <option value="13">Rental</option>
          </optgroup>
          <optgroup label="Books">
            <option value="14">Textbook</option>
            <option value="15">Novels</option>
          </optgroup>
          <optgroup label="Others">
            <option value="16">Others</option>
          </optgroup>
          </select>
          <div id="fileupload"></div>
            <input inputmode="numeric" id="qNum" name="qNum" max="20" min="1" placeholder="Qtty" style="width:30%; background:#eee; font-size:1em; padding:6px; border:1px solid #ccc;"/>
            <select id="uom" name="uom" style="background:#eee; font-size:1em; padding:6px; border:1px solid #ccc;">
                  <option value="1">Pieces</option>
                  <option value="2">Plate</option>
                  <option value="3">Cup</option>
                  <option value="4">Congo</option>
                  <option value="5">Bag</option>
                  <option value="6">Litres</option>
                  <option value="7">KG</option>
                  <option value="8">Tonne</option>
            </select>
          <button type="submit" name="submit" class="" id="search_btn" style="margin-left:0px; background:#fff; border:1px solid #ccc; border-left:transparent; flex:1; padding:6px; border-top-right-radius:5px; border-bottom-right-radius:5px;"><i class="fa fa-arrow-right" style="font-size:1em; color:#ccc;"></i></button>
        </div>
            <span id="check_qtty"></span>
            <span id="check_uom"></span>
            <span id="check_giftList"></span>
      </form>
      
      
       </div>
            <div style="text-align:left; margin-top:50px; height:110vh; font-size:18px;">';

$row3 = $this->select('donlist', ' WHERE donor=?', $user);

if(count($row3)==0){$page.='<div>Kindly donate by adding to the list below.</div>';}else{
$all_movies =explode('..', $row3[0]["item_list"]);

$page.='<details>
            <summary>Movies</summary>
                <ul style="">';
         if($row3[0]['item_code'] == 8){
            foreach ($all_movies as $row) {
            $page.='<li>'.$row.'</li>';
            }
          }
$page.="  </ul>
    
        </details>";
/*$userData = $this->fetchUser();
$uid = $userData[0]['profile_id'];*/
$valF = $user.', 5, '.$user.', 6, '.$user.', 7';
//
$rFood = $this->select('donlist', ' WHERE donor = ? AND item_code=? OR donor=? AND item_code = ? OR donor=? AND item_code = ?', $valF);

$page.='              <details>
                <summary>Food
                </summary>
                <ul style="">';
            foreach ($rFood as $food) {
              $food['item_code'] == 7 ? $uom = 'pieces' : $uom = 'Congoes';
            $page.='<li>'.$food["item_list"].'  <i style="color:#ccc; font-size:12px; font-family:cursive;">~ '.$food["qtty"].' '.$uom.'</i></li>';
            }
$page.="  </ul>
        </details>";
$page.='              <details>
                <summary>Home Appliances
                </summary>
                <ul style="">';
         
$valH = '1, 2, 3, 4';
$rHome = $this->select('donlist', ' WHERE item_code=? OR item_code = ? OR item_code = ? OR item_code = ?', $valH);

         foreach ($rHome as $homeApp) {
            $page.='<li>'.$homeApp["item_list"].'  <i style="color:#ccc; font-size:12px; font-family:cursive;">~ '.$homeApp["qtty"].' pieces</i></li>';
            }
$page.='    </ul>
              </details>
              <details>
                <summary>Others
                </summary>
                <ul style="">
                  <li>+ items</li>
                </ul>
              </details>
              </div>
            </div>';
//}
}
$page.='</div>
    
        <div id="search_results" style="position:fixed; top:10%; padding:10px; width:100%; background:transparent;"></div>
  </div></div>';

  return $page;