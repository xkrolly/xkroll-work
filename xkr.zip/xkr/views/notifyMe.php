<?php
include('../includes/autoloader.inc.php');

$usersView = new usersView();
if(isset($_GET['getNote'])){
$userData = $usersView->fetchUser();
$user_id = $userData[0]['profile_id'];
	$vals = $user_id.', 0';
	 $notes = $usersView->select('xnote', ' WHERE user_id=? AND iview=?', $vals);
$totalNew='';
$nSound='';
$notifier='';
//var_dump($notes);
if(count($notes)>0){
	 $n=count($notes);
 	echo json_encode(array("totalNew" => $n));
 }
}