<?php
return"   <form method='post' id='inspect_data' role='form'>
              <input type='hidden' id='global' name='global'>
              <h5 class='text-center' style='color:#444; font-weight:bold;'>Inspect/Verify</h5><br>
              <div style='display:flex; padding:25px;'>
            <input type='text' autofocus name='vin' id='vin' maxlength='40' style='width:70%; padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-top-left-radius:30px; border-bottom-left-radius:30px;' title='VIN' class='' placeholder='enter Bike or Vehicle VIN'>
                <button type='submit' class='btn-default sm theme' style='padding:10px; border-top-right-radius:30px; border-bottom-right-radius:30px; width:30%;'>Inspect</button>
                </div>
            </form><br>";