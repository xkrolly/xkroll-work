<?php
$lst_id = $_POST['lid'];
//include('includes/autoloader.inc.php');

$usersView = new usersView();
$lostData = $usersView->select('lst_item', ' WHERE lst_id=?', $lst_id);
$loser_id = $lostData[0]['user_id'];
$lost_item = $lostData[0]['ppt'];

$userData = $usersView->fetchUser();
$user_id = $userData[0]['profile_id'];

$form ="";

if($loser_id != $user_id){
$form .="
<div style='align-items:center; justify-content:center; padding-top:40px; margin-bottom:500px;'>
            <form method='POST' class='form-horizontal rptFm' role='form' id='retrieval_data' style='border-radius:10px; padding-top:0px;'>
        <h2 style='text-align:center; text-shadow: 1.5px 1.5px #999;'>Add Location</h2>
            <div style='padding:15px;'>         
              <div style='display:flex-column;'>
                <div class='form-group'>
                    <div class='col-sm-12'>
                        <label for='cityy' style='font-weight:bold;'>City*</label>
                    </div>
                    <div class='col-sm-12'>
                	    <input type='text' id='cityy' name='cityy' class='col-sm-12'>
                    </div>
                    <span id='check_cityy'></span>
                  </div>
                </div>
                
                <div class='form-group'>
                  <div style='display:flex-column;'>
                    <div class='col-sm-12'>
                        <label for='tel' style='font-weight:bold;'>Contact*</label>
                    </div>
                    <div class='col-sm-12'>
                    	<input type='tel' name='tel' class='col-sm-12' id='tel'/>
                    </div>
                    <span id='check_tel'></span>
                  </div>
                </div>
                <div class='form-group' style='margin-bottom:25px;'>
                    <div style='display:flex-column; margin-top:10px;'>
                        <div class='col-sm-12'>
                            <label style='font-weight:bold;'>Item image*</label>
                        </div>
                        <div class='col-sm-12'>
                            <div style='display:flex;'>
                               <input type='file' name='file' class='fileinput' multiple  style='width:60%;' capture='environment' accept='image/*'/ id='file'>
                                <div style='border-radius:10px; padding:10px 10px 10px 20px; font-size:12px; background:#ccc; color:#000; text-align:left;'><i class='fa fa-info' style='margin-right:5px;'></i> Upload front, rear & sides pictures of the property.<span style='color:red;'> (Required)</span>
                                </div>
                            </div>
                        </div>
                        <span id='check_file'></span>
                    </div>            
                </div>
                
 				<div class='form-group'>
                    <div class='col-sm-12' style=''>
                    	<input type='submit' class='btn theme opfem' style='font-size:20px;' name='submit'/>
                    	<input type='hidden' name='lid' value='".$lst_id."'/>
                    </div>
                </div><br><br><br>

            </form>
</div></div>";
}else{
    $form.="<p style='color:red; font-size:20px; text-align:center; margin-top:5%; padding:20px;'><span style='background:#fff; padding:10px; border-radius:5px; display:block;'>Sorry, you have found your ".$lost_item."?</span></p>";
}
return $form;