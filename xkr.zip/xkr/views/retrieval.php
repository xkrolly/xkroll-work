<?php
echo 'I am okay';