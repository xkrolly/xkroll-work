<?php

return "
        <form method='post' id='completeReg_data' class='homeWidth'>
        <div style='display:flex; justify-content:center; margin-bottom:20px;'>
            <div id='c1' style='background:#2196f3; width:15px; height:15px; border-radius:50%;'></div>
            <div id='b1' style='background:#eee; height:5px; width:20px; margin-left:2px; margin-right:2px; align-self:center;'></div>
            <div id='c2' style='background:#eee; width:15px; height:15px; border-radius:50%;'></div>
            <div id='b2' style='background:#eee; height:5px; width:20px; margin-left:2px; margin-right:2px; align-self:center;'></div>
            <div id='c3' style='background:#eee; width:15px; height:15px; border-radius:50%;'></div>
        </div>
            <div id='completeRegFmDiv1'>
                <h5 style='margin-bottom:10px;'>Your login details</h5>
    			<div style='display:flex column; text-align:left;'>
                    <div class='form-group'>
                            <div class='col-sm-12'>
                            <input class='form-control em' type='text' name='un' id='un' maxlength='10' placeholder='username e.g. Rodex' value='' required pattern='^(?=.{2,10})(([a-z])*([A-Z])*)*$'
                            title='Input must be only text characters and 10 max.'/>
                            </div>
                    </div>
                    <div class='form-group'>
                            <div class='col-sm-12'>
                            <input class='form-control em' type='password' name='pw' id='pw' placeholder='Choose 8-12 characters Password' value='' required autocomplete='off' placeholder='' pattern='^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$' title='Password must be 8 or more characters with at
least one number, an upper case letter, and one special character'/>
                            </div>
                    </div>
                    <div class='form-group'>
                            <div class='col-sm-12'>
                            <input class='form-control em' type='password' name='pw2' id='pw2' placeholder='Retype Password' value='' required />
                            </div>
                    </div>
                        <div class='col-sm-12 text-center'>
                            <button class='btn btn-default' id='saveLoginData'>Proceed</button>
                        </div>
                </div>
            </div>

            <div style='display:none;' id='completeRegFmDiv2'>
                   
            <h5 style='margin-bottom:10px;'>Your details</h5>
            <div style='display:flex column; text-align:left;'>
                <div class='form-group'>
                        <div class='col-sm-12'>
                        <input class='form-control em' type='text' name='fn' id='fn' placeholder='firstname' value='' required pattern='^(?=.{2,})(([a-z])*([A-Z])*)*$'
                        title='Input must be only text characters, with neither space nor hyphen character.'/>

                        </div>
                        
                </div>
                <div class='form-group'>
                        <div class='col-sm-12'>
                        <input class='form-control em' type='text' name='sn' id='sn' placeholder='Surname' value='' required pattern='^(?=.{2,})(([a-z])*([A-Z])*)*$'
                        title='Input must be only text characters, with neither space nor hyphen character.'/>

                        </div>
                        
                </div>
                <div class='form-group'>
                        <div class='col-sm-12'>
                        <input class='form-control em' type='text' name='contact' id='contact' value='' placeholder='Whatsapp contact' required/>
                        </div>
                        
                </div>

                    <div class='col-sm-12 text-center'>
                        <button class='btn btn-default' id='saveLoginData2'>Proceed
                        </button>
                        <input type='hidden' name='username' id='username' value=''/>
                        <input type='hidden' name='passphrase' id='passphrase' value=''/>
                    </div>
                </div> 
            </div>
             <div style='display:none;' id='completeRegFmDiv3'>
                   
            <h5 style='margin-bottom:15px;'>Your Detail</h5>
                <div id='regDetail' style='text-align:left; padding-left:30px;'>
                </div>
                            <span id='check__username'></span>
                            <span id='check__passphrase'></span>
                            <span id='check__firstname'></span>
                            <span id='check__lastname'></span>
                            <span id='check__contact'></span>

                <div class='form-group'>
                    <div style='display:flex;'>
                        <div class='col-sm-12'>
                            <button id='cancelRegFm'><<</button>
                        </div>
                        <div class='col-sm-12'>
                            <button class='btn btn-default' name='submit' id='submit'>Submit</button>
                            <input type='hidden' name='_username' id='_username' value=''>
                            <input type='hidden' name='_passphrase' id='_passphrase' value=''>
                            <input type='hidden' name='_firstname' id='_firstname' value=''>
                            <input type='hidden' name='_lastname' id='_lastname' value=''>
                            <input type='hidden' name='_contact' id='_contact' value=''>
                    
                         </div>
                   </div>    
                </div>
             </div>
        </form>";