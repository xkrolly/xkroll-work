<?php

$profile = new usersView();
return $profile->profile_page();