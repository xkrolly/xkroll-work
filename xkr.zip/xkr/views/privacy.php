<?php
$privacy= "<table width='100%' id='form'><tr><td width='15%' class='cell'></td><td width='70%' class='form'>".
      "<dl>".
      "<h3>Privacy Policies</h3>".
      "<hr/>".
      "<p>TraC<sup>&reg;</sup> Privacy Policies</p>".
      "<ul>".
        "<li>Your Identity remains confidential with us.</li>".
        "<li>Filing a false theft report may end you up into getting banned, and may attract police charges and harassment.
            If by chance you mistakenly file a non-genuine report, you are required to delete it via our <a href='prb_list.php'>report a problem</a> link
            at the bottom of each of your pages immediately before any inspection is carried out on it by anybody out there so as to prevent unnecessary police scenes.</li>".
        "<li>You are liable to report any extortion from any agent likewise you will be held guilty of extortion if you extort as regards the returning of lost or stolen properties.</li>".
        "<li>Extortion is requesting for rewards or compensations from the lost or stolen property owners beyond our stipulated limits.</li>".
        "<li>All cases of Extortions should be reported first to the Law Enforcement Agencies around you, and secondly to us via our <a href='rpt-problem.php'>Report a Problem</a> link at the bottom of every page.</li>".
        "<li>When meeting with any agent in order to retrieve your lost or stolen properties, bear in mind that you are meeting a completely unknown person that may be a potential security threat to you. Handle it smartly and wisely. You may as well inform the Law Enforcement Agency prior to checking out if so desired or the need arises.</li>".
        "<li>If you provide an intel, your identity is safe with us, unknown to anybody.</li>".
        "<li></li>".
      "</ul>".
      
     "</td><td width=15% class='cell'></td></tr>".
     "<tr><td width=15% class='cell'></td><td class='back'><a href='../index.php?page=home'>&lt; &lt; Back Home</a></td><td width=15% class='cell'></td></tr></table>";
echo $privacy;