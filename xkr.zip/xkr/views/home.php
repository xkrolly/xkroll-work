<?php
 $home = new usersView();
 return $home->showFeed();