<?php
return "<p style='font-size:25px; position:fixed; top:40%; right:10%;'>All losses appear here</p>";