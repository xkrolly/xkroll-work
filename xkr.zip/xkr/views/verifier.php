<?php
  $id=$_POST['fid'];


  $verifier = "<div style='width:100vw; padding:20px;'>
                 <form method='post' id='verify_data'>
                 <input type='hidden' name='lid' value='".$id."'>
                    <div class='form-group'>
                        <div class='col-sm-12'>
                            <label for='city' style='font-weight:bold;'>City where it was lost?* ".$id."</label>
                        </div>
                        <div class='col-sm-12'>
                    	   <input type='text' name='city' class='col-sm-12' placeholder='City' style='font-size:16px;'  pattern='^(?=.{2,})(([a-z])*([A-Z])*)*$' title='Input must be only text characters, with neither space nor special character.'/><br>
                        </div>
                    </div>
                    <div class='form-group'>
                        <div class='col-sm-12'>
                            <button type='submit' name='check' class='btn theme'>Verify</button>
                        </div>
                    </div>
                </form>
                </div>";
return $verifier;