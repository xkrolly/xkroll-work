<?php

include('../includes/autoloader.inc.php');
$usersContr = new usersContr();
$usersView = new usersView();

$lat = $_POST['lat'];
$lng = $_POST['lng'];
var_dump($lat);
if(!empty($lat) && !empty($lng) && $lat!=0 && $lng!=0){
	$_SESSION['loadNewsFeed'] = true;
	$vals = $lat.', '.$lng.', '.$_SESSION['user_id'];
   	$usersContr->update('profile', 'lat=?, lng=? WHERE profile_id = ?', $vals);
}else{	$_SESSION['loadNewsFeed'] = false;
//$_SESSION['geoloc_switch_query']=1;
}
