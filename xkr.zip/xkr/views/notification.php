<?php

 $notification = new usersView();
 return $notification->notePg();
