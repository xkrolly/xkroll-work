<?php

 $srch = new usersView();
//$ouput = new usersContr();
 
 return $srch->srchPg();
//$outputs=$usersView->fetchSrch('naira', 'ibadan');
