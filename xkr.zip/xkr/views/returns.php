<?php

	$home = new usersView();
	return $home->rtnPg();
