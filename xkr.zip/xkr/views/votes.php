<?php

include('../includes/autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();

if(isset($_POST['donation_id'])){
    $don_id=$_POST['donation_id'];
    //$callType=$_POST['callType'];
    
    $userData = $usersView->fetchUser();
    $user = $userData[0]['profile_id'];
    $myvote=$_POST['vote'];
    $vals=$user." ".$don_id;

    $vData = $usersView->select('voter', ' WHERE user_id = ? AND donation_id = ?', $vals);
    $dData = $usersView->select('donation', ' WHERE donation_id = ?', $don_id);

  if(count($vData)==0){
      $_empathy = $dData[0]['empathy'];
      $_ban = $dData[0]['nonreal'];
      $_played = $dData[0]['played'];
      $empathy = $_empathy + 1;
      $ban = $_ban + 1;
      $played = $_played + 1;
      $_POST['update']=TRUE;

      $myvote == 1 ?
      $updVals = $empathy.', '.$played.', '.$don_id :
      $updVals = $ban.', '.$played.', '.$don_id;

      $myvote == 1 ?
      $placeHolder = 'empathy = ?' :
      $placeHolder = 'nonreal = ?';
      
      $usersContr->update('donation', $placeHolder . ', played =? WHERE donation_id = ?', $updVals);

      //record the franchise as used
      $v2Data = array("user_id"=>$user, "donation_id"=>$don_id, "vote"=>$myvote, "cancelled"=>0);
      $usersContr->setVote('voter', $v2Data);

      if($_POST['update']==TRUE){
        $_POST['vote']==1? $btnPressed='btn_emp' :  $btnPressed='btn_ban';
        $callType != 2 ? $btnPressed = 'btn_likes' : $btnPressed;
        $usersContr->updUserActivity($user, $btnPressed);
  
        $row = $usersView->select('donation', ' WHERE donation_id = ?', $don_id);

        $emp=$row[0]['empathy']; $ban=$row[0]['nonreal']; $did=$row[0]['donation_id'];
        echo json_encode(array("upd_emp" => $emp, "upd_ban" =>$ban, "id"=>$did));
        }
    }
    else{

      $ban=$dData[0]['nonreal']; 
      $emp=$dData[0]['empathy'];     
      $vals = $don_id.' '.$user;

      $v2Data = $usersView->select('voter', ' WHERE donation_id = ? AND user_id = ?', $vals);
//      var_dump($v2Data);
      $preVote=$v2Data[0]['vote'];
      $cancelled=$v2Data[0]['cancelled'];
      $_POST['update']=TRUE;

      if($_POST['vote']!=$preVote){
        $_POST['update']=TRUE;
        $myvote=$_POST['vote']; 
         
//  START BELOW
        $emp = $dData[0]['empathy'] + 1;
        $emp > 1 ? $cancel_Emp = $dData[0]['empathy'] - 1 :
        $cancel_Emp = 0;

        $ban = $dData[0]['nonreal'] + 1;
        
        $ban > 1 ? 
        $cancel_Ban = $dData[0]['nonreal'] - 1 : 
        $cancel_Ban = 0;

        $myvote == 1 ? 
        $newVoteVals= $emp.', '.$cancel_Ban.', '.$don_id :
        $newVoteVals= $cancel_Emp.', '.$ban.', '.$don_id;
    
// This is to prevent getting negative values
        $usersContr->update('donation', 'empathy = ?, nonreal = ? WHERE donation_id = ?', $newVoteVals);
 
        $VoterData = $myvote.', 0, '.$user.', '.$don_id;
        $usersContr->update('voter', 'vote = ?, cancelled = ? WHERE user_id = ? AND donation_id = ?', $VoterData);

        if($_POST['update']==TRUE){
          $_POST['vote']==1? $subj='btn_emp' :  $subj='btn_ban';
          $usersContr->userActivity($subj, $user);
          $usersView->btnUpd($don_id);
          }
      }
      elseif($_POST['vote']==$preVote){
      // && $cancelled==0){ 
          $_POST['update']=TRUE;
          $emp = $dData[0]['empathy'];
          $emp > 0 ? $cancel_Emp = $emp - 1 : $cancel_Emp = 0;
      
          $ban = $dData[0]['nonreal'];
          $ban > 0 ? $cancel_Ban = $ban-1 : $cancel_Ban = 0;

          $myvote == 1 ? 
          $newVoteVals= $cancel_Emp.', '.$ban .', '.$don_id : 
          $newVoteVals= $emp.', '.$cancel_Ban .', '.$don_id;

    // This is to prevent getting negative values
          $usersContr->update('donation', 'empathy = ?, nonreal = ? WHERE donation_id = ?', $newVoteVals);

          $VoteVals = '0, '.$user.', '.$don_id;
          $usersContr->update('voter', 'vote = ? WHERE user_id = ? AND donation_id = ?', $VoteVals);

          $_POST['vote']==1? $btnPressed='btn_emp' :  
          $btnPressed='btn_ban';
          $usersContr->userActivity($btnPressed, $user);
          $usersView->btnUpd($don_id);
      }
   }
}