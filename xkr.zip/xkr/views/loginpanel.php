<?php

echo "<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en' dir='ltr'>
  <head>
    <title>Xkroll: Seek help, share vital info or alert people nearby</title>
        <meta http-equiv='Content-Type' content='text/html' charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
    <meta http-equiv='x-ua-compatible' content='ie=edge'>

</head><body>
<label onclick=$('.loginPanel').slideUp(500) style='text-align:left; color:black; font-size:20px;'>&times</label>
          <div style='display:flex; justify-content:center; align-self:center;'>
            <img src='img/helpmee.webP' alt='Xkroll logo' style='height:35px; width:30px; margin:50px auto auto auto;' />
           </div>
            <p style='font-weight:bold; text-align:center; font-size:18px; color:black'>Not yet a member?</p>
            <form method='post' id='signup_data' style='display:flex; margin-bottom:20px;'>
              <input type='text' style='width:65%; padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-top-left-radius:50px; border-bottom-left-radius:50px;' title='Mobile number' class='sm logininput' placeholder='Enter your mobile number' name='mobileNum' id='mobileNum'>
                <button type='submit' class='btn-default sm' style='padding:10px; border-top-right-radius:50px; border-bottom-right-radius:50px; width:35%;'>Register</button>
            </form>
            <div id='otpVerifyFm' style='margin:20px auto 20px auto;'></div>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-facebook sm'></i>&nbsp;&nbsp;Sign in with Facebook
            </p>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-google sm'></i>&nbsp;&nbsp;Sign in with Google
            </p>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-twitter sm'></i>&nbsp;&nbsp;Sign in with Twitter
            </p>
            <p style='color:#aaa; font-size:12px'>
              By clicking on Sign in/REGISTER you agree to Xkroll <a href='views/terms.php'>Terms of use</a> and <a href='views/terms.php'>Privacy policy</a>.
            </p>
            <br>
            <p style='color:black; font-size:16px'>
              You are already a member? <a href=# onclick=$('#loginForm').show()>SIGN IN</a>
            </p>
            <div>
              <form method='post' id='login_data' onclick='getMyLoc()' action='../includes/login.inc.php'>
                <input type='text' title='username' name='uname' id='uname' placeholder='Username or phone no.' style='padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-radius:50px; margin-top:10px; margin-bottom:-6px;'/>
                <p id='uname-input-check'></p><br>
              
<input type='password' title='password' name='pwd' id='pwd' placeholder='Password' class='form-control logininput' style='padding:10px; background:#ecf0f3; margin-bottom:-6px; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-radius:50px;'/>
<p id='pwd-input-check'></p><br>

                <input type='submit' name='login' id='loginbtn' value='Login' class='btn' style='padding:10px; border-radius:50px;'>
                  <input type='hidden' id='latd' name='latd' value=''>
                <input type='hidden' id='lngd' name='lngd' value=''>
            <br>
              </form>
            </div>
        </div>
        </body></html>";
//      </div>";