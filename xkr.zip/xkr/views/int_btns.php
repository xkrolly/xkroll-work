<?php

include('../includes/autoloader.inc.php');
$usersView = new usersView();
if(isset($_GET['getVote'])){
	$homeFeedArray = $usersView->homeFeed();

	$donations = array();
	if(count($homeFeedArray)>0){
//var_dump($homeFeedArray);
		foreach($homeFeedArray as $feed){
//var_dump($feed);

			array_push($donations, array('d' => $feed['donation_id'], 'l' => $feed['empathy'], 'p' => $feed['played'], 'h' => $feed['nonreal']));
		}
		echo json_encode(array("fds" => $donations));
	}
}