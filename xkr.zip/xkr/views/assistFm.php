<?php
return "<form id='".$i."assistForm' method='post' style='font-size:18px;'>
              <input type='hidden' name='i' id='i' value='".$i."'>
              <input type='hidden' name='".$i."don_id' id='".$i."don_id' value='".$did."'>
              <input type='hidden' name='".$i."item' id='".$i."item' value='".$item."'>
              <input type='hidden' name='assistId' class='assistId' value='".$i."'>
                <div style='margin-top:-5px; margin-bottom:10px; text-align:center;'>
                	<label style='font-size:25px;'><strong>".$item."</strong></label>
                </div>
              <div class='chosenContact'>
                <div>".$addContact."</div>
                 <div>
                  <div style='display:flex;'>
                  <input style='padding:10px; width:65%; background:#ecf0f3; border-top-left-radius:50px; border-bottom-left-radius:50px;' type='tel' name='helperContact' id='helperContact' class='sm helper_tel helperContact collapse' placeholder='Your active Contact' required/>  
                  <input type='submit' value='Send' style='padding:10px; width:35%; border-top-right-radius:50px; border-bottom-right-radius:50px;' class='btn_default assistForm helper_tel collapse sm assist' name='submit' id='".$i."channel1' />
                  </div>
                  <span id='check_".$i."channel1'></span>
			          </div>
                <div class='chatMedium collapse text-center'>
                  <a href='https://wa.me/".$chatContact."?text=".rawurldecode($assistNote)."' class='optwem hover assistForm assist'  id='".$i."channel2' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic'>
                    <i class='fab fa-whatsapp assist' style='font-size:50px'></i>
                  </a>&nbsp;&nbsp; Or &nbsp;&nbsp;
                  <a href=\"{$assistNote}\" style='text-decoration:none' class='optwem hover assistForm'  id='".$i."channel3' style='text-decoration:none; color:#454545; font-family:lucida; text-decoration:italic'>
                    <i class='fab fa-telegram assist' style='font-size:50px; color:#2166f3'></i>
                  </a>
                </div>
              </div>
              <div>
                <div class='assistMedium' style='display:flex column; text-align:left;'>
                  <a class='optwem hover' style='color:#000; text-decoration:none margin-bottom:40px;'>
                    <div class='sendContact flex-center'>
                      <div style='margin-right:25px;'>
                              <span class='ovalBackground'>
                                  <i class='fa fa-paper-plane' style='font-size:20px;'></i>
                              </span>
                      </div>
                      <div style='display:flex column;'>
                        <div>Send your contact</div>
                       <div style='font-style:italic; font-size:13px; color:#aaa;'>Let the needy call you</div>

                      </div>
                    </div>
                  </a><br>
                  <a class='optwem hover' style='color:#000; text-decoration:none'>
                    <div class='chatUp flex-center'>
                      <div style='margin-right:25px;'>
                        <span class='ovalBackground'>
                          <i class='fa fa-comments' style='font-size:20px;'></i>
                        </span>
                      </div>
                      <div style='display:flex column;'>
                        <div>Chat the needy up</div>
                        <div style='font-style:italic; font-size:13px; color:#aaa;'>Communicate by chat
                        </div>
                      </div>
                    </div>
                  </a><br>
                  <a href='tel:".$ndyContact."' name='ndyContact' id='".$i."channel4' class='optwem hover assistForm' style='color:#000; text-decoration:none'>
                      <div class='call flex-center'>
                        <div style='margin-right:25px;'>
                        <span class='ovalBackground'>
                          <i class='fa fa-phone' style='font-size:20px;'></i>
                        </span>
                      </div>
                      <div style='display:flex column;'>
                        <div>Place a call now</div>
                        <div style='font-style:italic; font-size:13px; color:#aaa;'>Call the needy contact
                        </div>
                      </div>
                    </div>
                  </a>
            </div>
              </div>
            </form>";
