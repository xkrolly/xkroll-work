<?php
include('autoloader.inc.php');

$usersView = new usersView();
$usersContr = new usersContr();

//select distress call located around this user
		$query="SELECT * FROM distress WHERE lat BETWEEN $this->lat - 0.05 AND $this->lat + 0.05 AND lng BETWEEN  $this->lng - 0.05 AND $this->lng + 0.05 AND distress_date < DATE_SUB(now(), interval 30 MINUTE)";
	 	$stmt = $this->connect()->query($query);
	while($rowDs = $stmt->fetch()){
		

	}
	 	
