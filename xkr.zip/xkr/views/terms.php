<?php
$terms="
<div style='padding:40px; font-family:sans-serif; font-size:13px; text-align:justify;'>
    <h1 style=''>Xkroll terms</h1>
    <div style='line-height:25px; word-spacing:3px;'>
            <h4>Xkroll purpose</h4>
            <p>Xkroll is a platform for quick intra-neighborhood communication for the purpose of seeking urgent help, disseminating vital info or neighborhood security alert and many more. The following are Xkroll policies.</p><br>
            <h4>Retrieval policy</h4>
            <p>You agree to pay 20% of the market worth of the item you lost to the finder as compensation if the finder requests it.</p> 
            <p>In a situation where it is difficult to ascertain the monetary worth of a property, such as certificates, you are liable to pay an amount equivalent to 5 US Dollar at the time. In the case of extortion such as requesting higher than the stipulated charge from you by the finder of your lost property, you report the case to Xkroll Admin immediately via your Xkroll account.</p>
                <p>If any security threat is perceived before, during or after Xkroll induced meeting between you and another Xkrollite, Xkroll is not in anyway responsible for it, you are liable to take care of it by beckoning to your nearest law enforcement agent(s) as deems fit.</p><br>
                <p>On the other hand, you agree to collect 5% max. of the market worth of the property you find from the owner at the time you give it back.</p>
                <p>Finder of your lost item/property is not in anyway responsible for damage to your lost property, if the damage occurs before or during the time it is under finder's custody or while giving it back to you.</p>
                <p>Finder of your lost item/property is not in anyway liable to be suspected or made guilty of theft or be shamed if the property/item they found is a stolen property, unless there is a sufficient proof for their theft accusation.</p>
                <p>After you report online, You will normally get a message through your inbox notifying you of the discovery of your lost item/property.
                If you get no message after you have waited for a while, it might have not been found or it was wrongly reported by the finder,
                you are therefore expected to frequently check whether it has been found through Xkroll search.
                Claim it by providing the required information to get you the finder's contact in order to retrieve your item/property.
                </p>
                <p>The finder will also request a proof which you are required to provide in order to ascertain your true ownership of the item/property.
                </p>
                <p>You are however advised where necessary to report a case of property discovery to the police after online report through our platform.</p><br>
            <h4>Non-disclosure policy</h4>
            <p>
            You agree to not disclose about the help you render to anyone in need of it to any third party.
            It remains a secret between you and the needy unless you seek and are granted permission by the needy you helped to do so if duly needed. 
            If this is violated, you will be banned from using Xkroll as this is an outright violation of the main purpose of Xkroll.
            </p><br>
            <h4><i class='fa fa-exclamation-triangle opeem warning'></i>&nbsp;Warning !!!</h4>
                <p>When contacting the finder of your lost property, do it smartly and carefully and bear in mind that you are meeting
                a completely unknown person. Pay the compensation if requested. Report to law enforcement agent(s) as urgent as possible if any security threat is perceived.</p>
                <button style='padding:10px; font-size:20px;'><a href='login' style='text-decoration:none;'>&lt;&lt; Back</a></button>
        </div>";
echo $terms;