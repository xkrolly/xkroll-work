<?php
$now = time();
$global = "<div class='collapse unselected2 coverage' id='globalCoverage' style='text-align:center;'><span id='rangeValue' style='font-weight:bold; padding:2px;color:#ccc;'></span></div>";

$rangeMeter = "<div class='input-group input-group-sm hidden-sm-down unselected2 radiusCoverage' id='radiusCoverage' style='display:none; margin-top:20px; width:100%; border-radius:50px;'>
                      <div style='display:flex; border:1px solid #ccc; width:100%; border-radius:50px;'>
                      <input type='range' name='callRange' min='0' max='5000' value='' id='callRange' class='myRange form-control slider' style='color:#f01e6b; margin: auto 25px auto 25px;'>
                      <button type='submit' name='submit' tabindex=3 class='input-shadow' id='radiusCoverageCloser'  style='border:0; border-top-right-radius:50px; border-bottom-right-radius:50px; background:#fff;'><i class='fa fa-times fa-fw'></i></button>
                      </div>

                    </div><br>";

$fdi="<div id='addFDIspec' class='addFDIspec'></div>";
$text = "<div class='input-group input-group-sm hidden-sm-down unselected input' id='textProof' style='display:none; margin-bottom:20px; width:100%; border-radius:50px;'>
                      <textarea tabindex=1 class='form-control' name='proof' id='proof' maxlength='200' pattern='^(?=.{4,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$' title='Needys convincing story' placeholder='Describe the purpose...' style='color:blue; border:2px solid #ccc; font-size:16px; color:#f01e6b; height:60px; border-top-left-radius:10px; border-bottom-left-radius:10px;'></textarea>
                      <button type='button' name='submit' tabindex=3 id='textProofCloser' style='border:0; border-top-right-radius:10px; border-bottom-right-radius:10px; background:#ccc;'><i class='fa fa-times fa-fw'></i></button>
                    </div>";
                    $audio = "<div id='countDowntime3'></div>";
/*                $usersView =  new usersView();

                $audio = $usersView->voiceRec_CountDown();
*/return"     <form id='request_data' method='post' enctype='multipart/form-data' class='form-horizontal' role='form'>
            <input type='hidden' id='now' value='".$now."' name='now'>
            <input type='hidden' id='global' name='global'>
            <h5 class='text-center' style='color:#444; font-weight:bold;'>Xkroll call</h5><br>


                  <!-- <div class='form-group'>
                    <div>
                      <select onchange='FDIorNot($(this).val())' class='form-control input' title='Xkroll call type' id='xkroll_callType' name='xkroll_callType' style='background:#eff; color:#f01e6b;' >
                          <option value='' disabled>Select Call purpose:</option>
                          <option value=2>Request Help</option>
                          <option value=4>Inspect vehicles/motorcycles</option>

                          <option value=1 disabled>Alert Neighborhood</option>
                          <option value=3 disabled>FDI Giveaway</option>
                         
                      </select>
                  </div>
               </div>-->

                    <div>
                      <div class='opt-list' style='margin-top:-10px;'>
                     <input type='text' list='items' name='heading' id='heading' maxlength='25' style='font-size:16px; color:#f01e6b;' class='form-control input' required spellcheck='true' value='' placeholder='Your request...'/>
                     <span id='check_heading'></span>
                     <datalist id='items' class='datalist'>
                     </datalist>
                     </div>
                     $fdi
                     <div style='display:flex; flex-wrap:nowrap; margin:5px auto auto auto; color:#777; font-size:12px; display:flex; justify-content:flex-end;'>
                      

                     <div style='margin-right:auto;'>$global</div>
                     <div style='margin-right:20px;'><span style='font-size:16px;' class='material-icons unselectedCaller small_Icons'  onClick='startRec(10, 3);' id='audioProofCaller'>&#xe029</span>&nbsp;&nbsp;&nbsp;<span class='material-icons unselectedCaller small_Icons' id='textProofCaller' style='font-size:16px;'>&#xe873</span></div>
                     <div style='font-weight:bold; color:#ccc; font-size:16px;'>|</div>
                     <div style='margin-left:20px;'><span class='material-icons unselectedCaller2 small_Icons' id='radiusCoverageCaller' style='font-size:16px;'>&#xe569</span>&nbsp;&nbsp;&nbsp;<span class='material-icons unselectedCaller2 small_Icons' style='font-size:16px;' id='globalCoverageCaller'>&#xe80b</span></div>
                   </div>
                   </div>".
                   $rangeMeter.$text."<div id='countDowntime3'></div>
                        <div id='request_options' style='display:none; text-align:left;'> 
                        <ul style='text-align:left;'><li><label>Send as alert to: </label></li>
                        <label><input type='checkbox' name=''>&nbsp;&nbsp;&nbsp;Feed </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name=''>&nbsp;&nbsp;&nbsp;DM</label><br>
                        <li style='margin-bottom:20px;'><label>Dispersal radius:</label>&nbsp;&nbsp;&nbsp;
                        <input type='number' name='' min='3' max='10'></li></ul>
                        </div>
                   <div style='display:flex; align-items:flex-end;'>
                        <div class='far-left'>
                        <a href=# style='text-decoration:none; font-size:14px; font-style:italic; color:#303696;' onclick=$('#request_options').show()>More options...</a>
                        </div>
                        <div class='far-right'>
                           <button type='submit' name='submit' class='btn btn-default sm theme' style='border-radius:20px; padding:10px 25px;'>
                            Submit
                           </button>
                        </div>
                    </div>
            </form>";
            //<span style='font-size:18px; color:#fff; filter:drop-shadow(2px 2px 1px #ccc);' class='material-icons unselectedCaller' id='audioProofCaller'>&#xe7f4</span>&nbsp;&nbsp;&nbsp;