<?php
$area='agbowo'; $street='yidi';
$val=$area.' '.$street;
$uersView = new usersView();
$data= $uersView->select('found_asset', ' WHERE area = ? AND street = ?', $val);
return count($data);
//echo $data[0]['ppt'];
/*foreach($data as $d){
	echo $d['ppt'];
}*/
//$usersContr = new usersContr();

/*$data= $usersContr->update('found_asset', 'ppt = ? WHERE area = ?', 'Napooo agbw');
*/
//echo time(date_format()).'<br>';

echo date('D', time());
//echo date('M-d, Y', time());

/*$input = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y');
$t = array_chunk($input, 5);
$ln = floor(count($input)/5)-1;
$str = array();
while($ln >= 0){
	$str[] = $t[$ln][0].$t[$ln][1].$t[$ln][2].$t[$ln][3].$t[$ln][4].'&nbsp;';
	$ln--;
}
$str = implode($str);

echo $str;*/
/*


$data= $uersView->checkDb('found_asset', ' WHERE area = ? AND city= ?', 'iworoad ibadan');
echo $data[0]['ppt'];

//WORKING
	protected function ftch($tableName, $whereVal) {
		$whereVal = explode(' ', $whereVal);

		$sql="SELECT * FROM ".$tableName." WHERE area = ? AND city = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute($whereVal);
		$results = $stmt->fetchAll();
		return $results;
	}


*/
