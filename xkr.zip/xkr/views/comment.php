<?php

$discussId = $_GET['cid'];
$comm = new usersView();
return $comm->showComment($discussId);

