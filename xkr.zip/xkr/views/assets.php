<?php
//include('includes/autoloader.inc.php');
 $usersView = new usersView();
$myasset = "<div style='background:#fff; width:100vw; min-height:100vh; padding:20px;'>
			<button class='btn theme' onclick=$('#regassetFm').show();>Toggle list</button><br><br>
      <h6>My asset list</h6>
			<details>
                <summary>Vehicles
                </summary>
                <ul style=''>
                  <li>Cars</li>
                  <li>Bus</li>
                  <li>Truck</li>
                  <li>Lorry</li>
                  <li>Motorcycle</li>
                </ul>
              </details>
              <details>
                <summary>Electronics
                </summary>
                <ul style=''>
                  <li>Phone/Tablet</li>
                  <li>Tv sets</li>
                  <li>Air con</li>
                </ul>
              </details>";
    $x = 10;
    while($x > 0){
       $myasset.="<div style='display:flex;background:#eee; border-radius:10px; margin: 20px auto 20px auto;'>
                <div style='height:180px; width:55%; border:1px solid #ccc; background:#ccc; border-radius:10px;'>
                </div>
                <div style='height:180px; width:40%; border:1px solid #ccc; background:#fff; border-radius:10px; margin-left:20px;'>
                </div>
            </div>";
    $x--;
}
$myasset.= "</div>";

//$usersView->showModal('views/regassetFm.php', 'regassetFm', 'file');
return $myasset;