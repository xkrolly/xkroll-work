<?php

$usersView = new usersView();
$usersView->logout();