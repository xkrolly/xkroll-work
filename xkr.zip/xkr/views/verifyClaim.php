<?php
if(isset($_POST['found_id'])){
$claimLoss = new usersView();
  $found_id=$_POST['found_id'];
  $area_input = $_POST['area'];
  $street_input = $_POST['street'];

$checker = $claimLoss->select('found_asset', ' WHERE found_id=?' $found_id);
	$found_ppt = $checker['ppt'];
	$finder = $checker['user_id'];
	$finder_contact = $checker['contact'];
	$area = $checker['area'];
	$street = $checker['street'];

	$area_screened = $claimLoss->screenWord($area);
	$street_screened = $claimLoss->screenWord($street);
	$i_area_screened = $claimLoss->screenWord($area_input);
	$i_street_screened = $claimLoss->screenWord($street_input);

	$areaMatch = similar_text($area_screened, $i_area_screened);
	$streetMatch = similar_text($street_input, $i_street_screened);

	if(($areaMatch>0.6 && $streetMatch>0.6) || ($areaMatch+$streetMatch>1.2)){
		$response = "Congrats, you are the true owner. Call the finder on ".$finder_contact." to retrieve it.";
	}else{
		$response = "Sorry, this is not your property!";
	}
	echo json_encode(array('ajaxReply'=>$response));
	
}