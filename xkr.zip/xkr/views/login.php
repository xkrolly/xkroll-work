<?php
return"<div class='homepage' onclick='getMyLoc()'>
          <div class='bg-overlay'>
            <div onclick='getMyLoc()' style='margin-bottom:100px; display:flex; color:#fff; justify-content:center; align-items:center;'>
              <div>
                <img src='img/helpmee.webP' alt='xkroll logo' style='height:30px; width:30px;'/>
                <label style='font-family:sans-serif; font-size:25px;'>kroll</label>
              </div>
              
              <div style='margin-left:auto; display:flex column; padding: 5px; background:#fff; border:1px solid #444; width:50px; height:35px; color:#444; border-radius:5px; z-index:1;' onclick=$('.loginPanel').slideDown(200)>
                <div style='border:1px solid #444; margin:5px; height:1px; background:#444;'></div>
                <div style='border:1px solid #444; margin:5px; height:1px; background:#444;'></div>
                <div style='border:1px solid #444; margin:5px; height:1px; background:#444;'></div>
              </div>
            </div>
          
            <header style='font-family:sans-serif;'>
              <h1 style='color:#fff; font-size:35px; text-align:center; word-spacing:6px; line-height:45px;'>Need To Seek Nearby Help, Inform Or Alert Your Neighborhood In A Jiffy?
              </h1>
              <h2 style='text-align:center; font-weight:normal; line-height:1.6em; padding:10px 20px; word-spacing:5px; color:#ccc;'>
                Communicate with people nearby, disseminate urgent vital info or alert people locally and quickly about a potential threat, urgent needs for rescue or help wherever you are anytime, just with few clicks!
              </h2>
              <p style='text-align:center;' onclick='getMyLoc()'>
                <button type='button' style='color:#000; font-weight:bold; font-size:18px; font-family:sans-serif; background:#fff; border:0px; border-bottom:1px solid #ccc; padding:15px 20px; margin-top:30px;' class='btn-sm' tabindex='3' onclick=$('.loginPanel').slideDown(200)>
                  Get started with Xkroll
                </button>
              </p>
            </header>
          </div>
        </div>

      <div style='height:0; width:0; border-top:70px solid #f01e6b; border-right:100vw solid transparent;'></div>


        <div onclick='getMyLoc()'>
          <h3 class='subHeading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
          <span class='material-icons' style='font-size:60px; animation-name: animateflash; animation-duration: 3s;'>&#xe32a;</span><br>
          Security</h3>
            <p class='loginPgContent content1' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                It can offer protection against kidnapping, rapping etc.
            </p>
            
          <h3 class='subHeading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
          <span class='material-icons' style='font-size:60px; animation-name: animateflash; animation-duration: 3s;'>&#xe32a;</span><br>
          Ownership Verification</h3>
            <p class='loginPgContent content1' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                You can now perform ownership verification test on any fairly-used item prior to buying.
            </p>
            <h3 class='subheading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
            <span class='material-icons' style='font-size:60px; animation-name: animateflash; animation-duration: 3s;'>&#xe0c6;</span><br>
            Urgent help sourcing</h3>
            <p class='loginPgContent content2' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                You get nearby help anywhere, anytime you are in dire need of it.
            </p>

            <h3 class='subHeading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
          <span class='material-icons' style='font-size:60px;'>&#xe7fb;</span><br>
          Community impact</h3>
            <p class='loginPgContent content3' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                               You get to be more informed on your neighbors or community's hidden challenges to offer a discreet help or contribute more to the development of your community.
            </p>
            <p style='text-align:center;' onclick='getMyLoc()'>
                <button type='button' style='color:#fff; font-size:20px; background:#f01e6b; padding:15px 20px; border:0px; margin:60px 30px;' id='regBtn1' class='btn-sm' onclick=$('.loginPanel').slideDown(200)>
                  Sign Up
                </button>
            </p>
            <h3 class='subHeading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
          <span class='material-icons' style='font-size:60px;'>&#xea17;</span><br>
          Privacy/Dignity</h3>
            <p class='loginPgContent content4' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                Privacy protection is non-negotiable to Xkroll. Your privacy is kept while outsourcing your request on your behalf unless you specify otherwise.
            </p>
            <h3 class='subHeading2' style='color:#656565; text-align:center; font-size:25px; font-weight:bold; margin:60px auto 3px auto;'>
              <span class='material-icons' style='font-size:60px;'>&#xe860;</span><br>
              Loss retrieval
            </h3>
            <p class='loginPgContent content5' style='line-height:1.8em; padding:12px 20px; text-align:center; color:#232323;'>
                Just imagine the painful experience you had the last time you misplaced a valuable property. Xkroll can help you anytime in retrieval. Just report here and relax while Xkroll does the work.
            </p>
 
        <p style='text-align:center;' onclick='getMyLoc()'>
                <button type='button'  id='regBtn2' style='color:#fff; font-size:20px; background:#f01e6b; padding:15px 20px; border:0px; margin:30px;' class='btn-sm' onclick=$('.loginPanel').slideDown(200)>
                  <a href='views/loginpanel.php' style='color:#fff; text-decoration:none;'>Join Xkroll</a>
                </button>
            </p>
          </div>
          <br>

        <div style='background:#000; color:#fff; padding:10px;' class='footer-list'>
        <div style='display:flex; flex-direction:column; align-items:space-beween; justify-content:space-beween; margin:20px;'>
            <div>
              <a href='./' style='color:#fff; text-decoration:none; margin-top:10px;'>Home</a>
            </div>
            <div style='margin-top:10px;'>
              <a href='views/about.php' style='color:#fff; text-decoration:none;'>About</a>
            </div>
            <div style='margin-top:10px;'>
              <a href='views/privacy-policy.php' style='color:#fff; text-decoration:none;'>Privacy Policy</a>
            </div>
            <div style='margin-top:10px;'>
              <a href='views/terms.php' style='color:#fff; text-decoration:none;'>Terms</a>
            </div>
          </div>
          <div>
            <p style='text-align:center;'>
                admin@Xkroll.com
            </p>
            <footer style='text-align:center; color:#fff; font-size:12px;'>
                &copy  ".date('Y')." Xkroll
            </footer>
          </div>
        </div>
</div>

<div class='loginPanel' style='display:none; margin-bottom:20%; overflow:scroll; filter: drop-shadow(2px 2px 3px #232); position:fixed; border-left:1px solid #ccc; top:0px; right:0px; height:100%; padding:20px; background:#fff; z-index:1;'>
          <label onclick=$('.loginPanel').slideUp(500) style='text-align:left; color:black; font-size:20px;'>&times</label>
          <div style='display:flex; justify-content:center; align-self:center;'>
            <img src='img/helpmee.webP' alt='Xkroll logo' style='height:35px; width:30px; margin:50px auto auto auto;' />
            </div>
            <p style='font-weight:bold; text-align:center; font-size:18px; color:black'>Not yet a member?</p>
            <form method='post' id='signup_data' style='display:flex; margin-bottom:20px;'>
              <input type='text' style='width:65%; padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-top-left-radius:50px; border-bottom-left-radius:50px;' title='Mobile number' class='sm logininput' placeholder='Enter your mobile number' name='mobileNum' id='mobileNum'>
                <button type='submit' class='btn-default sm' style='padding:10px; border-top-right-radius:50px; border-bottom-right-radius:50px; width:35%;'>Register</button>
            </form>
            <div id='otpVerifyFm' style='margin:20px auto 20px auto;'></div>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-facebook sm'></i>&nbsp;&nbsp;Sign in with Facebook
            </p>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-google sm'></i>&nbsp;&nbsp;Sign in with Google
            </p>
            <p style='padding:5px; margin-bottom:10px; border-radius:50px; font-size:14px; color:black; border:1px solid #aaa'>
              <i class='fab fa-twitter sm'></i>&nbsp;&nbsp;Sign in with Twitter
            </p>
            <p style='color:#aaa; font-size:12px'>
              By clicking on Sign in/REGISTER you agree to Xkroll <a href='views/terms.php'>Terms of use</a> and <a href='views/terms.php'>Privacy policy</a>.
            </p>
            <br>
            <p style='color:black; font-size:16px'>
              You are already a member? <a href=# onclick=$('#loginForm').show()>SIGN IN</a>
            </p>
            <div>
              <form method='post' id='login_data' onclick='getMyLoc()'>
                <input type='text' title='username' name='uname' id='uname' placeholder='Username or phone no.' style='padding:10px; background:#ecf0f3; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-radius:50px; margin-top:10px; margin-bottom:-6px;'/>
                <p id='uname-input-check'></p><br>
              
<input type='password' title='password' name='pwd' id='pwd' placeholder='Password' class='form-control logininput' style='padding:10px; background:#ecf0f3; margin-bottom:-6px; box-shadow: inset 6px 6px 6px #cbced1, inset -6px -6px 6px white; border-radius:50px;'/>
<p id='pwd-input-check'></p><br>

                <input type='submit' name='login' id='loginbtn' value='Login' class='btn' style='padding:10px; border-radius:50px;'>
                  <input type='hidden' id='latd' name='latd' value=''>
                <input type='hidden' id='lngd' name='lngd' value=''>
            <br>
              </form>
            </div>
        </div>
      </div>";