<?php
$usersView = new usersView();
$usersContr = new usersContr();
$userData = $usersView->fetchUser();

$uid = $userData[0]['profile_id'];

//capture video for storage
  $vid_input=$_FILES['video_data']['tmp_name'];
  $vid_output=$_FILES['video_data']['name'];
  if(!empty($vid_output)){
//    echo ('video loaded');
  
$vid_output == 1 ? $folder ='distress' : $folder='others';

      $target=$uid.substr($folder, 0, 1).time();
      move_uploaded_file($vid_input, 'videos/'.$folder.'/'.$target.".webm");
    //check if previous note was used
      $row = $usersView->select('profile', ' WHERE profile_id = ?', $uid);
      
      $distress_recipients = $row[0]['dSignal_recipients'];
      $distress_video = $target;
      $sender_lat = $row[0]['lat'];
      $sender_lng = $row[0]['lng'];
      //var_dump($target);

      
        $data = array('sender_id'=>$uid, 'd_signal_recipient'=>$distress_recipients, 'd_video'=>$distress_video, 'lat'=>$sender_lat, 'lng'=>$sender_lng);
        $usersContr->insert('distress', $data);

        //get distress id 
        $vals = $distress_video;
        $rowD = $usersView->select('distress', ' WHERE d_video = ?', $vals);
        $distress_id = $rowD[0]['distress_id'];
      
      //get each recipient one by one;
        $each_recipient = explode('..', $distress_recipients);
        foreach($each_recipient as $recipient){
        //update recipient with notification //create distress table itself
            $vals = $recipient;
            $rowR = $usersView->select('profile', ' WHERE contact = ?', $vals);
            if(count($rowR)>0){
               $recipientId = $rowR[0]['profile_id'];

               $data = array('user_id'=>$recipientId, 'donation_id'=>1, 'found_id'=>1, 'distress_id'=>$distress_id, 'msg_id'=>11);
               $usersContr->insert('xnote', $data);
            }
        }
  
      /*//inbox those around the distress source*/

      $userData = $usersView->fetchUser();
      $lat1 = $userData[0]['lat'] - 0.05;
      $lng1 = $userData[0]['lng'] - 0.05;
      $lat2 = $userData[0]['lat'] + 0.05;
      $lng2 = $userData[0]['lng'] + 0.05;
      $distSenderId = $userData[0]['profile_id'];

      $vals = $lat1.', '.$lat2.', '.$lng1.', '.$lng2;

      $profile_datas = $usersView->select('profile', ' WHERE lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?', $vals);
      foreach ($profile_datas as $eachProfile) {

        $recipientId = $eachProfile['profile_id'];
          
        if($recipientId != $distSenderId){
            $data = array('user_id'=>$recipientId, 'donation_id'=>1, 'found_id'=>1, 'distress_id'=>$distress_id, 'msg_id'=>11);

           //check if user has not received such inbox
            $vals = $distress_id.', '.$recipientId;
            $checkBox = $usersView->select('xnote', ' WHERE distress_id = ? AND user_id = ?', $vals);
            if(count($checkBox) == 0){ $usersContr->insert('xnote', $data); }
        }
    }
    
/*END*/

      $prev_aud=$row[0]['dist_vid'];

      //choosing the right table to check
      $vid_output == 1? $table ='donation' : ($vid_output== 2 ? $table='stolen_asset' : $table == 'found_asset');
      $vid_output == 3 ? $recipientColumn = 'proof' : $recipientColumn = 'description';
      $row2 = $usersView->select($table, ' WHERE '.$recipientColumn.' = ?', $prev_aud);
   
      if(count($row2)==0){
       //unlink unused audio from folder
       @unlink('videos/'.$folder.'/'.$prev_aud.'.wav');
      }
    //update profile
      /*$vals = $target.', '.$uid;
      //var_dump($vals);
      $usersContr->update('profile', 'dist_vid = ? WHERE profile_id = ?', $vals);
*/

  }else{return 'Your voice recording failed to upload, please try again!';}