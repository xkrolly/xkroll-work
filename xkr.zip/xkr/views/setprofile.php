<?php

//include('../includes/autoloader.inc.php');
    
    $usersView = new usersView();
    $userData = $usersView->fetchUser();
//var_dump($userData[0]['show_profile']);
    $userData[0]['show_profile'] == 1 ? $checked = 'checked' : $checked = '';
    $userData[0]['show_profile'] == 1 ? $value = 0 : $value = 1;
return "<div style='padding:20px; margin-bottom:50px;'>
<form id='profile_data' method='post'>
<h4>Profile settings</h4><br>
				<div style='display:flex;'>
                     <div class='col-sm-6'>
                        <label style='font-weight:bold;'>Header Image</label>
                        <input type='file' name='imgH' id='imgH' multiple camera class='fileinput' value='' style='width:100%;'>
                        <span id='imgH'></span>
                    </div>
                     <div class='col-sm-6'>
                        <label style='font-weight:bold;'>Profile Image</label>
                        <input type='file' name='imgP' id='imgP' multiple camera class='fileinput' value='' style='width:100%;'>
                        <span id='imgP'></span>
                    </div>
                </div>
                <hr>
				<div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Gender</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                        <input type='radio' name='sex' value='g1'>&nbsp;Female &nbsp;&nbsp;&nbsp;<input type='radio' name='sex' value='g2'>&nbsp;Male

                     </div>
                </div>
                <hr>
                <div class='form-group'>
                     <div class='col-sm-12' style='display:flex;'>
                        <input type='checkbox' name='show-profile' value='".$value."' ".$checked.">&nbsp;Show profile image on feed
                     </div>
                </div>
                <hr>
				<div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Religion</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                        <input type='radio' name='religion' value='r1'>&nbsp;Christianity &nbsp;&nbsp;&nbsp;<input type='radio' name='religion' value='r2'>&nbsp;Islam
                         &nbsp;&nbsp;&nbsp;<input type='radio' name='religion' value='r3'>&nbsp;Traditional
                     </div>
                </div>

                <hr>
				<div class='form-group'>
                    <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Contact</label>
                    </div>
                     <div class='col-sm-12' style='display:flex;'>
                        <input type='text' class='form-control' name='contact' value=''>
                     </div>
                </div>
                <div class='col-sm-12'>
                <button class='btn btn-default theme form-control'>Update</button>
                </div>
</form></div><br><br>";