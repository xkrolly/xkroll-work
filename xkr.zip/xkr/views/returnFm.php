<?php

 $usersView = new usersView();
 $usersContr = new usersContr();
 $user=$usersView->fetchUser($_SESSION['user_id']);
 $regCompleted = $user[0]['regCompleted'];
// $contact=$user[0]['contact'];
//$audio = $usersView->voiceRec_countDown();

$rForm=$usersView->searchPanel();
$rForm .="
<div style='align-items:center; justify-content:center; padding-top:40px;'>
        <h4 style='text-align:center; text-shadow: 1.5px 1.5px #999;'>Lost and Found</h4>
            <form method='POST' class='form-horizontal rptFm' role='form' id='return_data' style='border-radius:10px; padding-top:0px;'>
            <div style='padding:15px;'>         
                  <div class='form-group'>
                    <div class='col-sm-12'>
                        <label for='report-type' style='font-weight:bold;'>Select*</label>
                    </div>
                    <div class='col-sm-12'>
                        <select class='form-control' required name='report-type' id='report-type' >
                            <option value=''>Select one</option>
                         <optgroup label='Report'>
                     
                            <option value='1'>Loss</option>
                            <option value='2'>Discovery</option>
                              <option value='3'>Theft (Stolen)</option>
                        </optgroup>
                        <optgroup label='Register'>
                            <option value='4'>Register assets</option>
                        </optgroup>
                        </select>
                        <span id='check_report-type'></span>
                    </div>
                </div>
                <div class='form-group propertyType' style='display:none;'>
                    <div class='col-sm-12'>
                       <label for='property' style='font-weight:bold;'>Property*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                    <select class='form-control property' name='property' id='property'>
                      <option value=''>Select property</option>
                      <optgroup label='Vehicle'>
                        <option value='1'>Car</option>
                        <option value='2'>Bus</option>
                        <option value='3'>Truck</option>
                      </optgroup>
                      <optgroup label='Motorcycle'>
                        <option value='4'>Bike</option>
                        <option value='5'>PowerBike</option>
                        </optgroup>
                     <optgroup label='Electronics'>
                        <option value='6'>Phones/tablets</option>
                        <option value='7'>TV sets</option>
                     </optgroup>
                     <optgroup label='Others'>
                        <option value='8'>Others</option>
                     </optgroup>
                    </select>
                    <span id='check_property'></span>
                    </div>
                </div>
                <div class='form-group item'>
                    <div class='col-sm-12'>
                        <label for='item' id='item_label' style='font-weight:bold;'>Item name*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                        <input type='text' placeholder='e.g. Wrist watch' name='item' id='item' spellcheck='true' class='form-control em typewriter-effect' required value='' max-length='30'>
                        <span id='check_item'></span>

                    </div>
                </div>
                <div class='form-group city' style='display:none;'>
                    <div class='col-sm-12'>
                        <label for='city' style='font-weight:bold;'>City*</label>
                    </div>
                
                    <div class='col-sm-12' style=''>
                        <input type='text' placeholder='e.g. Ibadan' name='city' id='city' class='form-control em' value=''>
                        <span id='check_city'></span>

                    </div>
                </div>
                <div class='form-group model' style='display:none;'>
                
                    <div class='col-sm-12' style='display:flex;'>
                        <div style='display:flex column' style='margin-right:2%;'>
                        <label for='make' style='font-weight:bold;'>Make</label>
                        <select class='form-control col-sm-6' placeholder='Make' style='width:90%;' name='make' id='make'>
                        <option value=''>Select</option>
                          <option>Tesla</option>
                          <option>Toyota</option>
                          <option>Mercedes</option>
                          <option>Peugeot</option>
                        </select>
                            <span id='check_make'></span>
                        </div>
                        <div style='display:flex column' style='margin-right:2%;'>
                        <label for='model' style='font-weight:bold;'>Model</label>
                        <input type='text' class='form-control col-sm-6' placeholder='Model' style='width:90%;' name='model' id='model'>
                            <span id='check_model'></span>
                        </div>
                        <div style='display:flex column'>
                        <label for='color' style='font-weight:bold;'>Color</label>
                        <input type='color' value='' class='form-control chasisCol' style='width:50px; padding:2px;' name='color' id='color'>
                        <span id='check_color'></span>
                        </div>
                        
                    </div>
                </div>

                <div class='form-group vins' style='display:none;'>
                    <div class='col-sm-12'>
                             <label for='engine-number' style='font-weight:bold;'>VINs</label>
                    </div>    
                    <div class='col-sm-12' style='display:flex;'>
                      <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Engine num...' style='width:95%;' name='engine-number' id='engine-number'>
                        <span id='check_engine-number'></span>
                        </div>
                        <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Chassis num...' style='width:95%; margin-right:2%;' name='chassis-number' id='chassis-number'>
                          <span id='check_chassis-number'></span>
                        </div>

                      <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Num. plate...' style='width:95%; margin-right:2%;' name='number-plate' id='number-plate'>
                        <span id='check_number-plate'></span>
                        </div>

                    </div>
                </div>
                <div class='form-group desc'>
                    <div style='display:flex-column; margin-top:10px;'>
                        
                        <div class='col-sm-12'>
                            <label style='font-weight:bold;'>Describe item*</label>
                        </div>
                        <div class='col-sm-12'>
                            <div style='display:flex;'>
                                <div style='display:flex; align-items:flex-start;'><button onClick='startRec(5, 1);' class='hover' id='startRecBtn' style='background:transparent; border:0px; padding:15px; border:1px solid #fff; border-radius:10px; filter:drop-shadow(1px 2px 1px #aaa); background:#fff; margin-right:10px; padding-left:15px;'><i class='fa fa-microphone hover'></i>
                                    </button>
                                    </div>
                                    <div id='countDowntime1' style='color:red; margin:10px; display:flex; align-items:flex-start;'></div>

                                    <div style='border-radius:10px; padding:10px; font-size:12px; background:#ddd; color:black; text-align:left; margin-left:20px;'><i class='fa fa-info' style='margin-right:5px;'></i><span id='pptDesc'>Describe the unique features of the property succintly(e.g make, model, scratch, dent, texture, color, decoration etc.)</span> in 20s.<span style='color:red;'> (Required)</span>
                                    </div>
                            </div>
                        </div>
                            <span id='check_voicerec'></span>
                    </div>
                </div>
                <div class='form-group img' style='display:none; margin-bottom:25px;'>
                    <div style='display:flex-column; margin-top:10px;'>
                        <div class='col-sm-12'>
                            <label style='font-weight:bold;'>Item image</label>
                        </div>
                        <div class='col-sm-12'>
                            <div style='display:flex;'>
                                <div style='border-radius:10px; padding:6px 6px 6px 10px; font-size:12px; background:#ddd; color:#000; text-align:left;'><i class='fa fa-info' style='margin-right:5px;'></i> <span id='pptImg'>Upload 6 pictures consisting of front, rear, side, engine number and unique exterior(e.g scratch, dent, crack) pictures of the property.</span><span style='color:red;'> (Required)</span>
                                </div>
                                <input type='file' name='file' class='fileinput' multiple  style='width:60%;' capture='environment' accept='image/*'/ id='property-image'>
                               
                            </div>
                        </div>
                        <span id='check_property-image'></span>
                    </div>            
                </div>
                
                <div class='form-group'>
                    <div class='col-sm-12'>
                            <button type='submit' name='proceed' class='btn btn-default em hover theme' id='reportBtn' style='padding:10px 15px 10px 15px; font-size:16px;'>Report</button>
                             <input type='hidden' value='' name='myaudio' id='myaudio'>
                  
                    </div>
                </div><br><br><br>
            </form>
        </div></div>";
/* if($regCompleted=='0'){$rForm.=$usersView->showModal('includes/completeReg.inc.php', 'completeReg', 'file');
}
*/       
return $rForm;