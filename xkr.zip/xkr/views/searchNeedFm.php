<?php
return'   
    <form method="post" id="" class="search_data">
     <input type="hidden" name="searchType" id="searchType" value="4">
        <div style="display:flex column; align-items:center; margin:5px;">
            <div style="display:flex; font-size:20px; border:1px solid #aaa; border-radius:10px; margin-bottom:25px; padding-right:4px;">
              <button type="submit" name="submit" tabindex=3 class="" id="search_btn" style="width:10vw; background:#fff; border:transparent; border-top-left-radius:15px; border-bottom-left-radius:15px; padding:6px;">
                  <strong>
                  		<i class="fa fa-search" style="font-size:16px;"></i>
                 </strong>
              </button>
              <input type="search" incremental name="input" placeholder="Search urgent needs..." aria-label="Search the pool of resources nearby for your urgent needs" style="padding:6px; font-size:16px; width:60vw; border:transparent;" id="srchNeedFm" />
            </div>
             <ul style="font-weight:bold; margin-left:-20px; font-size:12px; margin-top:-10px;">
             <li>NOTE: Your CILs determines your chances.</li>
             </ul> 
        </div>
    </form>';