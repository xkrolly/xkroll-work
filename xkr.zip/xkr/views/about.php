<?php
$about_us="

			<div style='height:0; width:0; border-top:200px solid #f01e6b; border-right:99vw solid transparent;'></div>
			<div style='line-height:35px; word-spacing:3px;
padding:25px; font-family:sans-serif; font-size:13px;'>";
$about_us.="<h1 style='text-align:center;'>About us</h1>
		<p>Xkroll is an intra-neighborhood communication platform. Our services include nearby needs/help search, neighborhood alert for urgent rescue in a security challenge, loss retrieval etc.</p>

		<p>We are dedicated to helping people in dire situation by making available for them a network of nearby help which they can tap on for quick relief.</p>

		<p style='margin-bottom:100px;'>All our services are rendered via our mobile application and website(https://xkroll.com)</p>

		<h4>Our Vision</h4>
		<p>To accumulate, disseminate/share location-based intelligence and other vital information such as urgent needs/help request from people locally for life and property safety and security.</p>

		<p style='margin-bottom:100px;'>We intend to achieve this vision by ensuring a progressive and consistent effort towards enhancing a rapid/urgent communication amidst people closely located for many purposes including sourcing dire needs/help and creating a network of intelligence gathering for human and property safety and security.</p>

		<h4>Our Mission</h4>
		<p>To create more empathetic and secure environment for human lives and properties.</p>

		<p>To stimulate human empathy more towards improving and securing lives in order to enhance a more social and empathetic way of living.</p>
	</div>";
//return 
echo $about_us;