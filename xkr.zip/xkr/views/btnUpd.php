<?php
//required by votes.php
$row = $usersView->select('donation', ' WHERE donation_id = ?', $don_id);
$emp=$row[0]['empathy']; $ban=$row[0]['nonreal']; $did=$row[0]['donation_id'];
          echo json_encode(array("upd_emp" => $emp, "upd_ban" =>$ban, "cancelled"=>$cancelled, "id"=>$did));