<?php
		$rows= $this->fetchUser($_SESSION['user_id']);
$set=$rows[0]['media_setin'];
$set==1 ? $checked1='checked' : $checked1='';
$set==2 ? $checked2='checked' : $checked2='';
$set==3 ? $checked3='checked' : $checked3='';
$set==4 ? $checked4='checked' : $checked4='';
$set==5 ? $checked5='checked' : $checked5='';

$media_auto=$rows[0]['media_auto'];
$media_auto==1 ? $checkMed='checked' : $checkMed='';
$block=$rows[0]['blocked'];
$block=="'0'" ? $checked_b='checked' : $checked_b='';
$mailNote=$rows[0]['mailNote'];
$mailNote==1 ? $checked_m='checked' : $checked_m='';
$dm=$rows[0]['dm'];
$dm==1? $color='#fff' : $color='black';
$dm==1? $bgcolor='#232323' : $bgcolor='#fff';

$other_setins=$rows[0]['other_setins'];
$_aud_req=1;  $_useDefaultKm=2;
similar_text($_aud_req, $other_setins, $perc);
$perc > 0 ? $aud_req='checked' : $aud_req='';
similar_text($_useDefaultKm, $other_setins, $perc2);
$perc2 > 0 ? $useDefaultKm='checked' : $useDefaultKm='';

$prof_setin=$rows[0]['prof_setin'].'abcde';
$num=strlen($prof_setin);

$def_range=$rows[0]['def_range'];

$f=substr($prof_setin, 0, 1);
$s=substr($prof_setin, 1, 1);
$t=substr($prof_setin, 2, 1);
$fo=substr($prof_setin, 3, 1);
$ff=substr($prof_setin, 4, 1);
($f==1 || $s==1 || $t==1 || $fo==1 || $ff==1) ? $c_img='checked' : $c_img='';
($f==2 || $s==2 || $t==2 || $fo==2 || $ff==2) ? $c_pinfo='checked' : $c_pinfo='';
($f==3 || $s==3 || $t==3 || $fo==3 || $ff==3) ? $c_adr='checked' : $c_adr='';
($f==4 || $s==4 || $t==4 || $fo==4 || $ff==4) ? $c_contact='checked' : $c_contact='';
($f==5 || $s==5 || $t==5 || $fo==5 || $ff==5) ? $c_media='checked' : $c_media='';

$settings="<br><div style='margin:2px 10px 50px 10px;' id='setinPg'>
      <h3 class='text-center' style='color:#2196f3; font-weight:bold;'>Settings</h3>
               
            <form method='post' id='settingFm'>
               <h4 style='color:white; background-color:#aaa; margin-bottom:5px;'>Mode</h4>
                <fieldset style='border:0px'>
                         <legend>Light/ Dark mode</legend>
                          <div class='switches2'>
                                  <label class='switch2'>
                                    <input type='checkbox' data-on='good' data-off='bad' value='bad'>
                                    <span class='slider2 round2' id='toggle3'>
                                      <span class='off2'>Norm</span>
                                      <span class='on2'>Dark</span>
                                    </span>
                                  </label>
                              </div>
                  </fieldset><br>
            	          <h4 style='color:white; background-color:#aaa; margin-bottom:5px;'>Newsfeeds</h4>
                 <fieldset style='border:0px'>
                  	    <legend>Media inclusion</legend>
            	    	    		<input type='radio' name='media' id='media' value='1' $checked1 >
                            <label for='image'>Image only</label><br>
      							<input type='radio' name='media' value='2' id='media2' $checked2>
                    <label for='video'>Video only</label><br>
            	    	   <input type='radio' name='media' value='3' id='media3' $checked3>                            <label for='audio'>Audio only</label><br>
    	    		<input type='radio' name='media' value='4' id='media4' $checked4>
              <label for='imageAndVideo'>Image & Video only</label><br>				
 						<input type='radio' name='media' id='media5' $checked5 value='5' onclick=$('#vd').val('true')>
            <label for='all'>All media</label>
   	    	 </fieldset>
           <fieldset style='border:0px;'>
           	      <legend>Media control</legend>
                            <input type='checkbox' name='autoMed' id='autoMed' value='1' $checkMed>&nbsp;&nbsp;&nbsp;Autoplay audio and video
            </fieldset>";

if($block!="'0'"){ $settings.="<fieldset style='border:0px'><legend>Feeds filter</legend>
                            <input type='checkbox' name='unblock' id='unblock' value='1' $checked_b>&nbsp;&nbsp;&nbsp;Unblock all previously blocked
                        </fieldset>";}
 $settings.="<br><h4 style='color:white; background-color:#aaa; margin-bottom:5px;'>Profile</h4>
                 <fieldset style='border:0px;'>
                        <legend>Publishable profile</legend>
                            <input type='checkbox' name='img' id='img' value='1' $c_img><label>Profile image & CCII score</label><br> 
                            <input type='checkbox' name='pinfo' id='pinfo' value='2' $c_pinfo><label>Personal Info</label><br>
                            <input type='checkbox' name='address' id='address' value='3' $c_adr><label>Location address</label><br>
                            <input type='checkbox' name='contact' id='contact' value='4' $c_contact><label>Contact</label><br>
                            <input type='checkbox' name='mediaDetail' id='mediaDetail' value='5' $c_media><label>Social media detail</label>
                        </fieldset>";
$settings.="<br><h4 style='color:white; background-color:#aaa; margin-bottom:5px;'>Xkroll call</h4>
                 <fieldset style='border:0px'>
                          <legend>Xkroll call</legend>
                            <input type='checkbox' name='aud_req' id='aud_req' value='1' $aud_req>&nbsp;&nbsp;&nbsp;Always use audio<br> 
                            <input type='checkbox' onclick=$('#rngInput').show('slow') name='req_range' id='req_range' value='2' $useDefaultKm>&nbsp;&nbsp;&nbsp;Set default Xkroll call range<br>
                            <div id='rngInput' class='collapse'><input type='number' value='$def_range' name='def_range' id='def_range' min='0.1' max='20.0' placeholder='e.g. 0.5'>&nbsp;Km</div>
                  </fieldset>
            </fieldset>
            <br><h4 class='profile_headings'>Others</h4>
                 <fieldset style='border:0px;'>
                <legend>Notification</legend>
                            <input type='checkbox' name='mailNote' id='mailNote' value='1' $checked_m><label>Include Email Notification</label><br>
                            <input type='checkbox' name='mailNote' id='mailNote' value='1' $checked_m><label>Only alert me from >50% integrity</label>
                </fieldset><br>
                            <input type='submit' name='saveSettings' id='saveSettings' value='Save' class='btn'>
       	    </form></div><br><><br>";
return $settings;