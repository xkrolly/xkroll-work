<?php

$usersView = new usersView();
$Rquests= $usersView->timelineRqst();
$Rpts= $usersView->timelineRpt();
$Rturns= $usersView->timelineRtn();

$output = '<h4 class="text-center"><i class="fa fa-clock" style="color:gold"></i>&nbsp;&nbsp;<a href=#>Timeline</a></h4><br>
	<div class="text-center">
		<span class="thead thead2" id="rptHx">
			<i class="fa fa-clock" style="color:#ccc"></i>
			&nbsp;&nbsp;Report
		</span>
		<span class="thead" id="rtnHx">
     		<i class="fa fa-clock" style="color:#ccc"></i>&nbsp;&nbsp;Return
		</span>
		<span class="thead thead3" id="reqHx">
			<i class="fa fa-clock" style="color:#ccc"></i>&nbsp;&nbsp;Request
		</span>
	</div><br>
	<div class="collapse" id="req">';

foreach ($Rquests as $rquest) {
	$i=$rquest['donation_id'];
	$rquest['hAcesd']==1 ? $status="&nbsp;&nbsp;<button class='btn btn-sm' data-toggle='modal' data-target='#hOption".$i."' style='color:#fff; font-family:lucida; text-decoration:italic; background-color:green; padding:5px; border-radius:5px'>Granted</button>" : $status="";
	
	$output .='<p style="margin-left:20px; font-style:italic; font-family:cursive"><strong>'.$rquest['item'].'</strong> '.$usersView->time($rquest['d_date']).$status.'</p>';

	$output.="<div class='modal fade' id='hOption".$i."' tabindex='-1' role='dialog' aria-hidden='true' style='margin-top:45%'>
             <div class='modal-dialog' role='document'>
              <div class='modal-content'>
                <div class='modal-body' style='margin-left:3%'>
                 <form method='POST' id='#donorGrab'>
                		<input type='hidden' name='idd' value='".$rquest['donor']."'/>
                	<h6 class='text-center'>".$rquest['item']." donated by ".$rquest['donor']."</h6>
            				<i class='fa fa-user tracus'></i>&nbsp;&nbsp;&nbsp;<a href=#>View helper</a><br><br>
                  	<i class='fa fa-history'></i>&nbsp;&nbsp;&nbsp;<a href=#>Take a break</a><br><br>
    			<div data-toggle='modal' data-target='#blockDonor".$i."'><i class='fa fa-ban warning'></i> &nbsp;&nbsp;&nbsp;<a href=# class='warning'>Block this helper</a></div><br>
    			</form>
               </div>
              </div>
            </div>
           </div>";

$output.="<div class='modal fade' id='blockDonor".$i."' tabindex='-1' role='dialog' aria-hidden='true' style='margin-top:5%'>
            <div class='modal-dialog' role='document'>
              <div class='modal-content'>
                <div class='modal-body' style='margin-left:3%'>
                	<h6 class='text-center'>You want to stop this Helper from seeing your future requests?</h6>
                	<center>Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</center>
                </div>
              </div>
            </div>
        </div>";
}
$output.='</div>';
$output.='<div class="collapse" id="rtn">';

foreach ($Rturns as $rturn) {
	$output .= "<div class='' style=''><p style='padding:4px 4px 2px 10px; margin-left:20px; font-style:italic; font-family:cursive; border-radius:10px; border:1px solid #ccc'><strong>".$rturn['ppt']."</strong> ".$usersView->time($rturn['reporting_date'])."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class='fa fa-bars'></i>&nbsp;&nbsp;&nbsp;<i class='fa fa-trash'></i></p></div>";
}
$output.='</div>';
$output.='<table width="100%" class="collaps" id="rpt" style="margin:25px">';

foreach ($Rpts as $rpt) {
  $output.='<tr style="font-style:italic; font-family:cursive; border:1px solid #ccc; border-radius:40px; padding:4px -4px 4px 0px;"><td width="70%">
  		<strong>'.$rpt['ppt'].'</strong> '.$usersView->time($rpt['reporting_date']).'</td><td width="30%" colspan=""><i class="fa fa-bars"></i>&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-trash"></i>&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-ellipsis-v"></i></td></tr>';
}
$output.='</table>';
return $output;