<?php
  return "<form id='regAsset_data'>
                  <div class='form-group'>
                    <div class='col-sm-12'>
                        <label for='asset' style='font-weight:bold;'>Select property</label>
                    </div>
                    <div class='col-sm-12' style=''>
                      <select class='form-control asset' name='asset' id='asset'>
                        <option value=''>Select one</option>
                        <optgroup label='Vehicle'>
                          <option value='1'>Car</option>
                          <option value='2'>Bus</option>
                          <option value='3'>Truck</option>
                          <option value='4'>Lorry</option>
                          <option value='5'>Motorcycle</option>
                        </optgroup>
                        <optgroup label='Electronics'>
                          <option value='6'>Phone/Tablet</option>
                          <option value='7'>Tv sets</option>
                          <option value='8'>Air pod</option>
                          <option value='9'>Ipad</option>
                          <option value='10'>Others</option>
                        </optgroup>
                      </select>
                        <span id='check_property_'></span>
                    </div>
                  </div>
                  <div class='form-group model' style='display:block;'>
                
                    <div class='col-sm-12' style='display:flex;'>
                        <div style='display:flex column' style='margin-right:2%;'>
                        <label for='make' style='font-weight:bold;'>Make</label>
                        <select class='form-control col-sm-6' placeholder='Make' style='width:90%;' name='make' id='make'>
                        <option value=''>Select</option>
                          <option>Tesla</option>
                          <option>Toyota</option>
                          <option>Mercedes</option>
                          <option>Peugeot</option>
                        </select>
                            <span id='check_make'></span>
                        </div>
                        <div style='display:flex column' style='margin-right:2%;'>
                        <label for='model' style='font-weight:bold;'>Model</label>
                        <input type='text' class='form-control col-sm-6' placeholder='Model' style='width:90%;' name='model' id='model'>
                            <span id='check_model'></span>
                        </div>
                        <div style='display:flex column'>
                        <label for='color' style='font-weight:bold;'>Color</label>
                        <input type='color' value='' class='form-control chasisCol' style='width:50px; padding:2px;' name='color' id='color'>
                        <span id='check_color'></span>
                        </div>
                        
                    </div>
                  </div>
                   <div class='form-group vins' style='display:none;'>
                    <div class='col-sm-12'>
                             <label for='engine-number' style='font-weight:bold;'>VINs</label>
                    </div>    
                    <div class='col-sm-12' style='display:flex;'>
                      <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Engine num...' style='width:95%;' name='engine-number' id='engine-number'>
                        <span id='check_engine-number'></span>
                        </div>
                        <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Chassis num...' style='width:95%; margin-right:2%;' name='chassis-number' id='chassis-number'>
                          <span id='check_chassis-number'></span>
                        </div>

                      <div style='display:flex column' style='margin-right:.5%;'>
                 <input type='text' class='form-control col-sm-4' placeholder='Num. plate...' style='width:95%; margin-right:2%;' name='number-plate' id='number-plate'>
                        <span id='check_number-plate'></span>
                        </div>

                    </div>
                </div>
                <div class='form-group uniq-Id' style='display:none;'>
                    <div class='col-sm-12'>
                             <label for='engine-number' style='font-weight:bold;'>Unique ID</label>
                    </div>    
                    <div class='col-sm-12' style='display:flex;'>
                      <input type='text' class='form-control' name='uniqId' id='unique-Id'>
                    </div>
                </div>


                <div class='form-group assetimg' style='display:none; margin-bottom:25px;'>
                    <div style='display:flex-column; margin-top:10px;'>
                      <div class='col-sm-12'>
                        <label style='font-weight:bold;'>Item image</label>
                      </div>
                      <div class='col-sm-12'>
                        <div style='display:flex;'>
                               <input type='file' name='file' class='fileinput' multiple  style='width:60%;' capture='environment' accept='image/*'/ id='property-image'>
                                <div style='border-radius:10px; padding:10px 10px 10px 20px; font-size:12px; background:#ccc; color:#000; text-align:left;'><i class='fa fa-info' style='margin-right:5px;'></i> Upload the snapshot of the serial number page or IMEI screenshot of your property.<span style='color:red;'> (required)</span>
                                </div>
                            </div>
                        </div>
                        <span id='check_property-image'></span>
                    </div>            
                </div>
 


                <div class='form-group'>
                    <div class='col-sm-12'>
                      <input type='submit' class='btn theme' name='regass'>
                    </div>
                </div>


              </form>";

